





<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
    <link href="<?php echo get_template_directory_uri(); ?>/css/stylenew.css" rel="stylesheet" type="text/css" />
<link href="<?php echo get_template_directory_uri(); ?>/css/responsivenew.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Varela+Round&amp;subset=hebrew,latin-ext,vietnamese" rel="stylesheet"> 
	 <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


	<?php 
	
	add_action( 'wp_enqueue_scripts', 'enqueue_theme_css' );
    
    function enqueue_theme_css()
    {
        wp_enqueue_style(
            'default',
            get_template_directory_uri() . '/css/stylenew.css'
        ); 
        wp_enqueue_style(
            'mediaa',
            get_template_directory_uri() . '/css/responsivenew.css'
        );
    }
 
	
	wp_head(); ?>
</head>

<body <?php body_class(); ?>>




<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset >= 1) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
<?php
$redirect_login = get_page_by_path("login");
$redirectloginlink = get_permalink($redirect_login->ID);
$siteurl = get_option('siteurl');
?>
     <div class="header">
        <div class="wraper">
          <div class="logo">
             <img src="<?php echo $siteurl;?>/wp-content/uploads/2018/06/logo.jpg" alt="logo">
		  </div>
         <div class="search_box">
             <form id="tfnewsearch" method="get" >
			  <input type="text" placeholder="Vous cherchez quelque chose ?" name="search" id="main">
			  <input type="submit" value="" id="autocomplete">
			 </form>
		  </div>
		  <div class="seconneters">
	<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/elip.png" alt="">
	<?php if(!is_user_logged_in()){?>
	    <a href="<?php echo $redirectloginlink;?>"><h3>Se connecter</h3></a>
	<?php }else{?>
	    <a href="<?php echo wp_logout_url( $redirectloginlink ); ?>"><h3>Se déconnecter</h3></a>
	<?php }?>
	</div>
    <div class="menuicon" id="abc">
		  <div class="bar1"></div>
		  <div class="bar2"></div>
		  <div class="bar3"></div>
    </div>
	<div class="nav" id="navigation">
	 <?php wp_nav_menu( array( 'theme_location' => 'my-menu2' ) ); ?>
	</div>
	
	
	  <br class="clr">
         </div>
  </div><!--header-->





