<?php
   //  echo "<pre>";
   // print_r($_POST);exit;
@session_start();   
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
$siteurl = get_option('siteurl');
global $wpdb;
$prmetaid = $_POST['prmetaid'];
$SQLPROJECTMETA = "SELECT * FROM wp_project_meta WHERE id='".$prmetaid."'";
$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA);

$desid=$rsProdmeta[0]->designation_id;
$SQLDESIGNATION = "SELECT * FROM wp_designations WHERE id='".$desid."'";
$rsDesignation = $wpdb->get_results($SQLDESIGNATION); 
/*echo '<pre>';
print_r($rsDesignation);
echo '</pre>';
*/
$user_id=$rsProdmeta[0]->user_id;
$key = array('prime_mwhc','highprecarite','precarite');
$key1='prime_mwhc';
$key2='precarite';
$key3='highprecarite';
$single = true;
$user_info = get_userdata($user_id);
$user_email=$user_info->user_email;
 $prime_mwhc= get_user_meta( $user_id, $key1, $single );
$precarite= get_user_meta( $user_id, $key2, $single );
$highprecarite= get_user_meta( $user_id, $key3, $single );
$mwhvalue= $rsProdmeta[0]->mwh_cumac;
$prime=$mwhvalue*$prime_mwhc/1000;
$precarite=$mwhvalue*$precarite/1000;
$highprecarite=$mwhvalue*$highprecarite/1000;
$numberlink=$rsProdmeta[0]->number_link;
$number= $rsProdmeta[0]->number_title;
?>
<span class="hrbor"></span>
	 <div class="reparti_moninse"> 
	<div class="wraper">
<div class="reparti_montant">
		<form name="frmcals" id="frmcals" method="post" action="">		
        <h1>Repartissez le montant total de la prime </h1>
	
        <div class="reparti_mon_text">
		   <ul>
		       <li>
				     <h3>Montant pour votre client :</h3>
				     <h4><span id="amounts"><?php echo number_format($prime,0," "," ")." ".$rsProdmeta[0]->primecurr;?></span></h4>
	           </li>
		       <li>
				     <h3>Montant gardé pour vous :</h3>
				     <h4><span id="curriences">0,00 €</span></h4>
	           </li>
		  </ul>
		<div class="partition_sec">
		   <h3>Bougez le curseur pour modifier le % de répartition </h3><span id="percentages">100%</span>
		   <!--<img src="<?php echo $siteurl;?>/wp-content/uploads/2018/06/percents1.png" alt="Bougez le curseur">-->
			 <!--<input type="range" name="points" min="0" max="100" step="10" value="100" list="grade" onclick="return calsresults(this.value);" class="newwcoverange">-->
			 <input type="range" name="points" class="newwcoverange" min="0" max="100" step="10" value="100" list="grade" onclick="return calsresults(this.value);"/>
			 
		</div>
		<div class="prime_sec" id="results">
          <table width="100%" border="0"cellpadding="0" cellspacing="0">

<tr>
  <th class="newrcvse"></th>
  <th id="a2" axis="expenses">Pour votre client</th>
  <th id="a3" axis="expenses">Pour vous</th>
</tr>
<tr>
  <td class="newrcvse"></td>
 <td></td>
 <td></td></tr>
<tr>
  <td class="newrcvse">Prime sans precarité</td>
  <td><a><?php echo number_format($prime,0," "," ")." ".$rsProdmeta[0]->primecurr;?></a><input type="hidden" readonly value="<?php echo number_format($prime,0," "," ")." ".$rsProdmeta[0]->primecurr;?>" name="primevalaj" id="primevalaj" ></td>
  <td><a><?php echo $rsProdmeta[0]->primecurr;?></a><input type="hidden" readonly value="<?php echo $rsProdmeta[0]->primecurr;?>" name="g_primevalaj" id="g_primevalaj" ></td>

</tr>
<tr>
  <td class="newrcvse">Prime avac precarite (avec justificatif)</td>
  <td><a><?php echo number_format($precarite,0," "," ")." ".$rsProdmeta[0]->primecurr;?></a><input type="hidden" readonly value="<?php echo number_format($precarite,0," "," ")." ".$rsProdmeta[0]->primecurr;?>" name="precariteaj" id="precariteaj" ></td>
  <td><a><?php echo $rsProdmeta[0]->primecurr;?></a><input type="hidden" readonly value="<?php echo $rsProdmeta[0]->primecurr;?>" name="g_precariteaj" id="g_precariteaj" ></td>

</tr>
<tr>
  <td class="newrcvse">Prime grand avac precarite (avec justificatif)</td>
 <td><a><?php echo number_format($highprecarite,0," "," ")." ".$rsProdmeta[0]->primecurr;?></a><input type="hidden" readonly value="<?php echo number_format($highprecarite,0," "," ")." ".$rsProdmeta[0]->primecurr;?>" name="grandprecariteaj" id="grandprecariteaj" ></td>
  <td><a><?php echo $rsProdmeta[0]->primecurr;?></a><input type="hidden" readonly value="<?php echo $rsProdmeta[0]->primecurr;?>" name="g_grandprecariteaj" id="g_grandprecariteaj" ></td>

</tr>
<tr>
<td class="newrcvse"></td>
<td></td>
<td></td>
</tr>


</table>
		
	      </div>		
		
		
		</div><!--ends reparti_mon_text-->
		 <input type="hidden" name="currency" id="currency"  value="<?php echo $rsProdmeta[0]->primecurr; ?>" />
			  <input type="hidden" name="mwhvalue" id="mwhvalue"  value="<?php echo $mwhvalue; ?>" />
			  <input type="hidden" name="userid" id="userid"  value="<?php echo $user_id; ?>" />
			  <input type="hidden" name="useremail" id="useremail"  value="<?php echo $user_email; ?>" />
			  <input type="hidden" name="scenarioid" id="scenarioid"  value="<?php echo $desid; ?>" />
			  <input type="hidden" name="pmtid" id="pmtid"  value="<?php echo $rsProdmeta[0]->id; ?>" />
			  <input type="hidden" name="pmtitle" id="pmtitle"  value="<?php echo $rsDesignation[0]->des_name; ?>" />
			  <input type="hidden" name="pmnumberlink" id="pmnumberlink"  value="<?php echo $numberlink; ?>" />
			  <input type="hidden" name="pmnumbername" id="pmnumbername"  value="<?php echo $number; ?>" />
</form>		
	 <h4 class="saproject newsaproh"> <a href="#" id="myBtn">Faire cette offre à mon client</a> </h4>	
	 	 	<div id="successresult"></div>

 <div id="myModal" class="modal">

  <!-- Modal content -->
  
  <div class="modal-content">
    <span class="close">&times;</span>
    <div class="pop_secttxt">
 <h3>Faire une offre de prime à mon client</h3>	
	  <div class="pop_sect12" id="maindivforms">
	    <form action="#" id="frms" method="post" name="frms">
		 <div class="pop_setxtnede"> 
			 <h5> Identifier votre client :</h5>
		    <p>
		        <input type="text" name="cname"  id="cname" placeholder="Prénom"/>
		    	<input type="text" name="cfullname" id="cfullname" placeholder="Nom"/>
			</p>
				<input type="email" name="cemail" id="cemail" placeholder="Email"/>
		  <p>
			<input type="tel" name="mobil" id="mobil" placeholder="Téléphone mobile"/>
			<input type="tel" name="tel" id="tel" placeholder="Téléphone fixe"/>
			</p>
			
			 <h5>Localisation du chantier :</h5>
		   <input type="addresdu" name="caddress" id="caddress" placeholder="Adresse du client"/>
		  <p>
			<input type="text" name="postalcode" id="postalcode" placeholder="Code postal"/>
			<input type="text" name="ville" id="ville" placeholder="Ville">
			</p>
			 <p><input type="hidden" name="fiche" id="fiche1" value="<?php echo $number;?>">
			<input type="hidden"  name="fichelink" id="fichelink" value="">
			<input type="hidden" name="fichname" id="fichname" value="">
			<input type="hidden"  name="mwhcumac" id="mwhcumac" placeholder="Mwh cumac" value="">
			<input readonly type="hidden" name="repartition" id="repartition" placeholder="% repartition prime" value="">
			<input type="hidden" value="" name="userids" id="userids">
			<input type="hidden" value="" name="useremails" id="useremails">
			<input type="hidden" value="" name="scenarioids" id="scenarioids" value="">
			<input type="hidden" name="pmetaid" id="pmetaids"  value="<?php echo $rsProdmeta[0]->id; ?>" />
			<input type="hidden" value="" name="primevalfinal" id="primevalfinal" >
			<input type="hidden"  value="" name="precaritefinal" id="precaritefinal" >
			<input type="hidden" value="" name="grandprecaritefinal" id="grandprecaritefinal" >
			<input  type="hidden" value="" name="g_primevalf" id="g_primevalf" >
			<input value="" type="hidden" name="g_precaritef" id="g_precaritef" >
			<input  value="" type="hidden" name="g_grandprecaritef" id="g_grandprecaritef" >
			</p>	
			
			</div>	 
 <div id="loaders" style="display:none;"><img src="<?php echo $siteurl;?>/wp-content/uploads/2018/06/load.gif"></div>
	 
	 

	 </form>	
	 </div>
	 	  <input type="button" name="btnSubmit" id="btnSubmit" onclick="return submitfinaldata()" value="Valider" id="valider">
    </div>  
  </div>

</div>
  </form>

</div>
 </div><!--ends reparti_montant-->	
 </div>
 
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
	$('#primevalfinal').val($('#primevalaj').val());
$('#precaritefinal').val($('#precariteaj').val());
$('#grandprecaritefinal').val($('#grandprecariteaj').val());
$('#repartition').val($('#percentages').html());
$('#mwhcumac').val($('#mwhvalue').val());

//-------------------------------------------
//$('#fiche').val($('#pmnumbername').val());
$('#fichelink').val($('#pmnumberlink').val());
$('#fichname').val($('#pmtitle').val());
//-------------------------------------------



//-------------------------------------------
$('#useremails').val($('#useremail').val());
$('#scenarioids').val($('#scenarioid').val());
$('#userids').val($('#userid').val());

//-------------------------------------------
$('#g_primevalf').val($('#g_primevalaj').val());
$('#g_precaritef').val($('#g_precariteaj').val());
$('#g_grandprecaritef').val($('#g_grandprecariteaj').val());
document.getElementById('maindivforms').style.display = "block";
document.getElementById('loaders').style.display = "none";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function calsresults(vals){
		//alert("A");
		var curr=$('#currency').val();
		var mwhvalue=$('#mwhvalue').val();
		var userid=$('#userid').val();
		urls = "<?php echo $siteurl;?>/wp-content/themes/enemat/ajax_scripts/get_details.php";	
		$.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"vals":vals,"currency":curr,"mwhvalue":mwhvalue,"userid":userid},
                url: urls,
                success: function(msgs){
				 //alert(msgs);
				  obj = JSON.parse(msgs);
				 document.getElementById("amounts").innerHTML = obj.amount1;
				 document.getElementById("curriences").innerHTML = obj.amount2;
				 document.getElementById("results").innerHTML = obj.details;
				 document.getElementById("percentages").innerHTML = vals+ "%";					
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
	}
	function submitfinaldata()
{//alert($('#fiche1').val());
var pmetaid = jQuery('#pmetaids').val();
var primeval=jQuery('#primevalfinal').val();
var precarite=$('#precaritefinal').val();
var grandprecarite=$('#grandprecaritefinal').val();

var g_primeval=jQuery('#g_primevalf').val();
var g_precarite=$('#g_precaritef').val();
var g_grandprecarite=$('#g_grandprecaritef').val();


var userid=$('#userid').val();
var useremail=$('#useremail').val();
var scenarioids=$('#scenarioids').val();


var cfname=$('#cname').val();
var cfullname=$('#cfullname').val();
var email=$('#cemail').val();
var tel=$('#tel').val();
var mobil=$('#mobil').val();

var caddress=$('#caddress').val();
var postalcode=$('#postalcode').val();
var ville1=$('#ville').val();
var fiche1=$('#fiche1').val();
var fichelink=$('#fichelink').val();
var pmtitle = $('#pmtitle').val();
var fichname=$('#fichname').val();

var mwhcumac=$('#mwhcumac').val();
var repartition=$('#repartition').val();
if(cfname=="")
{
	$('#cname').focus();
	return false;
}

if(cfullname=="")
{
	$('#cfullname').focus();
	return false;
}
if(email=="")
{
$('#cemail').focus();
return false;
}
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(!email.match(mailformat))
{
alert("You have entered an invalid email address!");
$('#email').focus();
return false;
}
if(tel=="")
{
	$('#tel').focus();
	return false;
}
var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
if(!tel.match(phoneno)){
alert("Le numéro de téléphone n'est pas valide.");
$('#tel').focus();
return false;
}
if(mobil=="")
{
	$('#mobil').focus();
	return false;
}
//var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
if(!mobil.match(phoneno)){
alert("Le numéro de téléphone n'est pas valide.");
$('#mobil').focus();
return false;
}
if(caddress=="")
{
$('#caddress').focus();
return false;
}
if(postalcode=="")
{
$('#postalcode').focus();
return false;
}
if(ville1==""){
$('#ville').focus();
return false;	
}

var strs="submitfinalreport";
urls = "<?php echo $siteurl;?>/wp-content/themes/enemat/ajax_scripts/get_details.php";	
if(confirm("Voulez-vous envoyer l'offre?")){//alert('a');
		document.getElementById("loaders").style.display="block";
		//document.getElementById("maindivforms").style.display="none";		
		document.getElementById("btnSubmit").disabled=true;
		$.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"pmetaid":pmetaid,"cemail":email,"cname":cfname,"cfullname":cfullname,
				"cmobil":mobil,"ctel":tel,"caddress":caddress,"postalcode":postalcode,"ville":ville1,
				"useremail":useremail,"scenarioids":scenarioids,"strs":strs,
				"scenariotitle":fichname,"fichelink":fichelink,"fiche":fiche1,"mwhcumac":mwhcumac,
				"primeval":primeval,"precarite":precarite,"grandprecarite":grandprecarite,
				"g_primeval":g_primeval,"g_precarite":g_precarite,"g_grandprecarite":g_grandprecarite,
				"userid":userid,"pmtitle":pmtitle},
                url: urls,
                success: function(msgs){
                var obj = JSON.parse(msgs);
				 if(obj.status=="success"){
				document.getElementById("btnSubmit").disabled=false; 
				document.getElementById('myModal').style.display = "none";	
				document.getElementById("loaders").style.display="none";				
				document.getElementById("successresult").innerHTML = "Votre offre de prime a été soumise!";
				//document.getElementById("successresult").focus();
				$('html, body').animate({scrollTop:$('#successresult').position().top}, 'slow');
				$('#successresult').focus();
			}
				if(obj.status=="error"){
				document.getElementById('myModal').style.display = "block";
				document.getElementById("successresult").innerHTML = "Votre offre de prime a été failed!";
				$('html, body').animate({scrollTop:$('#successresult').position().top}, 'slow');
				$('#successresult').focus();
				}
				},
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}
}
</script>