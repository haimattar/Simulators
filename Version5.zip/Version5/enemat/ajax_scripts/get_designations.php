<?php
   //  echo "<pre>";
   // print_r($_POST);exit;
@session_start();   
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
$siteurl = get_option('siteurl');
global $wpdb;
$subcatid = $_POST['subcatids'];
$SQL="SELECT * FROM `wp_designations` WHERE status='Active' AND  subcatid ='".$subcatid."'";
$rsDesignation=$wpdb->get_results($SQL);
?>
<h3>Désignation :</h3>
	 <select name="fiche" id="fiche" onchange="return show_step2(this.value,'<?php echo get_template_directory_uri().'/ajax_scripts/get_wordings.php';?>');">
		 <option value="" class="opwrap" selected="selected">Pompe à chaleur collective à absorption de type air/eau </option>
		  <?php if(count($rsDesignation)>0){
				for($i=0;$i<count($rsDesignation);$i++){
		  ?>
			<option value="<?php echo $rsDesignation[$i]->id;?>"><?php echo stripslashes($rsDesignation[$i]->des_name);?></option>
		  <?php }
		  } ?>
</select>
<div id="numtitles" style="display:none;"></div>