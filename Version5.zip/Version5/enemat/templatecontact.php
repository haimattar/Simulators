<?php
// Template Name: Contact
get_header(); ?>
<div class="main_pro">
	<div class="wraper">
		<div class="txt_pro">
			<h3>Contact</h3>
		</div>
		<div class="clr"></div>
	</div>
</div>
<div class="cont_form">
<div class="wraper">
	<div class="lf_cont">
	<h5>Enemat</h5>
		<form>
			<input type="text" placeholder="Nom">
			<input type="text" placeholder="Email">
			<input type="text" placeholder="Sujet">
			 <textarea rows="6" cols="50" placeholder="Message"></textarea> 
		</form>
			 <a href="">Envoyer</a>
	</div>
	<div class="rg_cont">
		<div class="txtNew">
		<h6>Notre adresse</h6>
		<h6>ENEMAT&nbsp;</h6>
		<p>22 rue duret</p>
		<p>75116 PARIS</p></div>
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2624.1306374101414!2d2.28404801520228!3d48.87478610750689!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1515417335767" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
		<a href="">gestion@enemat.fr</a>
	</div>
	<div class="clr"></div>
	</div>
</div>
<?php get_footer(); ?>