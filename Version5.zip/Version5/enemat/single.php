<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package enemat
 */

get_header('post'); ?>
<div class="mem_bck">
	<div class="wraper">
	<div class="contentbody">
		<?php
		while ( have_posts() ) : the_post();
the_content();
if ( comments_open() || get_comments_number() ) :
			comments_template();
			endif;

		endwhile; // End of the loop.
		?>
		</div>
	<div class="rec_post rup_new" id="ARTICLESRÉCENTS">
	<h5>Post Recent</h5>
	<ul>
 <?php
  $args = array( 'post_type' => 'post',
  'posts_per_page' => 2,
  'category_name'=>'Rédigez un commentaire',
  'order'=>'ASC', 'order'=>'date',
  'post__not_in' => array( $post->ID )
  );
  $loop = new WP_Query( $args ); 
  while ( $loop->have_posts() ) : $loop->the_post();
?>

<li>
<?php if ( has_post_thumbnail()) {?> <a href="<?php the_permalink(); ?>" ><?php echo the_post_thumbnail(array(200,150)); ?> </a> <?php } ?>
<a href="<?php the_permalink(); ?>"><p class="title1"><?php the_title(); ?></p></a>
<p class="rup_set">
<span><i class="fa fa-eye" aria-hidden="true"></i></span><?php echo do_shortcode('[post-views]') ?>
<a href="<?php the_permalink(); ?>"><span class="txt1">Rédigez un commentaire</span></a>
<span><i class="fa fa-heart-o" aria-hidden="true"></i></span>
</p>
</li> <?php endwhile; ?>
 </ul>
 </div>
 <div class="lnkks"><p><a href=""><span>Connexion </span> pour laisser un commentaire !</a></p></div>
 <div class="clr"></div>
		</main><!-- #main -->
	</div><!-- #primary -->
		</div><!-- #primary -->
			</div><!-- #primary -->

<?php
//get_sidebar();
get_footer();
