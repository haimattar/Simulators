<?php
// Template Name: Info et actus
get_header(); ?>
<div class="mem_vid">
	<video width="100%"  autoplay>
		<source src="https://video.wixstatic.com/video/11062b_d38eb6f132584c9a9b88b3bbd4c7b8eb/1080p/mp4/file.mp4" type="video/mp4">
	</video>
	<h2>INFOS ET ACTUS</h2>
	<div class="clr"></div>	
</div>
<div class="mem_bck">
	<div class="wraper">
	<div class="navigation">
		<ul>
			<li><a href="">Members</a></li>
		</ul>
	</div>
	<div class="ser_icn">
	<form>
		<ul>
			<li><a href=""><i class="fa fa-search" aria-hidden="true"></i></a></li>
			<li><a href=""><i class="fa fa-user-o" aria-hidden="true"></i></a></li>
		</ul>
	</form>
	<a class="btn" href="">Connexion/Inscription</a>
	</div>
		<ul class="mem_bck1">
		
		
				 <?php
  $args = array( 'post_type' => 'post', 
  'posts_per_page' => 4,
  'category_name'=>'Rédigez un commentaire',
  'order'=>'DESC',
 'orderby'=>'date'
  ); 
  $loop = new WP_Query( $args ); while ( $loop->have_posts() ) : $loop->the_post();
?>
<li><a href="<?php the_permalink(); ?>">
<?php echo the_post_thumbnail('full'); ?> 
<div class="lf_icn">
<span>Manu AT</span><img src="<?php echo get_template_directory_uri(); ?>/images/Capture2.png">
<ul><li><span><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></span></li> </ul>
</div>
<div class="rg_icn">
<img src="<?php echo get_template_directory_uri(); ?>/images/Capture.png">
</div>
<h6><?php the_title(); ?></h6>
<p class="brdr"><?php echo wp_trim_words( get_the_content(), 20, '...' ); ?></p>
</a>
<p class="rup_set">
<span><i class="fa fa-eye" aria-hidden="true"></i></span><?php echo do_shortcode('[post-views]') ?>
<a href="<?php the_permalink(); ?>"><span class="txt1">Rédigez un commentaire</span></a>
<span><i class="fa fa-heart-o" aria-hidden="true"></i></span>
</p>
</li>
<?php endwhile; ?>
</ul>
<div class="clr"></div>
</div>
</div>
<?php get_footer(); ?>