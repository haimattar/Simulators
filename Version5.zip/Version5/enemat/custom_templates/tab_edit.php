<style>
.mem_vid1 {
margin-top: 40px; 
overflow: hidden;
position: relative; 
vertical-align: bottom;
}
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>
<script>
      window.onload = function () {
         document.getElementById("oneopen").click();
      }      
    </script>
<?php 
// Template name: Tabbar Edit
get_header();print_r($_POST);
//session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
$current_date = date("Y-m-d H:i:s");
$siteurl = get_option("siteurl");
$table_name = $wpdb->prefix . "projects";
/*echo '<pre>';
print_r($_POST);
echo '</pre>';*/
$insertdata=isset($_POST['submit_form'])?$_POST['submit_form']:'';
$project_id = $_POST['project_id'];
//print_r($_POST);exit;
if(!empty($insertdata) && $insertdata=="Enter the project") {
            $projectname=$_POST['project_name'];
            $projectdesc=$_POST['project_desc'];
            $projecttype=$_POST['project_type'];
            $subprojecttype=$_POST['subproject_type'];
            $subtype=($projecttype==2)?$subprojecttype:'';
            $studyzone=$_POST['study_zone'];
            $projectcat=implode(',',$_POST['projectcat']);
            $epc=$_POST['epc'];
            $study_dureeContrat=$_POST['study_dureeContrat'];
            $study_objectifEcon=$_POST['study_objectifEcon'];
            $duration=($epc=="yes")?$study_dureeContrat:'';
            $goals=($epc=="yes")?$study_objectifEcon:'';
            $price=$_POST['price'];
            $study_unite=$_POST['study_unite'];
			$SQL = "UPDATE wp_projects SET name='".esc_sql($projectname)."',description='".esc_sql($projectdesc)."',pt_id='".esc_sql($projecttype)."',subpt_id='".esc_sql($subtype)."',zone_id='".esc_sql($studyzone)."',sectors_id='".esc_sql($projectcat)."',epc_status='".esc_sql($epc)."',duration='".esc_sql($duration)."',goal='".esc_sql($goals)."',sellingprice_id='".esc_sql($price)."',unit_id='".esc_sql($study_unite)."' WHERE id='".$project_id."'";
            $wpdb->query($SQL);
}

$cat_ds=implode(',',$_POST['projectcat']);
global $wpdb;
$sql="SELECT * FROM `wp_categories` WHERE status='Active' AND  id IN ($cat_ds) ";
$strsd=$wpdb->get_results($sql);
/*
echo '<pre>';
print_r($strsd);
echo '</pre>';
echo count($strsd);
*/ 
?>
<script>
function subcatchange(id,sids,url,tname){
//alert (id+url+tname);
var strs="fetchsubcat";
$('#numb'+sids+'').html('');
$('#commt'+sids+'').html('');
$('#idss'+sids+'').html('');
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"catids":id,"table_name":tname},
                url: url,
                success: function(msgs){
				//alert(msgs);
				 if($.trim(msgs)!=""){
					$('#fiche-input-holder'+sids+'').html(msgs);
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}

function subcatchangeedit(id,sids,url,tname,prjmtaid){
//alert (id+url+tname);
var strs="fetchsubcat";
//$('#numb'+sids+'').html('');
$('#commt'+sids+'').html('');
$('#catgscatgsid'+sids+'').html('');
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"catids":id,"table_name":tname,"prjmtaid":prjmtaid},
                url: url,
                success: function(msgs){
				//alert(msgs);
				 if($.trim(msgs)!=""){
					$('#fiche-input-holder'+sids+'').html(msgs);
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}


function getdestinations(id,sid){
//alert (sid);
var strs="fetchdestinations";
var url= document.getElementById("tabsurls").value;
    $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"destiid":id},
                url: url,
                success: function(msg){
               // alert (msg);
			   if($.trim(msg)!=""){
					var data_array = $.parseJSON(msg);				
					$('#numb'+sid+'').html(data_array['numb']);
					$('#commt'+sid+'').html(data_array['comnt']);
					$('#idss'+sid+'').html(data_array['meta']);
				}else{
					$('#numb'+sid+'').html('');
					$('#commt'+sid+'').html('');
					$('#idss'+sid+'').html('');
				}
                },
                error: function(){
                //$('#nummb').html(msg);
                }
        });
}

function getdestinationsedit(id,sidcts,prjmetaids){
  //alert (prjmetaids);
var strs="fetchdestinations";
var url="<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/frontdataeditwordings.php";
    $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"destiid":id,"catids":sidcts,"prjmetaid":prjmetaids},
                url: url,
                success: function(msgs){
                //alert (msgs);
			   if($.trim(msgs)!=""){
					var data_array = $.parseJSON(msgs);	
					//alert(data_array['meta']);					
					$('#catgscatgsid'+prjmetaids+'').html(data_array['meta']);
				}else{
					$('#catgscatgsid'+prjmetaids+'').html('');
				}
                },
                error: function(){
                //$('#nummb').html(msg);
                }
        });
}

function openCity(evt, cityName,project_id,pageurls1) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {

        tablinks[i].className = tablinks[i].className.replace(" active", "");
}
    document.getElementById(cityName).style.display = "block";
	if(document.getElementById("projectsrecds"+cityName+"")){
		$("#projectsrecds"+cityName+"").show();
	}
    evt.currentTarget.className += " active";
	document.getElementById("fiche"+cityName+"").options.length = 0;
	//========Ajax Part==============//
	$.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_id":project_id,"subsector_id":cityName},
                url: pageurls1,
                success: function(msgformdatas){
					//alert(msgformdatas);
					$("#projectsrecds"+cityName+"").before(msgformdatas);
                },
                error: function(){  
                }
        });
	//========Ajax Part==============//
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

function submit_form(pageurls,secsids){
	 frmdatas = $("#frmdata"+secsids+"").serialize();
	 if(document.getElementById("sousSecteur"+secsids+"").value==""){
		alert("Please select Subsector");
		document.getElementById("sousSecteur"+secsids+"").focus() = true;
		return false;
	}
	 if(document.getElementById("fiche"+secsids+"").value==""){
		alert("Please select Designation");
		document.getElementById("fiche"+secsids+"").focus() = true;
		return false;
	}
	/*var elements = document.getElementsByName("wmetavalue[]");
	if(elements){
		for (i = 0; i < elements.length; i++) {
			if (elements[i].tagName == "INPUT") {
				if(elements[i].value.replace(/^\s+|\s+$/g,'')==""){
					alert("Please enter this value");
					elements[i].focus() = true;
					return false;
				 }
			} 
		}
	}*/
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas,
                url: pageurls,
                success: function(msgformdatas){
					//alert(msgformdatas);
					$("#projectsrecds"+secsids+"").before(msgformdatas);
					$('#numb'+secsids+'').html('');
					$('#commt'+secsids+'').html('');
					$('#idss'+secsids+'').html('');
					//$('#fiche'+secsids+'').val();
					$("#EventStartTimeMin").val();
					$('#commentaires'+secsids+'').val('');
					$('#sousSecteur'+secsids+'').prop('selectedIndex',0);
					$('#wordingid'+secsids+'').val('');
					document.getElementById("wmetavalue"+secsids+"").options.length = 0;
					document.getElementById("fiche"+secsids+"").options.length = 0;
                },
                error: function(){  
                }
        });
}

function recet_data(ids,pageurls,secsids){
	//alert(secsids);
	 frmdatas11 = $("#aa"+secsids+"").serialize();
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas11,
                url: pageurls,
                success: function(msgformdatareset){
					 //alert(msgformdatas);
				$("#treditrow"+secsids+"").replaceWith(msgformdatareset);	 
                },
                error: function(){  
                }
        });
}
function update_form(ids,pageurls,secsids){
	//alert(secsids);
	 frmdatas11 = $("#aa"+secsids+"").serialize();
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas11,
                url: pageurls,
                success: function(msgformdatasdatas){
				//alert(msgformdatasdatas);
				$("#myModal").hide();	
				$("#trsimuledit"+ids+"").replaceWith(msgformdatasdatas);
				$("#myModal").html(''); 
                },
                error: function(){  
                }
        });
}

function delete_records(prmids,pageurlsdels,secsids){
	//alert(secsids);
	// alert(frmdatas1);	
	if(confirm("Do you want to delete?")){
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_meta_id":prmids},
                url: pageurlsdels,
                success: function(msgdeletes){
					 //alert(msgformdatas);
				//alert("Deleted");	 
				$("#trsimuledit"+prmids+"").remove();
				$("#myModal").hide();
				$("#myModal").html('');	
                },
                error: function(){  
                }
        });
	}	
}

function edit_project(project_meta_id,pageurlsmeta,subsecid,desgid,projid,catgsid){
	//alert("A");
	document.getElementById('myModal').style.display= "block";
	$.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_meta_id":project_meta_id,"subsecid":subsecid,"desgid":desgid,"projid":projid,"catgsid":catgsid},
                url: pageurlsmeta,
                success: function(msgformdatasupdates){
					//alert(msgformdatas);
					$("#myModal").html(msgformdatasupdates);
			    },
                error: function(){  
                }
        });
}

function show_pop1(){
	 document.getElementById('myModal').style.display= "block";
} 
function close1(){
	document.getElementById('myModal').style.display="none";
	$("#myModal").html('');	
}
</script>

<?php
function get_subsector($subsector_id){
	global $wpdb;
	$SQL = "SELECT category_name FROM wp_subcategory WHERE id='".$subsector_id."'";
	$rsSubcat = $wpdb->get_results($SQL);
	$subsectors = $rsSubcat[0]->category_name;
	return $subsectors;
}

function get_designations($designation_id){
	global $wpdb;
	$SQL = "SELECT des_name FROM wp_designations WHERE id='".$designation_id."'";
	$rsDesc = $wpdb->get_results($SQL);
	$desname = $rsDesc[0]->des_name;
	return $desname;
}


function get_wordings($project_meta_id){
	global $wpdb;
	$SQL = "SELECT * FROM wp_project_meta_wording WHERE project_meta_id ='".$project_meta_id."'";
	$rsMeta = $wpdb->get_results($SQL);
	$meta = "";
	$meta_title = "";
	if(count($rsMeta)>0){
		$meta .= '<table width="100%">';
		for($i=0;$i<count($rsMeta);$i++){
			$SQLWording="SELECT title FROM wp_wording WHERE id ='".$rsMeta[$i]->wording."'";
			$resultWord = $wpdb->get_results($SQLWording);
			if(!empty($rsMeta[$i]->wording_meta_id)){			
				$SQWordingMeta="SELECT title FROM wp_wording_meta WHERE id ='".$rsMeta[$i]->wording_meta_id."'";
				$resultWordMeta = $wpdb->get_results($SQWordingMeta);
				$meta_title = $resultWordMeta[0]->title;
			}else {				
				$meta_title = 	$rsMeta[$i]->value;
			}
			
			$meta .= '<tr><td style="width:40px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
			'.$resultWord[0]->title.'
			</font></font>
			</td>';
			$meta .= '<td class="param-input tac" style="width:40px;">'.$meta_title.'</td></tr>';
		}
			$meta .= '</table>';
	}
	return $meta;
}

$SQLPROJECTMETA = "SELECT * FROM wp_project_meta WHERE project_id='".$project_id."'";
$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA);
if(isset($_SESSION['SuccessMsg'])){?>
<div class="success-msg">
<h5><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></h5>
</div>
<?php }?>
<div class="mem_vid1">
</div>
<div class="mainform">
<div class="wraper">
<div class="tab">
<?php
if(count($strsd)>0){
/*foreach($strsd as $tbs)
{
$ids=$tbs->id;
 ?>
  <button class="tablinks" onclick="openCity(event, '<?php echo $ids;?>','<?php echo $project_id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/get_data.php')"><?php echo $tbs->category_name; ?></button>
 <?php 
}*/
 $counter=0;
foreach($strsd as $tbs)
{
$ids=$tbs->id;
if($counter==0){
 ?>
  <button class="tablinks" id="oneopen" onclick="openCity(event, '<?php echo $ids;?>','<?php echo $project_id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/get_data.php')"><?php echo $tbs->category_name; ?></button>
 <?php 
}else{?>
 <button class="tablinks" onclick="openCity(event, '<?php echo $ids;?>','<?php echo $project_id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/get_data.php')"><?php echo $tbs->category_name; ?></button>
<?php 
}
$counter = $counter+1;
}


}
?>
</div>
<?php if(count($strsd)>0){
foreach($strsd as $tbs)
{
$ids=$tbs->id;
$sqlSUBCat="SELECT * FROM `wp_subcategory` WHERE status='Active' AND  catid ='$ids' ";
$SUBCat=$wpdb->get_results($sqlSUBCat);

?>
<div id="<?php echo $ids;?>" class="tabcontent">
  <h3><?php echo $tbs->category_name; ?></h3>
<form class="frmdatas" name="frmdata<?php echo $ids;?>" id="frmdata<?php echo $ids;?>" method="post" action="">

<table class="table_a smpl_tbl">
<thead>
<tr>
<th rowspan="2" width="115"><div class="th_wrapp">
<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Subsector</font></font></div></th>
<th rowspan="2" width="230px">
<div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Designation</font></font></div></th>
<th rowspan="2" width="120px" style="width:100px;"><div class="th_wrapp">
<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Number</font></font></div></th><th colspan="2"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Settings</font></font></div></th><th width="100" rowspan="2"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Main application conditions</font></font></div></th><th width="120" rowspan="2"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">User Comments</font></font></div></th><th rowspan="2" width="50"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MWh </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">cumac</font></font></div></th><th rowspan="2" width="45"><div class="th_wrapp"><font style="vertical-align: inherit;"></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">CPE </font><font style="vertical-align: inherit;">Bonus</font></font></div></th><th class="hide-print" style="text-align:center;" rowspan="2" width="75"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">stock</font></font></div></th></tr><tr><th width="85"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Wording</font></font></div></th>
<th width="106" style="text-align:center;"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Value</font></font></div></th>
</tr></thead>
<tbody>
 <?php
 if(count($rsProdmeta)>0){
	for($i=0;$i<count($rsProdmeta);$i++){
?>
<tr class="sa_tab" id="trsimuledit<?php echo $rsProdmeta[$i]->id;?>">
<td rowspan="1" width="74">
<?php 
 $subsectors = get_subsector($rsProdmeta[$i]->subsector_id);
echo $subsectors;?>
</td>


<td class="" rowspan="1"  width="141"><?php echo $rsProdmeta[$i]->subsector_id;?>
	<?php 
 $designations = get_designations($rsProdmeta[$i]->designation_id);
echo $designations;?>
</td>

<td class="" width="97" ><?php echo $rsProdmeta[$i]->number_title;?></td>

<td colspan="2" width="106" valign="top" class="botrf"><?php 
	$wordings = get_wordings($rsProdmeta[$i]->id);
	echo $wordings;?></td>

<td class="" rowspan="1" width="95"><?php echo $rsProdmeta[$i]->conditions;?></td>
<td class="" rowspan="1" width="88"><?php echo $rsProdmeta[$i]->user_comments;?></td>
<td class="" rowspan="1" width="55"><?php echo $rsProdmeta[$i]->mwh_cumac;?></td>
<td class="" rowspan="1" width="39">0</td>
<td class="" style="text-align:center;" rowspan="1" width="59"><span class="updt_data" onclick="return edit_project('<?php echo $rsProdmeta[$i]->id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/edit_data.php','<?php echo $subsector_id;?>','<?php echo $designation_id;?>','<?php echo $project_id;?>','<?php echo $catgsid;?>');">Action</span>
</td>
</tr>
<?php }
}?>
 <tr id="projectsrecds<?php echo $ids;?>" class="new-op parent  hide-print" data-param-count="0" data-child-class="new-op-AGRI">
<td class="multi-row sousSecteur" rowspan="1" width="93">
<select name="sousSecteur" onchange="subcatchange(this.value,'<?php echo $ids;?>','<?php echo get_template_directory_uri().'/filterajax/frontdata.php';?>','designations')" id="sousSecteur<?php echo $ids;?>"  style="max-width: 110px;">
<option selected=""></option>
<?php foreach($SUBCat as $subc){ ?>
<option value="<?php echo $subc->id; ?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $subc->category_name; ?></font></font></option>
<?php } ?>
</select><br></td>


<td class="multi-row fiche responsecat" width="166" rowspan="1">
<div id="fiche-input-holder<?php echo $ids;?>">
<select name="fiche" style="max-width: 161px;" id="fiche<?php echo $ids;?>">
<option></option>
</select>
</div>
<span class="fiche-nom"></span></td>

<td width="78" class="responseall multi-row fiche-num-input-holder" id="AGRI-fiche-num-input-holder" rowspan="1">
<span  id="numb<?php echo $ids;?>" class="numero-link-holder">

</span>

<input type="text" data-sect-key="AGRI" class="inpt_c fiche-num-input" style="width: 80px; display: none;" id="AGRI-fiche-num-input" autocomplete="off" disabled="">

</td>

<td colspan="2" width="83" class="botrf"><div id="idss<?php echo $ids;?>"></div></td>

<td class="multi-row commentaire" rowspan="1" width="84"><div id="commt<?php echo $ids;?>"></div></td>

<td class="multi-row commentaires" rowspan="1"  width="98"><input type="text" name="commentaires" id="commentaires<?php echo $ids;?>" class="inpt_c"></td>
<td class="multi-row cumac" rowspan="1" width="46"></td>
<td class="multi-row bonus" rowspan="1" width="42"></td>
<td class="content_actions multi-row hide-print" style="text-align:center;" rowspan="1" width="57">
<span class="updt_data" onclick="return submit_form('<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/submit_data.php','<?php echo $ids;?>');">Record</span>
<input type="hidden" name="catgsid" id="catgsid" value="<?php echo $ids;?>">
<input type="hidden" name="calcul"><input type="hidden" name="id" value="0">
<div class="hidden-inputs param-input"><input type="hidden" name="vecteur1" value="20">
<input type="hidden" name="calcul" value="81"></div>
</td>
</tr>
 
</table>

<div class="updt_data prt_btn">Print</div>

<input type="hidden" name="project_id" id="project_id" value="<?php echo $project_id;?>"/>
<input type="hidden" name="tabsurls" id="tabsurls" value="<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/frontdata.php"/>
</form> 
</div>
<?php }} ?>
<div class="clr"></div>

</div>
<!-- The Modal -->
<div id="myModal" class="modal"></div></div>

<?php 
get_footer();
?>