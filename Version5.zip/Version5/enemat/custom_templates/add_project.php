<?php 
// Template name: Add Project
get_header();
session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
$current_date = date("Y-m-d H:i:s");
$siteurl = get_option("siteurl");
$redirect_addproject= get_page_by_path("add-project");
$redirectaddprojectlink = get_permalink($redirect_addproject->ID);  
?>
 <?php 
 $redirect_studenttestlist= get_page_by_path("studentlist");
 $redirectstudenttestlistlink = get_permalink($redirect_studenttestlist->ID);
//=============Paging==================//
  //===========Parent Category=============//
$SQLZONE = "SELECT * FROM wp_zone WHERE status='Active' ORDER BY zone ASC";
$rsZone = $wpdb->get_results($SQLZONE);

$SQLCATS = "SELECT * FROM wp_categories";
$rsCats = $wpdb->get_results($SQLCATS); 

$SQLsp = "SELECT * FROM `wp_ewc_selling_price` WHERE 1";
$rsSP = $wpdb->get_results($SQLsp); 

$PROJECTTYPE = "SELECT * FROM `wp_project_type` WHERE 1";
$rsPT = $wpdb->get_results($PROJECTTYPE); 

$SUBPROJECTTYPE = "SELECT * FROM `wp_project_subtype` WHERE 1";
$rsSPT = $wpdb->get_results($SUBPROJECTTYPE); 

?>
 <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
 <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/validates.js"></script>
  <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/validations.js"></script>
  <script type="text/javascript">

function myFunction() {
    var eID = document.getElementById("study_unite");
var uid = eID.options[eID.selectedIndex].getAttribute('data');
var dayVal = eID.options[eID.selectedIndex].value;
document.getElementById("price").value =uid;
document.getElementById("selectid").value =dayVal;
 }
    function ShowHideDiv() {
    var chkYes = document.getElementById("epc");
    var cpe = document.getElementById("cpe-table-block");
    cpe.style.display = chkYes.checked ? "block" : "none";
    }
    function ShowPT(chkYes1) {
    var cpe1 = document.getElementById("subpt");
    cpe1.style.display =  chkYes1.checked && chkYes1.value == 2 ? "block" : "none";
    }
    
   function validate()
{
    
var ckbox = $("input[name='projectcat[]']");
var pname=document.getElementById("project_name").value;
var zone=document.getElementById("study_zone").value;
	if(pname==""){
	    document.getElementById("project_name").focus();
	document.getElementById("project_name").style.border= "1px solid red";   
	return false;
	  }
	  if(zone==""){
document.getElementById("study_zone").focus();
	document.getElementById("study_zone").style.border= "1px solid red";   
	return false;
	  }

if (!ckbox.is(':checked')) {
alert('Select  atleast one Sectors'); // return value of checkbox checked
ckbox.focus();
return false;
} 


}   
   
   
   
   
</script>
  <div id="container">
	<div class="wraper">
<?php if(isset($_SESSION['SuccessMsg'])){?>
<div class="success-msg">
<h5><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></h5>
</div>
<?php }?>
<div class="mainform">
<form action="http://stagingenemat.apps-1and1.net/tabbar/" method="POST" id="projectfrom" name="projectfrom"  onsubmit="return validate();">
<div class="des-pro">
<h4>Description of your project</h4>
<div class="pro-name">
<label>Name of the project</label>
<input name="project_name" id="project_name" type="text">
</div>
<div class="pro-des">
<label>Description</label>
<textarea name="project_desc" id="project_desc"></textarea>
</div>
<div class="clr"></div>
</div>
<div class="clr"></div>
<div class="des-pro">
<h4>Description of your project</h4>
<div class="pro-type">
<?php if(count($rsPT)){ 
foreach($rsPT as $pt){
?>
<input type="radio" onclick="ShowPT(this)" name="project_type" <?php if($pt->id==1){ echo 'checked';} ?>  id="project_type" value="<?php echo $pt->id; ?>"><?php echo $pt->name; ?>
<?php }
} ?>
</div>
<div class="pro-type" id="subpt" style="display:none;">
<?php if(count($rsSPT)){ 
foreach($rsSPT as $Spt){
?>
<input type="radio" name="subproject_type" <?php if($Spt->id==1){ echo 'checked';} ?>  id="subproject_type" value="<?php echo $Spt->id; ?>"><?php echo $Spt->title; ?>
<?php }
} ?>
</div>
<div class="clr"></div>
<div class="climt-zone">
<label>Climate zone</label>
<select id="study_zone" name="study_zone" class="">
	<option value="">Select zone</option>
	<?php if(count($rsZone)>0){
		for($i=0;$i<count($rsZone);$i++){
	?>
		<option value="<?php echo $rsZone[$i]->id;?>"><?php echo $rsZone[$i]->zone."-".$rsZone[$i]->department;?></option>
	<?php }
	}?>
</select>

</div>
<div class="ur-sudy">
<label>Sectors concerned by your study</label>
	<?php if(count($rsCats)>0){
		for($i=0;$i<count($rsCats);$i++){
	?>
    <p><input type="checkbox" name="projectcat[]" id="ckbox" class="chkbox" value="<?php echo $rsCats[$i]->id;?>"> <?php echo $rsCats[$i]->category_name;?><br></p>
    
	<?php }
	}
	?>
</div>
<div class="cpe-con">
<label>Existence of a CPE (Energy Performance Contract)?</label>
<span><input type="radio" onclick="ShowHideDiv()" id="epc" name="epc" value="yes"> Yes</span>
<span><input type="radio" onclick="ShowHideDiv()" checked id="epc" name="epc" value="no"> No  </span>
</div>


<div id="cpe-table-block" class="dn" style="display: none;">
<br><br><table class="table_a smpl_tbl" style="text-align:center">
<tbody><tr><td>
<font style="vertical-align: inherit;">Duration of the contract (years) </font>
<img class="infobulle" src="/wp-content/uploads/2018/01/info_about.png"></td>
<td><input type="text" id="study_dureeContrat" name="study_dureeContrat"  class="inpt_e tar"></td></tr>
<tr><td><font style="vertical-align: inherit;">Energy saving goal (%) </font>
<img class="infobulle" src="/wp-content/uploads/2018/01/info_about.png"></td>
<td><input type="text" id="study_objectifEcon" name="study_objectifEcon"  class="inpt_e tar" ></td></tr>
</tbody>
</table>
</div>

<div class="clr"></div>
</div>
<div class="clr"></div>


<div class="des-pro">
<h4>Description of your project</h4>

<div class="sel-prce">
<table>
<tr>
<th>Price</th>
<th>Unit</th>
</tr>
<tr>
<td><input type="text" id="price" name="price" value=""><input type="hidden" id="selectid" name="selectid" value=""></td>
<td><select id="study_unite" name="study_unite" onchange="myFunction()" class="study_unite">
	<?php if(count($rsSP)>0){
		for($i=0;$i<count($rsSP);$i++){
	?>
<option value="<?php echo $rsSP[$i]->id; ?>" data="<?php echo $rsSP[$i]->price; ?>"><font style="vertical-align: inherit;"><?php echo $rsSP[$i]->unit; ?></font></option>
<?php }  }?>

</select></td>
</tr>
</table>
</div>
<div class="dclimr">
<p>Selling price of EWCs by default for all sectors. You can consult the monthly average price of assignment of the certificates on the site of <br/>
<a href="https://www.emmy.fr/">the National Register of EWCs</a>
</p>
</div>
<div class="clr"></div>
</div>
<input type="submit" name="submit_form" value="Enter the project">
</div>
</form>
</div>
</div><!--wrapper-->
</div><!--end-->
<?php get_footer();?>