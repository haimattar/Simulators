<style>
.mem_vid1 {
margin-top: 40px; 
overflow: hidden;
position: relative; 
vertical-align: bottom;
}
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>

<script>
      window.onload = function () {
         document.getElementById("oneopen").click();
      }      
    </script>
<?php 
ob_start();
// Template name: tabbar
get_header();
session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
$current_date = date("Y-m-d H:i:s");
$siteurl = get_option("siteurl");
$table_name = $wpdb->prefix . "projects";
$currentuserid=get_current_user_id();
$project_id = "";
$user_id = get_current_user_id();
//$cat_ds=implode(',',$_POST['projectcat']);*/
$browserid = session_id();
$sql="SELECT * FROM `wp_categories` WHERE status='Active' order by sortorder ASC " ;

if(is_user_logged_in()){
$sql="SELECT * FROM `wp_categories` WHERE status='Active' order by sortorder ASC " ;
}
else{
    $page_id = 95;
$uri = get_page_uri($page_id);
  //  $_SESSION['SuccessMsg']="<p>if you want to Use Simulator then login first <a href=\"$uri\">Login</a></p>";
$sql="SELECT * FROM `wp_categories` WHERE status='Active' order by sortorder ASC " ;
}

$strsd=$wpdb->get_results($sql);
/*
echo '<pre>';
print_r($strsd);
echo '</pre>';
echo count($strsd);
*/ ?>
<script>
function subcatchange(id,sids,url,tname){
//alert (id+url+tname);
var strs="fetchsubcat";
$('#numb'+sids+'').html('');
$('#conds'+sids+'').html('');
$('#idss'+sids+'').html('');
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"catids":id,"table_name":tname},
                url: url,
                success: function(msgs){
				//alert(msgs);
				 if($.trim(msgs)!=""){
					$('#fiche-input-holder'+sids+'').html(msgs);
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}

function subcatchangeedit(id,sids,url,tname,prjmtaid,cgsid){
//alert (id+"--"+sids+"-"+url+"-"+tname+"-"+prjmtaid);
var strs="fetchsubcat";
$('#numbedit'+sids).html('');
$('#commt'+sids).html('');
$('#catgscatgsid'+sids+'').html('');
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"catids":id,"table_name":tname,"prjmtaid":prjmtaid,"dcatid":cgsid},
                url: url,
                success: function(msgs){
			//	alert(msgs);
				 if($.trim(msgs)!=""){
					 
					$('#fiche-input-holder'+sids+'').html(msgs);
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}



function getdestinations(id,sid){
//alert (sid);
var strs="fetchdestinations";
var url= document.getElementById("tabsurls").value;
    $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"destiid":id},
                url: url,
                success: function(msg){
              // alert (msg);
			   if($.trim(msg)!=""){
					var data_array = $.parseJSON(msg);				
					$('#numb'+sid+'').html(data_array['numb']);
					$('#conds'+sid+'').html(data_array['conditions']);
					$('#idss'+sid+'').html(data_array['meta']);
				}else{
					$('#numb'+sid+'').html('');
					$('#conds'+sid+'').html('');
					$('#idss'+sid+'').html('');
				}
                },
                error: function(){
                //$('#nummb').html(msg);
                }
        });
}

function getdestinationsedit(id,sidcts,prjmetaids){
//alert (id+sidcts+prjmetaids);
var strs="fetchdestinations";
var url="<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/frontdataeditwordings.php";
$("#number_title").remove();
$("#number_link").remove();
    $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"destiid":id,"catids":sidcts,"prjmetaid":prjmetaids},
                url: url,
                success: function(msgs){
                //alert (msgs);
			   if($.trim(msgs)!=""){
					var data_array = $.parseJSON(msgs);	
					//alert(data_array['numb']);		
					$('#numbedit'+sidcts+'').html(data_array['numb']);
					$('#catgscatgsid'+prjmetaids+'').html(data_array['meta']);
					
				}else{
					$('#catgscatgsid'+prjmetaids+'').html('');
				}
                },
                error: function(){
                //$('#nummb').html(msg);
                }
        });
}


function openCity(evt, cityName,project_id,pageurls1) {
    var i, tabcontent, tablinks;
	$("#sousSecteur"+cityName+"")[0].selectedIndex = 0;
	$("#fiche"+cityName+"").css("width", 35);
	document.getElementById("fiche"+cityName+"").options.length = 0;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
	if(document.getElementById("projectsrecds"+cityName+"")){
		$("#projectsrecds"+cityName+"").show();
	}
    evt.currentTarget.className += " active";
	document.getElementById("fiche"+cityName+"").options.length = 0;
	//========Ajax Part==============//
	$.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_id":project_id,"subsector_id":cityName},
                url: pageurls1,
                success: function(msgformdatas){
					//alert(msgformdatas);
					$("#projectsrecds"+cityName+"").before(msgformdatas);
                },
                error: function(){  
                }
        });
	//========Ajax Part==============//
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

function submit_form(pageurls,secsids){
	 frmdatas = $("#frmdata"+secsids+"").serialize();
	 if(document.getElementById("sousSecteur"+secsids+"").value==""){
		alert("Please select Subsector");
		document.getElementById("sousSecteur"+secsids+"").focus() = true;
		return false;
	}
	 if(document.getElementById("fiche"+secsids+"").value==""){
		alert("Please select Designation");
		document.getElementById("fiche"+secsids+"").focus() = true;
		return false;
	}
	/*var elements = document.getElementsByName("wmetavalue[]");
	if(elements){
		for (i = 0; i < elements.length; i++) {
			if (elements[i].tagName == "INPUT") {
				if(elements[i].value.replace(/^\s+|\s+$/g,'')==""){
					alert("Please enter this value");
					elements[i].focus() = true;
					return false;
				 }
			} 
		}
	}*/
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas,
                url: pageurls,
                success: function(msgformdatas){
					//alert(msgformdatas);
					document.getElementById("fiche"+secsids+"").options.length = 0;
					$("#fiche"+secsids+"").css("width", 35);
					$("#projectsrecds"+secsids+"").before(msgformdatas);
					$('#numb'+secsids+'').html('');
					$('#conds'+secsids+'').html('');
					$('#idss'+secsids+'').html('');
					//$('#fiche'+secsids+'').val();
					$("#EventStartTimeMin").val();
					$('#sousSecteur'+secsids+'').prop('selectedIndex',0);
					$('#wordingid'+secsids+'').val('');
					document.getElementById("wmetavalue"+secsids+"").options.length = 0;		
                },
                error: function(){  
                }
        });
}

function recet_data(ids,pageurls,secsids){
	//alert(secsids);
	 frmdatas11 = $("#aa"+secsids+"").serialize();
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas11,
                url: pageurls,
                success: function(msgformdatareset){
					 //alert(msgformdatas);
				$("#treditrow"+secsids+"").replaceWith(msgformdatareset);	 
                },
                error: function(){  
                }
        });
}


function get_conditions(metaids,secsids,pageurls){
	 //alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					//alert(msgformdatareset);
					if($.trim(msgformdatareset)!="No"){
						  $(".trcpnditions"+secsids+"").remove(".trcpnditions"+secsids+"");
						//$("spcnd"+secsids+"").before(msgformdatareset);
						//$("#trconds"+secsids+"").before(msgformdatareset);
					}				
                },
				complete: function () {
					get_conditions2(metaids,secsids,pageurls);
				
				},
                error: function(){  
                }
        });
}

function get_sub_conditions(metaids,secsids,pageurls){
	 //alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					//alert(msgformdatareset);
					if($.trim(msgformdatareset)!="No"){
						  $("#trcpconmetas"+secsids+"").replaceWith(msgformdatareset);
					}				
                },
                error: function(){  
                }
        });
}
function get_conditions2(metaids,secsids,pageurls){
	 // alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					 //alert(msgformdatareset);
					if($.trim(msgformdatareset)!="No"){
						$("#trconds"+secsids+"").before(msgformdatareset);
					}				
                },
                error: function(){  
                }
        });
}

function update_form(ids,pageurls,secsids){
	//alert(secsids);
	 frmdatas11 = $("#aa"+secsids+"").serialize();
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas11,
                url: pageurls,
                success: function(msgformdatasdatas){
				//alert(msgformdatasdatas);
				$("#myModal").hide();	
				$("#trsimuledit"+ids+"").replaceWith(msgformdatasdatas);
				$("#myModal").html(''); 
                },
                error: function(){  
                }
        });
}

function delete_records(prmids,pageurlsdels,secsids){
	//alert(secsids);
	// alert(frmdatas1);	
	if(confirm("Voulez-vous supprimer?")){
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_meta_id":prmids},
                url: pageurlsdels,
                success: function(msgdeletes){
					 //alert(msgformdatas);
				//alert("Deleted");	 
				$("#trsimuledit"+prmids+"").remove();
				$("#myModal").hide();
				$("#myModal").html('');	
                },
                error: function(){  
                }
        });
	}	
}

function edit_project(project_meta_id,pageurlsmeta,subsecid,desgid,projid,catgsid){
	//alert("A");
	document.getElementById('myModal').style.display= "block";
	$.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_meta_id":project_meta_id,"subsecid":subsecid,"desgid":desgid,"projid":projid,"catgsid":catgsid},
                url: pageurlsmeta,
                success: function(msgformdatasupdates){
					//alert(msgformdatas);
					$("#myModal").html(msgformdatasupdates);
			    },
                error: function(){  
                }
        });
}

function show_pop1(){
	 document.getElementById('myModal').style.display= "block";
} 
function close1(){
	document.getElementById('myModal').style.display="none";
	$("#myModal").html('');	
}

function printpages(){
	window.print();
}

function setTwoNumberDecimal(event) {
    this.value = parseFloat(this.value).toFixed(2);
}
</script>
<?php
function get_subsector($subsector_id){
	global $wpdb;
	$SQL = "SELECT category_name FROM wp_subcategory WHERE id='".$subsector_id."'";
	$rsSubcat = $wpdb->get_results($SQL);
	$subsectors = $rsSubcat[0]->category_name;
	return $subsectors;
}

function get_designations($designation_id){
	global $wpdb;
	$SQL = "SELECT des_name FROM wp_designations WHERE id='".$designation_id."'";
	$rsDesc = $wpdb->get_results($SQL);
	$desname = $rsDesc[0]->des_name;
	return $desname;
}

function get_meta_conditions($wording_meta_wording_id,$wording_meta_id){
	global $wpdb;
	$rsconditions = "";
	$SQL = "SELECT * FROM wp_project_meta_conditions WHERE wording_meta_id='".$wording_meta_id."' AND wording_meta_wording_id='".$wording_meta_wording_id."'";
	$rsConds = $wpdb->get_results($SQL);
	if(count($rsConds)>0){
		for($i=0;$i<count($rsConds);$i++){
			$SQLCONDS = "SELECT mc_title FROM wp_meta_conditions WHERE id='".$rsConds[$i]->condition_id."'";
			$rsCondsLabel = $wpdb->get_results($SQLCONDS);
			if(!empty($rsConds[$i]->conditions_valueids)){
				$SQLCONDSVALS = "SELECT mc_title FROM wp_meta_conditions_values WHERE id='".$rsConds[$i]->conditions_valueids."'";
				$rsCondsLabelVals = $wpdb->get_results($SQLCONDSVALS);
				$mcndstitles = $rsCondsLabelVals[0]->mc_title;
			}else{
				$mcndstitles = $rsConds[$i]->consddacavle;
			}
			$rsconditions .= '<tr><td>'.stripslashes($rsCondsLabel[0]->mc_title).'</td><td>'.$mcndstitles.'</td></tr>';
		}
	}
	return $rsconditions;
}


function get_wordings($project_meta_id){
	global $wpdb;
	$SQL = "SELECT * FROM wp_project_meta_wording WHERE project_meta_id ='".$project_meta_id."'";
	$rsMeta = $wpdb->get_results($SQL);
	$meta = "";
	$meta_title = "";
	if(count($rsMeta)>0){
		$meta .= '<table width="100%">';
		for($i=0;$i<count($rsMeta);$i++){
			$SQLWording="SELECT title FROM wp_wording WHERE id ='".$rsMeta[$i]->wording."'";
			$resultWord = $wpdb->get_results($SQLWording);
			if(!empty($rsMeta[$i]->wording_meta_id)){			
				$SQWordingMeta="SELECT title FROM wp_wording_meta WHERE id ='".$rsMeta[$i]->wording_meta_id."'";
				$resultWordMeta = $wpdb->get_results($SQWordingMeta);
				$meta_title = $resultWordMeta[0]->title;
			}else {				
				$meta_title = 	$rsMeta[$i]->value;
			}
			
			$meta .= '<tr><td style="width:40px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
			'.$resultWord[0]->title.'
			</font></font>
			</td>';
			$meta .= '<td class="param-input tac" style="width:40px;">'.$meta_title.'</td></tr>';
			
			$meta_conditions = get_meta_conditions($rsMeta[$i]->id,$rsMeta[$i]->wording_meta_id);
			$meta .= $meta_conditions;
		}
			$meta .= '</table>';
	}
	return $meta;
}
?>

<div class="mem_vid1">
</div>
<div class="mainform">
<div class="wraper">
<?php
if(isset($_SESSION['SuccessMsg'])){?>
<div class="success-msg">
<h5><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></h5>
</div>
<?php }?>
<div class="tab">
<?php
if(count($strsd)>0){
    $counter=0;
foreach($strsd as $tbs)
{
$ids=$tbs->id;
if($counter==0){
 ?>
  <button class="tablinks" id="oneopen" onclick="openCity(event, '<?php echo $ids;?>','<?php echo $project_id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/get_data.php')"><?php echo $tbs->category_name; ?></button>
 <?php 
}else{?>
 <button class="tablinks" onclick="openCity(event, '<?php echo $ids;?>','<?php echo $project_id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/get_data.php')"><?php echo $tbs->category_name; ?></button>
<?php 
}
$counter = $counter+1;
}
}
?>
</div>
<?php if(count($strsd)>0){
foreach($strsd as $tbs)
{
$ids=$tbs->id;
$prime_value = $tbs->prime_value;
$prime_currency = $tbs->prime_currency;
$sqlSUBCat="SELECT * FROM `wp_subcategory` WHERE status='Active' AND  catid ='".$ids."'";
$SUBCat=$wpdb->get_results($sqlSUBCat);
?>
<div id="<?php echo $ids;?>" class="tabcontent">
  <h3><?php echo $tbs->category_name; ?></h3>
<form class="frmdatas" name="frmdata<?php echo $ids;?>" id="frmdata<?php echo $ids;?>" method="post" action="">

<table class="table_a smpl_tbl">
<thead>
<tr>
<th rowspan="2" width="115"><div class="th_wrapp">
<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sous-secteur</font></font></div></th>
<th rowspan="2" width="230px">
<div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Désignation</font></font></div></th>
<?php /*<th rowspan="2" width="120px" style="width:100px;"><div class="th_wrapp">
<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Number</font></font></div></th>*/?>

<th colspan="2"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Paramètres</font>
</font></div></th>
<th width="100" rowspan="2"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Principales conditions d'application</font></font></div></th>
<th rowspan="2" width="50"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">KWh </font></font><br>
<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">cumac</font></font></div></th>
<th rowspan="2">Prime Indicative</th>
<th class="hide-print" style="text-align:center;" rowspan="2" width="75"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Actions</font></font></div></th></tr><tr><th width="85"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Libellé</font></font></div></th>
<th width="106" style="text-align:center;"><div class="th_wrapp"><font style="vertical-align: inherit;">
<font style="vertical-align: inherit;">Valeur</font></font></div></th>
</tr></thead>
<tbody>
 <tr id="projectsrecds<?php echo $ids;?>" class="new-op parent  hide-print" data-param-count="0" data-child-class="new-op-AGRI">
<td class="multi-row sousSecteur" rowspan="1" width="93">
<select name="sousSecteur" onchange="subcatchange(this.value,'<?php echo $ids;?>','<?php echo get_template_directory_uri().'/filterajax/frontdata.php';?>','designations')" id="sousSecteur<?php echo $ids;?>"  style="max-width: 110px;">
<option selected=""></option>
<?php foreach($SUBCat as $subc){ ?>
<option value="<?php echo $subc->id; ?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $subc->category_name; ?></font></font></option>
<?php } ?>
</select><br></td>


<td class="multi-row fiche responsecat" width="166" rowspan="1">
<div id="fiche-input-holder<?php echo $ids;?>">
<select name="fiche" style="max-width: 161px;" id="fiche<?php echo $ids;?>">
<option></option>
</select>
</div>
<span class="fiche-nom"></span>
<span  id="numb<?php echo $ids;?>" class="numero-link-holder"></span>
</td>
<td colspan="2" width="83" class="botrf"><div id="idss<?php echo $ids;?>"></div></td>
<td class="multi-row cumac" rowspan="1" width="46"><div id="conds<?php echo $ids;?>"></div></td>
<td><div id="prims<?php echo $ids;?>"></div></td>
<td class="multi-row bonus" rowspan="1" width="42"></td>
<td class="content_actions multi-row hide-print" style="text-align:center;" rowspan="1" width="57">
<span class="updt_data" onclick="return submit_form('<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/submit_data.php','<?php echo $ids;?>');">Calculer ma prime </span>
<input type="hidden" name="catgsid" id="catgsid" value="<?php echo $ids;?>">
<input type="hidden" name="calcul">
<input type="hidden" name="id" value="0">
<input type="hidden" name="prime_value" id="prime_value<?php echo $ids;?>" value="<?php echo $prime_value;?>"/>
<input type="hidden" name="primecurr" id="primecurr<?php echo $ids;?>" value="<?php echo $prime_currency;?>"/>
<div class="hidden-inputs param-input"><input type="hidden" name="vecteur1" value="20">
<input type="hidden" name="calcul" value="81"></div>
</td>
</tr> 
</table>

<div class="updt_data prt_btn" onclick="printpages();">Imprimer / Enregistre</div>

<input type="hidden" name="project_id" id="project_id" value="<?php echo $project_id;?>"/>
<input type="hidden" name="tabsurls" id="tabsurls" value="<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/frontdata.php"/>
</form> 
</div>
<?php }} ?>
<div class="clr"></div>

</div>
<!-- The Modal -->
<div id="myModal" class="modal"></div></div>

<?php 

get_footer();
?>