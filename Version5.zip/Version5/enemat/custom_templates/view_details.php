<?php 
ob_start();
// Template name: Details Page
get_header();
session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
$siteurl = get_option("siteurl");
$redirect_viewdetails= get_page_by_path("view-details");
$redirectviewdetailslink = get_permalink($redirect_viewdetails->ID);
$id = isset($_GET['id'])?$_GET['id']:"";
$SQLPROJECTMETA = "SELECT * FROM wp_project_meta WHERE id='".$id."'";
$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA); 
?>
<script type="text/javascript">
	function calsresults(vals){
		//alert("A");
		var curr=$('#currency').val();
		var mwhvalue=$('#mwhvalue').val();
		var userid=$('#userid').val();
		urls = "<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/get_details.php";	
		$.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"vals":vals,"currency":curr,"mwhvalue":mwhvalue,"userid":userid},
                url: urls,
                success: function(msgs){
				 //alert(msgs);
				  obj = JSON.parse(msgs);
				 document.getElementById("amounts").innerHTML = obj.amount1;
				 document.getElementById("curriences").innerHTML = obj.amount2;
				 document.getElementById("results").innerHTML = obj.details;
				 document.getElementById("percentages").innerHTML = vals+ "%";					
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
	}
function submitfinaldata()
{
var primeval=jQuery('#primevalfinal').val();
var precarite=$('#precaritefinal').val();
var grandprecarite=$('#grandprecaritefinal').val();

var g_primeval=jQuery('#g_primevalf').val();
var g_precarite=$('#g_precaritef').val();
var g_grandprecarite=$('#g_grandprecaritef').val();


var userid=$('#userid').val();
var useremail=$('#useremail').val();
var scenarioids=$('#scenarioids').val();


var cfname=$('#cname').val();
var cfullname=$('#cfullname').val();
var email=$('#cemail').val();
var tel=$('#tel').val();
var mobil=$('#mobil').val();

var caddress=$('#caddress').val();
var postalcode=$('#postalcode').val();
var ville1=$('#ville').val();
var fiche1=$('#fiche').val();
var fichelink=$('#fichelink').val();
var pmtitle = $('#pmtitle').val();
var fichname=$('#fichname').val();

var mwhcumac=$('#mwhcumac').val();
var repartition=$('#repartition').val();
if(cfname=="")
{
	$('#cname').focus();
	return false;
}

if(cfullname=="")
{
	$('#cfullname').focus();
	return false;
}
if(email=="")
{
$('#cemail').focus();
return false;
}
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(!email.match(mailformat))
{
alert("You have entered an invalid email address!");
$('#email').focus();
return false;
}
if(tel=="")
{
	$('#tel').focus();
	return false;
}
var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
if(!tel.match(phoneno)){
alert("Le numéro de téléphone n'est pas valide.");
$('#tel').focus();
return false;
}
if(mobil=="")
{
	$('#mobil').focus();
	return false;
}
//var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
if(!mobil.match(phoneno)){
alert("Le numéro de téléphone n'est pas valide.");
$('#mobil').focus();
return false;
}
if(caddress=="")
{
$('#caddress').focus();
return false;
}
if(postalcode=="")
{
$('#postalcode').focus();
return false;
}
if(ville1==""){
$('#ville').focus();
return false;	
}

var strs="submitfinalreport";
urls = "<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/get_details.php";	
if(confirm("Voulez-vous envoyer l'offre?")){//alert('a');
		document.getElementById("loaders").style.display="block";
		document.getElementById("maindivforms").style.display="none";
		$.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"cemail":email,"cname":cfname,"cfullname":cfullname,
				"cmobil":mobil,"ctel":tel,"caddress":caddress,"postalcode":postalcode,"ville":ville1,
				"useremail":useremail,"scenarioids":scenarioids,"strs":strs,
				"scenariotitle":fichname,"fichelink":fichelink,"fiche":fiche1,"mwhcumac":mwhcumac,
				"primeval":primeval,"precarite":precarite,"grandprecarite":grandprecarite,
				"g_primeval":g_primeval,"g_precarite":g_precarite,"g_grandprecarite":g_grandprecarite,
				"userid":userid,"pmtitle":pmtitle},
                url: urls,
                success: function(msgs){
                var obj = JSON.parse(msgs);
				 if(obj.status=="success"){
				document.getElementById('abc').style.display = "none";	
				document.getElementById("loaders").style.display="none";	
				document.getElementById("successresult").innerHTML = "Scenario Information sent Successfully to Client";
				}
				if(obj.status=="error"){
				document.getElementById('abc').style.display = "block";
				document.getElementById("successresult").innerHTML = "Senario Information is not sent Successfully to Client";
				}
				},
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}
}
function div_show() {
$('#primevalfinal').val($('#primevalaj').val());
$('#precaritefinal').val($('#precariteaj').val());
$('#grandprecaritefinal').val($('#grandprecariteaj').val());
$('#repartition').val($('#percentages').html());
$('#mwhcumac').val($('#mwhvalue').val());

//-------------------------------------------
$('#fiche').val($('#pmnumbername').val());
$('#fichelink').val($('#pmnumberlink').val());
$('#fichname').val($('#pmtitle').val());
//-------------------------------------------



//-------------------------------------------
$('#useremails').val($('#useremail').val());
$('#scenarioids').val($('#scenarioid').val());
$('#userids').val($('#userid').val());

//-------------------------------------------
$('#g_primevalf').val($('#g_primevalaj').val());
$('#g_precaritef').val($('#g_precariteaj').val());
$('#g_grandprecaritef').val($('#g_grandprecariteaj').val());
document.getElementById('abc').style.display = "block";
document.getElementById('maindivforms').style.display = "block";
document.getElementById('loaders').style.display = "none";
}
function div_hide(){
document.getElementById('abc').style.display = "none";
}
</script>
<div class="main_pro">
        <div class="wraper">
        <div class="txt_pro">		
       
        </div>
        <div class="clr"></div>
        </div>
</div>
<div class="cont_form">
<div class="wraper">
<div id="abc">
<!-- Popup Div Starts Here -->
<div id="popupContact">
<!-- Contact Us Form -->
<form action="#" id="form" method="post" name="form">
<img id="close" src="<?php echo get_site_url();?>/wp-content/uploads/2018/04/close.png" onclick ="div_hide()">
<h2>Faire une offre de prime a mon client</h2>
<h4>Indiquez I'adresse du chantier et du signataire de cette offre</h4>
<hr>
<div id="loaders" style="display:none;height:auto;"><img src="<?php echo $siteurl;?>/wp-content/uploads/2018/05/loaders.gif"/></div>
<div id="maindivforms">
<div id="chantier">
<h3>Identifier votre client</h3>
<p><label>Prénom du client: </label> <input type="text" name="cname" placeholder="Name" id="cname" value=""></p>
<p><label>Nom du client: </label><input id="cfullname" name="cfullname" placeholder="Enter full Name" type="text"></p>
<p><label>Email du client: </label><input id="cemail" name="cemail" placeholder="Email" type="email"></p>
<p><label>Tel.Mobile: </label><input type="tel" placeholder="Enter mobile number.." name="mobil" id="mobil" value=""></p>
<p><label>Tel.Fixe: </label><input type="tel" placeholder="Enter tel fixe Number.." name="tel" id="tel" value=""></p>
</div>

<div id="chantier">
<h3>Localisation du chantier</h3>
<p><label>L'adresse du client: </label> <input type="text" name="caddress" id="caddress" value=""></p>
<p><label>Le code postal du client: </label> <input type="text" name="postalcode" id="postalcode" value=""></p>
<p><label>La ville du client: </label> <input type="text" name="ville" id="ville" value=""></p>
<p>
<input type="hidden" readonly name="fiche" id="fiche" placeholder="Operation number eg “bar-en-102.. Title &number”" value="">
<input type="hidden" readonly  name="fichelink" id="fichelink" value="">
<input type="hidden" readonly  name="fichname" id="fichname" value="">
</p>
<p><input type="hidden" readonly name="mwhcumac" id="mwhcumac" placeholder="Mwh cumac" value=""></p>
<p><input readonly type="hidden" name="repartition" id="repartition" placeholder="% repartition prime" value=""></p>
<!--<p><label>Date envoie : </label> <input type="text" name="dateenvoie" id="dateenvoie" placeholder="Date envoie" value=""></p>
<p><label>Date signature : </label> <input type="text" name="datesignature" id="datesignature" placeholder="Date signature" value=""></p>-->
</div>
<div id="leftpop">
<input type="hidden" value="" name="userids" id="userids">
<input type="hidden" value="" name="useremails" id="useremails">
<input type="hidden" value="" name="scenarioids" id="scenarioids">

<input type="hidden" readonly value="" name="primevalfinal" id="primevalfinal" >
<input type="hidden" readonly value="" name="precaritefinal" id="precaritefinal" >
<input type="hidden" readonly value="" name="grandprecaritefinal" id="grandprecaritefinal" >
</div>
<div id="rightpopup">
<input readonly type="hidden" value="" name="g_primevalf" id="g_primevalf" >
<input readonly value="" type="hidden" name="g_precaritef" id="g_precaritef" >
<input readonly value="" type="hidden" name="g_grandprecaritef" id="g_grandprecaritef" >
</div>
<input type="button" onclick="return submitfinaldata()"  id="submit" value="Valider">
<div id="successresult"></div>

</form>
</div>
</div>
<!-- Popup Div Ends Here -->
</div>
<?php 

$desid=$rsProdmeta[0]->designation_id;
$SQLDESIGNATION = "SELECT * FROM wp_designations WHERE id='".$desid."'";
$rsDesignation = $wpdb->get_results($SQLDESIGNATION); 
/*echo '<pre>';
print_r($rsDesignation);
echo '</pre>';
*/
$user_id=$rsProdmeta[0]->user_id;
$key = array('prime_mwhc','highprecarite','precarite');
$key1='prime_mwhc';
$key2='precarite';
$key3='highprecarite';
$single = true;
$user_info = get_userdata($user_id);
$user_email=$user_info->user_email;
 $prime_mwhc= get_user_meta( $user_id, $key1, $single );
$precarite= get_user_meta( $user_id, $key2, $single );
$highprecarite= get_user_meta( $user_id, $key3, $single );
$mwhvalue= $rsProdmeta[0]->mwh_cumac;
$prime=$mwhvalue*$prime_mwhc/1000;
$precarite=$mwhvalue*$precarite/1000;
$highprecarite=$mwhvalue*$highprecarite/1000;
?>
<div id="scenariosummary">
<?php 
$numberlink=$rsProdmeta[0]->number_link;
$number= $rsProdmeta[0]->number_title;?>
<h3><?php echo $rsDesignation[0]->des_name;?><br>
<br />
<p><a href="<?php echo $numberlink; ?>" target="_blank"><?php echo $number; ?></a></p>
</h3>
</div>
<div id="headpart"><h2>Repartissez le montant total de la prime entre vous et votre client</h2></div>
<div id="votre">
Montant* pour votre client<br/>
<br/>
<span id="amounts"><?php echo number_format($prime,0," "," ")." ".$rsProdmeta[0]->primecurr;?>
</span></div>
<div id="grade1">
Montant* gardè pour vous<br/>
<br/>
<span id="curriences">0,00 €</span>
</div>
<div id="rangebar">
<p><span class="rdtxtcol">Bougez le curseur pour modifier le % de rèpartition</span></p>
<br/>
 <form name="frmcals" id="frmcals" method="post" action="">
<input type="range" name="points" min="0" max="100" step="10" value="100" list="grade" onclick="return calsresults(this.value);"/>

  <input type="hidden" name="currency" id="currency"  value="<?php echo $rsProdmeta[0]->primecurr; ?>" />
  <input type="hidden" name="mwhvalue" id="mwhvalue"  value="<?php echo $mwhvalue; ?>" />
  <input type="hidden" name="userid" id="userid"  value="<?php echo $user_id; ?>" />
  <input type="hidden" name="useremail" id="useremail"  value="<?php echo $user_email; ?>" />
  <input type="hidden" name="scenarioid" id="scenarioid"  value="<?php echo $desid; ?>" />
  <input type="hidden" name="pmtid" id="pmtid"  value="<?php echo $rsProdmeta[0]->id; ?>" />
  <input type="hidden" name="pmtitle" id="pmtitle"  value="<?php echo $rsDesignation[0]->des_name; ?>" />
  <input type="hidden" name="pmnumberlink" id="pmnumberlink"  value="<?php echo $numberlink; ?>" />
  <input type="hidden" name="pmnumbername" id="pmnumbername"  value="<?php echo $number; ?>" />
  
  <span id="percentages">100 %</label>
</div>
<div id="results">
 <table with="100%"><tbody>
 
<tr><td>&nbsp;</td>
<td>Pour votre client</td>
<td>Pour votre</td></tr>
<tr><td>Prime sans precarite</td>
<td><input readonly value="<?php echo number_format($prime,0," "," ")." ".$rsProdmeta[0]->primecurr;?>" name="primevalaj" id="primevalaj" ></td>
<td><input readonly value="<?php echo $rsProdmeta[0]->primecurr;?>" name="g_primevalaj" id="g_primevalaj" ></td></tr>
<tr><td>Prime avac precarite (avec justificatif)</td>
<td><input readonly value="<?php echo number_format($precarite,0," "," ")." ".$rsProdmeta[0]->primecurr;?>" name="precariteaj" id="precariteaj" ></td>
<td><input readonly value="<?php echo $rsProdmeta[0]->primecurr;?>" name="g_precariteaj" id="g_precariteaj" ></td></tr>
<tr><td>Prime grand avac precarite (avec justificatif)</td>
<td><input readonly value="<?php echo number_format($highprecarite,0," "," ")." ".$rsProdmeta[0]->primecurr;?>" name="grandprecariteaj" id="grandprecariteaj" ></td>
<td><input readonly value="<?php echo $rsProdmeta[0]->primecurr;?>" name="g_grandprecariteaj" id="g_grandprecariteaj" ></td>
</tr>				
</tbody></table>
<br/>
<p>La prime sera mulitplièè par la suite en function du revenue de votre client</p>
</div>
<input type="button" name="submitval" id="submitval" onclick="div_show()" value="Faire cette offre à mon client">
<br/>
<div id="successresult"></div>
</form>
</div>
<?php 
get_footer();
?>