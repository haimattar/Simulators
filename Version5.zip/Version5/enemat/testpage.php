





<?php

/* Template Name: testpage*/ 

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Untitled Document</title>
<link href="<?php echo get_template_directory_uri(); ?>/css/stylenew.css" rel="stylesheet" type="text/css" />
<link href="<?php echo get_template_directory_uri(); ?>/css/responsivenew.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Varela+Round&amp;subset=hebrew,latin-ext,vietnamese" rel="stylesheet"> 
</head>
<body>   
     <div class="header">
        <div class="wraper">
          <div class="logo">
             <img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/logo.jpg" alt="logo">
		  </div>
         <div class="search_box">
             <form id="tfnewsearch" method="get" >
			  <input type="text" placeholder="Vous cherchez quelque chose ?" name="search" id="main">
			  <input type="submit" value="" id="autocomplete">
			 </form>
		  </div>
		  <div class="seconneters">
	<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/elip.png" alt="">
	<h3>Se connecter</h3>
	</div>
    <div class="menuicon" id="abc">
		  <div class="bar1"></div>
		  <div class="bar2"></div>
		  <div class="bar3"></div>
    </div>
	<div class="nav" id="navigation">
	  <ul>
	      <li><a href=""> Accueil </a></li>	 
		  <li><a href=""> à propos </a></li>	   
		  <li><a href="">Typologie</a></li>	   
		  <li><a href=""> Infos & Actus </a></li>	 
		  <li><a href="">Contacts </a></li>	   
		  <li><a href="">S’inscrire</a></li>
	  </ul>

	</div>
	
	
	  <br class="clr">
         </div>
  </div><!--header-->
<div class="simu_primese">
  <div class="wraper">
    <h1>Simulateur Prime énergie</h1>
      <div class="simular_sec1">
	  <img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/smartphone-1.png" class="nerwsec">
	   <h3>Secteur concerné par votre étude :</h3>
	      <ul>
				<li>
					   <div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu1.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu11.png" class="img-top" alt="Card Front">
					</div>
                   <h4>Agricole</h4></li>
				<li>
				      <div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu2.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu12.png" class="img-top" alt="Card Front">
					</div>
					<h4>Bâtiment <br/>Résidentiel</h4>
					</li>
				<li>
				<div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu3.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu13.png" class="img-top" alt="Card Front">
					</div>
					<h4>Bâtiment <br/>Tertiaire</h4></li>
				<li>
				<div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu4.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu14.png" class="img-top" alt="Card Front">
					</div>
					<h4>Industrie</h4></li>
				<li>
				<div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu5.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu15.png" class="img-top" alt="Card Front">
					</div>
					<h4>Réseaux</h4></li>
				<li>
				<div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu6.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu16.png" class="img-top" alt="Card Front">
					</div>
					<h4>Transports</h4></li>
	      </ul>
	 </div>
<!--2 section-->	 
  <div class="simular_sec1 simulater12">
	  <img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/smartphone-2.png" class="nerwsec">
	   <h3>Sous secteur :</h3>
	      <ul>
				<li class="newcarse">
					   <div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu211.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu21.png" class="img-top" alt="Card Front">
					</div>
                   <h4>Chauffage</h4></li>
				<li>
				      <div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu22.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu221.png" class="img-top" alt="Card Front">
					</div>
					<h4>Isolation</h4>
					</li>
				<li>
				<div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu23.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu231.png" class="img-top" alt="Card Front">
					</div>
					<h4>LED & autres</h4></li>
				<li>
				<div class="card">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu24.png" alt="Card Back">
						<img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/simu241.png" class="img-top" alt="Card Front">
					</div>
					<h4>Services</h4></li>
				
	      </ul>
		  <div class="dexbnati">
		     <h3>Désignation :</h3>
	 <select value="">
		 <option value="bc" class="opwrap">
		Pompe à chaleur collective à absorption de type air/eau </option>
		  <option value="">Lorem Ipsum</option>
		  <option value="">Lorem Ipsum</option>
		  <option value="">Lorem Ipsum</option>
     </select> 
		  </div>
	 </div>	 
	 
	<!--3 section-->	 
  <div class="simular_sec1 simular_sec3">
	  <img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/smartphone-3.png" class="nerwsec">
	  		  <div class="dexbnati secsimu2">
			
		     <h3>Type de logement :</h3>
	 <select value="">
		  <h3><option value="">Maison individuelle</option></h3>
		  <option value=""><h3>Lorem Ipsum</h3></option>
		  <option value=""><h3>Lorem Ipsum</h3></option>
		  <option value=""><h3>Lorem Ipsum</h3></option>
     </select> 
		  </div>
		  		  <div class="dexbnati secsimu1">
		     <h3>Efficacité énergetique saisonnière (ns) :</h3>
	 <select value="">
		  <h3><option value="">100% < ns < 120%</option></h3>
		  <option value=""><h3>Lorem Ipsum</h3></option>
		  <option value=""><h3>Lorem Ipsum</h3></option>
		  <option value=""><h3>Lorem Ipsum</h3></option>
     </select> 
		  </div>    
		  		  <div class="dexbnati secsimu4">
		     <h3>Surfface chauffée (m²) :</h3>
	 <select value="">
		  <h3><option value="">90 < S < 110</option></h3>
		  <option value=""><h3>Lorem Ipsum</h3></option>
		  <option value=""><h3>Lorem Ipsum</h3></option>
		  <option value=""><h3>Lorem Ipsum</h3></option>
     </select> 
		  </div> <br class="clr"/>  
<div class="dexbnati nessesimu">
		     <h3>Zone climatique :</h3>
			 <p>Cliquez sur la carte <br/>ou sur les boutons ci-dessous</p>
	 <img src="http://stagingenemat.enemat.fr/wp-content/uploads/2018/06/map.png" alt="map">	 
	 <div class="dexbnatiboxx">
	       <a href="#">H1</a><a href="#">H2</a><a href="#" class="crrents">H3</a>
	 </div>
	 <br class="clr"/>
 </div>   
   
</div>
<span class="hrbor"></span>
<div class="cond_applica">
		  <h3>Conditions d’application :</h3>
		  <ul>
		      <li>Sur réseau hydraulique de chauffage ou d'eau chaude sanitaire existant</li>
			  <li>Situé hors du volume chauffé</li>
			  <li>Pour un système de chauffage collectif existant maintenu en température (bouclé ou tracé)</li>
			  <li>Non isolé ou d'isolation de classe ≤ 2</li>
			  <li>Avec isolant de classe ≥ 3</li>
			  <li>Avec contrôle des travaux a posteriori par un organisme d'inspection</li>
	</ul>
		  <h4 class="saproject"> <a href="#">Demander ma prime</a> </h4>
		   <br class="clr"/>
	 </div>	 
<span class="hrbor"></span>
	 
	<div class="singtextsre">
       <h1>Valeur de ma Prime </h1>
	   <div class="singhemain">
	     <div class="singhetxt">
		   <h4>Pompe à chaleur collective à absorption de type air/eau ou eau/eau</h4>
		   <a href="#">BAR-EN-101</a> <br class="clr"/>
		    <div class="singhetxt_sec">
				 <h2>445 €</h2>
				 <h5>économie d’énergie :<span>33 500 kWh Cumac*</span></h5>
				 <p>Bâtiment résidentiel<br/>Maison individuelle<br/>Thermique<br/>90 m² <br/>Zone H3</p>
		   </div>
		  </div>
		  <h3> 
	        <a href="#">Modifier</a>
	        <a href="#" class="crrents">Demander ma prime</a>
			<br class="clr"/>
	 </h3>
		   </div>
	

	 </div>
	 
	 <span class="hrbor"></span>
	 </div><!--ends wraper-->	 	 
 </div><!--ends simu_primese-->	
    <div class="reparti_moninse"> 
	<div class="wraper">
<div class="reparti_montant">

        <h1>Repartissez le montant total de la prime </h1>
        <div class="reparti_mon_text">
		   <ul>
		       <li>
				     <h3>Montant pour votre client :</h3>
				     <h4>178€</h4>
	           </li>
		       <li>
				     <h3>Montant gardé pour vous :</h3>
				     <h4>267 €</h4>
	           </li>
		  </ul>
	<div class="partition_sec">
       <h3>Bougez le curseur pour modifier le % de répartition <span>60%</span></h3>
	   <input type="range" name="points" class="newwcoverange" min="0" max="100" step="10" value="100" list="grade" onclick="return calsresults(this.value);"/>

	   
    </div>	
		<div class="prime_sec">
          <table border="0"cellpadding="0" cellspacing="0">

<tr>
  <th class="newrcvse"></th>
  <th id="a2" axis="expenses">Pour votre client</th>
  <th id="a3" axis="expenses"> 	Pour vous </th>
</tr>
<tr>
  <td class="newrcvse"></td>
 <td><td>
  <td></td>

</tr>
<tr>
  <td class="newrcvse">Prime sans precarité     </td>
  <td> <a>455€</a></td>
  <td><a>455€</a></td>

</tr>
<tr>
  <td class="newrcvse">Prime avac precarite (avec justificatif)      </td>
  <td> <a>455€</a></td>
  <td><a>455€</a></td>

</tr>
<tr>
  <td class="newrcvse">Prime grand avac precarite (avec justificatif)    </td>
 <td> <a>455€</a></td>
  <td><a>455€</a></td>

</tr>
<tr>
  <td class="newrcvse">&nbsp;</td>
 <td>&nbsp;<td>
  <td>&nbsp;</td>

</tr>
</table>
		
	      </div>		
		
		
		</div><!--ends reparti_mon_text-->	
	 <h4 class="saproject newsaproh"> <a href="#" id="myBtn">Faire cette offre à mon client</a> </h4>	
 <div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <div class="pop_secttxt">
 <h3>Faire une offre de prime à mon client</h3>
	  <div class="pop_sect12">
	    
		 <div class="pop_setxtnede"> 
		 
		 <form id="tfnewsearch" method="get">
		 
		 <h5> Identifier votre client :</h5>
		    <p>
			<input type="text" name="" placeholder="Prénom" id="prenom">
			<input type="text" name="" placeholder="Nom" id="Nom">
			</p>
				<input type="email" name="" placeholder="Email" id="email">
		  <p>
			<input type="text" name="" placeholder="Téléphone mobile" id="telmob">
			<input type="text" name="" placeholder="Téléphone fixe" id="telfex">
			</p>
			
			 <h5>Localisation du chantier :</h5>
		   <input type="addresdu" name="" placeholder="Adresse du client" id="email">
		  <p>
			<input type="text" name="" placeholder="Code postal" id="telmob">
			<input type="text" name="" placeholder="Ville" id="telfex">
			</p>
			 
		 </form>
		 
	  </div>
	</div>
	 <input type="submit" value="Valider" id="valider">
    </div>  
  </div>

</div>
  

</div>
 </div><!--ends reparti_montant-->	
 </div>
  
  
  
  
  
  
  

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
jQuery(document).ready(function() {

jQuery("#abc").click(function () {

          jQuery("#abc").toggleClass("change");
        jQuery('#navigation').toggle();
});
});
</script>
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</body>
</html>
