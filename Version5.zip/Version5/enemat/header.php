<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	 <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>




<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset >= 1) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>
<div class="header sticky" id="myHeader">
	<div class="wraper">
		<div class="logo">
			<a href="<?php echo get_site_url(); ?>/accueil/"><!--<img src="<?php echo get_template_directory_uri(); ?>/images/logo.png">-->
			 <?php $custom_logo_id = get_theme_mod( 'custom_logo' );
                $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                if ( has_custom_logo() ) {
                echo '<img src="'. esc_url( $logo[0] ) .'">';
                } else {
                echo '<h1>'. get_bloginfo( 'name' ) .'</h1>';
                } ?>
			</a>
		</div>
		<div class="nav">
			<?php wp_nav_menu( array( 'theme_location => Header menu' ) ); ?>
		</div>
	<div class="clr"></div>
	</div>
</div>