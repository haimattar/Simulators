<?php 
// Template name: Simualtors Demo
get_header(1);
session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
$current_date = date("Y-m-d H:i:s");
$siteurl = get_option("siteurl");
$redirect_addproject= get_page_by_path("add-project");
$redirectaddprojectlink = get_permalink($redirect_addproject->ID);

$table_name = $wpdb->prefix . "projects";
$currentuserid=get_current_user_id();
$project_id = "";
$user_id = get_current_user_id();
//$cat_ds=implode(',',$_POST['projectcat']);*/
$browserid = session_id();
$SQL="SELECT * FROM `wp_categories` WHERE status='Active' order by category_name ASC " ;

if(is_user_logged_in()){
$SQL="SELECT * FROM `wp_categories` WHERE status='Active' order by category_name ASC " ;
}
else{
    $page_id = 95;
$uri = get_page_uri($page_id);
  //  $_SESSION['SuccessMsg']="<p>if you want to Use Simulator then login first <a href=\"$uri\">Login</a></p>";
$SQL="SELECT * FROM `wp_categories` WHERE status='Active' order by category_name ASC " ;
}

$rsTabs=$wpdb->get_results($SQL);
//echo "<pre>";
//print_r($strsd);
function get_icons($caegory_name){
	$siteurl = get_option("siteurl");
	switch($caegory_name){
	 case "Agricole":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-agriculture.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-agriculture-2" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Bâtiment Résidentiel":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Bâtiment Tertiaire":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Industrie":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-industrie.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-industrie-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Réseaux":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-reseaux.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-reseaux-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Transports":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-transport.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-transport-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	}
}
?>
<script type="text/javascript">
	function show_step1(catids,prime_value,prime_currency,pageurls){//alert("a1");	    
		if(document.getElementById("step3")){
			document.getElementById("step3").style.display="none";
		}
		if(document.getElementById("numtitles")){
			document.getElementById("numtitles").style.display="none";
		}
		if(document.getElementById("step4")){
			document.getElementById("step4").style.display="none";
		}
		if(document.getElementById("step5")){
			document.getElementById("step5").style.display="none";
		}
		if(document.getElementById("step6")){
			document.getElementById("step6").style.display="none";
		}
		if($('.navlists li').hasClass('active')){
			$('.navlists li').removeClass('active');			
		}
		if(!$("#step1").hasClass("simulater12")){
	       $("#step1").addClass("simulater12");
	     
	    }
	    if($("#step2").hasClass("simulater12")){
	       $("#step2").removeClass("simulater12");
	     
	    }
	    if($("#step3").hasClass("simulater12")){
	       $("#step3").removeClass("simulater12");
	     
	    }
		if(document.getElementById("fiche")){
			$('#fiche option').remove();
		}
		document.getElementById("catgsid").value = catids;
		document.getElementById("prime_value").value = prime_value;
		document.getElementById("primecurr").value = prime_currency;
		
		$("#catsli-"+catids+"").addClass('active');
		 $.ajax({
                type: "POST",
                 data: {"catids":catids},
                url: pageurls,
                success: function(msgs){
				//alert(msgs);
				 if($.trim(msgs)!=""){
				    if($("#step1").hasClass("simulater12")){
	                    $("#step1").removeClass("simulater12");
	                    $("#step2").addClass("simulater12");
	             } 
					document.getElementById("step2").style.display="block"; 
					$('#step2').html(msgs);
					//var scrollPos1 =  $("#step2").offset().top;
					//$(window).scrollTop(scrollPos1);
					$('html, body').animate({scrollTop:$('#step2').position().top}, 'slow');
					$('#step2').focus();
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
	}
	
	function active_zone(metaids){//alert(metaids);
		if($('.dexbnatiboxx a').hasClass('crrents')){
			$('.dexbnatiboxx a').removeClass('crrents');
		}
		$('#zone-'+metaids+'').addClass('crrents');
		document.getElementById("wmetavalues").value = metaids;
	}
	
	function show_designations(subcatids,pageurls){//alert("a1");
		if(document.getElementById("step3")){
					document.getElementById("step3").style.display="none";
		}
		if(document.getElementById("numtitles")){
				document.getElementById("numtitles").style.display="none";
		}
		if(document.getElementById("step4")){
					document.getElementById("step4").style.display="none";
		}
		if(document.getElementById("step5")){
					document.getElementById("step5").style.display="none";
		}
		if(document.getElementById("step6")){
					document.getElementById("step6").style.display="none";
		}
		if(document.getElementById("fiche")){
			$('#fiche option').remove();
		}
		 if(subcatids!=""){
			if($('.subnavlists li').hasClass('active_sub')){
				$('.subnavlists li').removeClass('active_sub');			
			}
			$("#subcats-"+subcatids+"").addClass('active_sub');
			document.getElementById("sousSecteur").value = subcatids;
			 $.ajax({
					type: "POST",
					 data: {"subcatids":subcatids},
					url: pageurls,
					success: function(msgs1){
					//alert(msgs);
					 if($.trim(msgs1)!=""){
						document.getElementById("designations").style.display="block"; 
						$('#designations').html(msgs1);
					 }
					},
					error: function(){
					 //$('.responsecat').html(msgs);
					}
			});
		}else{
			document.getElementById("designations").style.display="none";
			if(document.getElementById("step4")){
				document.getElementById("step4").style.display="none";
			}
			if(document.getElementById("step5")){
				document.getElementById("step5").style.display="none";
			}
			if(document.getElementById("step6")){
				document.getElementById("step6").style.display="none";
			}
		}
	}
	function show_step2(desgid,pageurls){//alert("a1");
		if(document.getElementById("step5")){
				document.getElementById("step5").style.display="none";
		}
		if(document.getElementById("step6")){
				document.getElementById("step6").style.display="none";
		}
		
		if($("#step1").hasClass("simulater12")){
	       $("#step1").removeClass("simulater12");
	     
	    }
	    if($("#step2").hasClass("simulater12")){
	       $("#step2").removeClass("simulater12");
	     
	    }
		var current = $('#fiche').val();
		if (current!= '') {
				$('#fiche').css('color','#2686c6');
		} else {
			  $('#fiche').css('color','#bfbfbf');
		}
		if(desgid!=""){			
			 $.ajax({
					type: "POST",
					 data: {"desgid":desgid},
					url: pageurls,
					success: function(msgs2){
					//alert(msgs);
					 if($.trim(msgs2)!=""){
						var datas = $.parseJSON(msgs2);	
					    if($("#step1").hasClass("simulater12")){
	                     $("#step1").removeClass("simulater12");	                     
	                    }  
	                     if($("#step2").hasClass("simulater12")){
    	                    $("#step2").removeClass("simulater12");
    	                }
    	                $("#step3").addClass("simulater12");
						document.getElementById("numtitles").style.display="block";
						document.getElementById("step3").style.display="block";
						//document.getElementById("step4").style.display="block";
						$('#numtitles').html(datas['designations']);
						$('#step3').html(datas['meta']);
						//var scrollPos2 =  $("#step3").offset().top;
						//$(window).scrollTop(scrollPos2);
						$('html, body').animate({scrollTop:$('#step3').position().top}, 'slow');
						$('#step3').focus();
					 }
					},
					error: function(){
					 //$('.responsecat').html(msgs);
					}
			});
		}else{
			document.getElementById("step3").style.display="none";
			if(document.getElementById("numtitles")){
				document.getElementById("numtitles").style.display="none";
			}
			document.getElementById("step4").style.display="none";
			if(document.getElementById("step5")){
				document.getElementById("step5").style.display="none";
			}
			if(document.getElementById("step6")){
					document.getElementById("step6").style.display="none";
			}
		}	
	}
	
	function get_conditions(metaids,secsids,pageurls){
	 //alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					//alert(msgformdatareset);
					if(msgformdatareset!="No"){
						  $(".trcpnditions"+secsids+"").remove(".trcpnditions"+secsids+"");
						//$("spcnd"+secsids+"").before(msgformdatareset);
						//$("#trconds"+secsids+"").before(msgformdatareset);
					}				
                },
				complete: function () {
					get_conditions2(metaids,secsids,pageurls);
				
				},
                error: function(){  
                }
        });
}

function get_sub_conditions(metaids,secsids,pageurls){
	 //alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					//alert(msgformdatareset);
					if(msgformdatareset!="No"){
						  $("#trcpconmetas"+secsids+"").replaceWith(msgformdatareset);
					}				
                },
                error: function(){  
                }
        });
}
function get_conditions2(metaids,secsids,pageurls){
	 // alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					 //alert(msgformdatareset);
					if(msgformdatareset!="No"){
						$("#trconds"+secsids+"").before(msgformdatareset);
					}				
                },
                error: function(){  
                }
        });
}

function submit_form(pageurls,secsids){
	 frmdatas = $("#frmdata").serialize();	 
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas,
                url: pageurls,
                success: function(msgformdatas){
					//alert(msgformdatas);
					 document.getElementById("step5").style.display="block";
					 $("#step5").html(msgformdatas);
					 //var scrollPos3 =  $("#step5").offset().top;
					 //$(window).scrollTop(scrollPos3);
					 $('html, body').animate({scrollTop:$('#step5').position().top}, 'slow');
					 $('#step5').focus();
					 	
                },
                error: function(){  
                }
        });
}
function show_prime_details(prmetaid,pageurls){//alert("a1");
		 $.ajax({
					type: "POST",
					 data: {"prmetaid":prmetaid},
					url: pageurls,
					success: function(msgs5){
					//alert(msgs);
					 if($.trim(msgs5)!=""){
						document.getElementById("step6").style.display="block"; 
						$('#step6').html(msgs5);
						//var scrollPos4 =  $("#step6").offset().top;
						//$(window).scrollTop(scrollPos4);
						$('html, body').animate({scrollTop:$('#step6').position().top}, 'slow');
						$('#step6').focus();
					 }
					},
					error: function(){
					 //$('.responsecat').html(msgs);
					}
			});		  
}
</script>
 <div class="simu_primese">
  <div class="wraper">
    <h1>Simulateur Prime énergie</h1>
	<form class="frmdatas" name="frmdata" id="frmdata" method="post" action="">
      <div id="step1" class="simular_sec1 simulater12">
	  <img src="<?php echo $siteurl;?>/wp-content/uploads/2018/06/smartphone-1.png" class="nerwsec">
	   <h3>Secteur concerné par votre étude :</h3>
		<?php if(count($rsTabs)>0){?>	
		 <ul class="navlists">
			<?php foreach($rsTabs as $tbs){
				$category_name = ucwords($tbs->category_name);
				$ids=$tbs->id;
				$prime_value = $tbs->prime_value;
				$prime_currency = $tbs->prime_currency;?>
				<li id="catsli-<?php echo $ids;?>" onclick="return show_step1('<?php echo $ids;?>','<?php echo $prime_value;?>','<?php echo $prime_currency;?>','<?php echo get_template_directory_uri().'/ajax_scripts/get_subcats.php';?>');">
					   <div class="card" id="catimages-<?php echo $ids;?>">
					    <?php $images = get_icons($category_name);
							echo $images;
						?>						
					</div>
                   <h4 id="catheading-<?php echo $ids;?>"><?php echo str_replace(" ","<br/>",$category_name); ?></h4></li>
			<?php }?>		
	      </ul>
		  <?php }?>
	 </div>
<!--2 section-->
	<input type="hidden" name="catgsid" id="catgsid" value="">
	<input type="hidden" name="prime_value" id="prime_value" value=""/>
	<input type="hidden" name="primecurr" id="primecurr" value=""/>
	<input type="hidden" name="project_id" id="project_id" value="<?php echo $project_id;?>"/>	
  <div id="step2" class="simular_sec1 simulater12" style="display:none;"></div>	 
	 
	<!--3 section-->	 
  <div id="step3" style="display:none;"></div>
  <div id="step5" style="display:none;"></div>
   </form>
  <div id="step6" style="display:none;"></div>
	 </div><!--ends wraper-->	 	 
 </div><!--ends simu_primese--> 

 <div class="clr"></div>
<?php get_footer(1);?>