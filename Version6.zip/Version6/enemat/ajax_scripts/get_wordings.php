<?php
	   //  echo "<pre>";
	   // print_r($_POST);exit;
	@session_start();   
	$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
	require_once( $parse_uri[0] . 'wp-load.php' );
	define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
	global $wpdb;
	$desgid = $_POST['desgid'];
	$siteurl = get_option('siteurl');
	$SQLDESIG="SELECT * FROM `wp_designations` WHERE status='Active' AND  id ='".$desgid."'";
	$rsDesignation=$wpdb->get_results($SQLDESIG);
	$catids = $rsDesignation[0]->catid;
	//$SQL="SELECT * FROM wp_wording WHERE desg_id ='".$desgid."' AND title NOT LIKE '%Zone climatique%' ORDER BY `desg_id` ASC";
	
	$SQL="SELECT * FROM wp_wording WHERE desg_id ='".$desgid."' ORDER BY `desg_id` ASC";
	$resultWord = $wpdb->get_results($SQL);

	$SQLZONE="SELECT * FROM wp_wording WHERE desg_id ='".$desgid."' AND title LIKE '%Zone climatique%' ORDER BY `title` ASC";
	$resultWordZONE = $wpdb->get_results($SQLZONE);
	//print_r($resultWordZONE);
	$meta = "";
	$meta1 = "";
	$meta2 = "";
	function rspecial($string,$rp = '') {
	$string = str_replace(' ', ',', $string);
	return preg_replace('/[^A-Za-z0-9\-]/', $rp, $string);
	}
	 
	$meta .= '<div id="step31" class="simular_sec1 simular_sec3">
	  <img src="'.$siteurl.'/wp-content/uploads/2018/06/smartphone-3.png" class="nerwsec">
				 
				  <div class="dexbnati secsimu2 newsedrmaint">';				 
					if(count($resultWord)>0 ){
		$meta .= '<table cellpadding="0" cellspacing="0" border="0" align="center" style="width:100%;">';
		foreach($resultWord as $spt){
			$wmts=$spt->id;
			if($spt->otherparts=="No"){
			$SQwordMeta="SELECT * FROM wp_wording_meta WHERE word_id ='".$wmts."' ORDER BY `id` ASC,is_cond ASC";
			$WMeta = $wpdb->get_results($SQwordMeta);
			$meta .= '<tr><td>
			<h3>'.stripslashes($spt->title).'</h3>
			<input type="text" name="wordingid[]" id="wordingid'.$catids.'" value="'.$wmts.'" style="display:none;"/>
			</td>';
			$meta .= '<td class="param-input tac">';
			if(!empty($WMeta)){
			$counter_meta = 0;
			$counter_meta_conds = 0;
			$first_conditions = "";
			$condionsvals = "";
			$subcondionsvals = "";
			 $meta .= '<select name="wmetavalue[]" id="wmetavalue'.$wmts.'" onchange=\'return  get_conditions(this.value,"'.$catids.'","'.$siteurl.'/wp-content/themes/enemat/ajax_scripts/conditions_data.php");\'>';
			foreach($WMeta as $wmr){
				$counter_meta = $counter_meta+1;
				//====Check Meta Conditions==========//
				//If Meta Conditions Exists//
				//If Meta Conditions Exists//
				if($counter_meta==1){
					$meta_id = $wmr->id;
					$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$meta_id."' ORDER BY is_cond ASC";
					$rsConditions = $wpdb->get_results($SQLCOND);
					$first_conditions = "1";
					if(count($rsConditions)>0){
				 for($x=0;$x<count($rsConditions);$x++){
					if($rsConditions[$x]->is_cond=="Yes"){ 
						$cond_id = $rsConditions[$x]->id;
						$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
						$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
						$condionsvals = '<select name="condition_valuesid[]" id="condition_valuesid" onchange=\'return  get_sub_conditions(this.value,"'.$catids.'","'.$siteurl.'/wp-content/themes/enemat/ajax_scripts/subconditions_data.php");\'>';
						 for($aa=0;$aa<count($rsCondValues);$aa++){
							$counter_meta_conds = $counter_meta_conds+1;
							if($counter_meta_conds ==1){
								$SQLSUBCONDS = "SELECT * FROM wp_cond_meta_cond WHERE cmcond_id='".$rsCondValues[$aa]->id."'";
								$rsSubconds = $wpdb->get_results($SQLSUBCONDS);
								if(count($rsSubconds)>0){								
									 for($xx=0;$xx<count($rsSubconds);$xx++){						
										$SQLCONDMETAVALUESVALUES = "SELECT * FROM wp_cond_meta_cond_values WHERE cmcond_id='".$rsSubconds[$xx]->id."'";
										$rsSubcondMetas = $wpdb->get_results($SQLCONDMETAVALUESVALUES);
										if(count($rsSubcondMetas)>0){
											$subcondionsvals = '<select name="subcondition_valuesid" id="subcondition_valuesid">';
											for($yy=0;$yy<count($rsSubcondMetas);$yy++){
												$subcondionsvals .= '<option value="'.$rsSubcondMetas[$yy]->id."-".$rsSubcondMetas[$yy]->cmcv_value."-".$rsSubcondMetas[$yy]->cond_id."-".$rsSubcondMetas[$yy]->subconds_id.'">'.$rsSubcondMetas[$yy]->cmcv_title.'</option>';
											}
											$subcondionsvals .= '</select>';	
										}
										 $meta2 .= '<tr id="trcpconmetas'.$catids.'" class="trcpnditions'.$catids.'"><td><h3>'.$rsSubconds[$xx]->cmc_title.'</h3>
										 <input type="hidden" name="subcondition_id" id="subcondition_id'.$catids.'" value="'.$rsSubconds[$xx]->id.'" style="display:none;"/>
										 </td><td class="param-input tac">'.$subcondionsvals.'</td></tr>';
									}
								}
							}else{
								$meta2 .= "";
							}
							$condionsvals .= '<option value="'.$rsCondValues[$aa]->id."-".$rsCondValues[$aa]->mc_value.'">'.$rsCondValues[$aa]->mc_title.'</option>';
						 }
						$condionsvals .= '</select>
						<input type="text" name="condition_id[]" id="condition_id'.$catids.'" value="'.$rsConditions[$x]->id.'" style="display:none;"/>';				
						
						$meta1 .= '<tr class="trcpnditions'.$catids.'"><td><h3>'.$rsConditions[$x]->mc_title.'</h3></td><td class="param-input tac">'.$condionsvals.'</td></tr>';
						if($x==0){
							$meta1 .= '<tr id="trconds0-'.$catids.'"style="display:none;"><td colspan="2"></td></tr>';
							$meta1 .= $meta2; 
						}
											
				 }
				 if($rsConditions[$x]->is_cond=="No"){
					if($rsConditions[$x]->otherparts=="No"){
					 $condsvaltext = '<input type="text" name="condition_text" id="condition_text"/>';
					 $meta1 .= '<tr class="trcpnditions'.$catids.'"><td><h3>'.$rsConditions[$x]->mc_title.'</h3></td><td class="param-input tac">'.$condsvaltext.'</td></tr>';
					 $meta1 .= '<input type="hidden" name="condition_textid" id="condition_textid'.$catids.'" value="'.$rsConditions[$x]->id.'"/>';	
					}
					if($rsConditions[$x]->otherparts=="Yes"){
					 $meta1 .= '<tr class="trcpnditions'.$catids.'" style="display:none;"><td><input type="hidden" name="partssub" id="partssub'.$catids.'" value="'.$rsConditions[$x]->mc_value.'"/>
					 <input type="hidden" name="partssubopt" id="partssubopt'.$catids.'" value="'.$rsConditions[$x]->optypes.'"/></td></tr>';
					 }
				 }
				 
				}
				}	
				}
				//====Check Meta Conditions==========//
		
	 $wmrval=rspecial($wmr->value,'.'); //  output: _index_id_666
				
			$meta .=  '<option  value="'.$wmr->id.'-'.$wmrval.'-'.$wmr->is_cond.'">'.stripslashes($wmr->title).'</option>';
			}
			$meta .= '</select>';
			}else{
			$meta .= '<input type="text" name="wmetavalue[]" id="wmetavalue'.$catids.'"  step="1" value=""  min="0" >';
			}		 
			$meta .= '</td></tr>';
			}else if($spt->otherparts=="Yes"){
				 $meta .= '<input type="text" style="display:none;"name="wpartssub[]" id="wpartssub'.$catids.'" value="'.$spt->word_value.'"/>
					 <input type="hidden" name="wpartssubopt" id="wpartssubopt'.$catids.'" value="'.$spt->optypes.'"/>';
			}
			}
			if(!empty( $first_conditions)){
					$meta .= $meta1;
			}
			$meta .= '<tr id="trconds'.$catids.'" style="display:none;"><td class="sav_spcl" colspan="2"></td></tr></table>';
			} 
			$meta .= '</div>
			   
		<br class="clr"/> 		 
		</div>';
		$meta .= '<div id="step4">
<span class="hrbor"></span>
<div class="cond_applica">
		  <h3>Conditions d’application :</h3>
		  <ul>
		      <li>'.$rsDesignation[0]->conditions.'</li>
			  
	</ul>';
	  $target = get_site_url()."/wp-content/plugins/simulate/uploads/".$rsDesignation[0]->number;
	  $meta .= '<input type="hidden" name="number_title" id="number_title" value="'.$rsDesignation[0]->number.'"/>
	   <input type="hidden" name="number_link" id="number_link" value="'.$target.'" target="_blank"/>
		<input type="hidden" name="conditions" id="conditions" value="'.stripslashes($rsDesignation[0]->conditions).'"/> 
		  <h4 class="saproject"> <a  onclick="return submit_form(\''.$siteurl.'/wp-content/themes/enemat/ajax_scripts/submit_data.php\',\''.$catids.'\');">Demander ma prime</a> </h4>
		   <br class="clr"/>
	 </div>	 
<span class="hrbor"></span>
	</div>'; 
	$array_find = array(".pdf",".PDF");
	$array_replace = "";
	$number_title = str_replace($array_find,$array_replace,$rsDesignation[0]->number);
	$designations = '<a href="'.$target.'" target="_blank">'.$number_title.'</a>';
	 $array_json=array('designations'=>$designations,'meta'=>$meta);
	echo json_encode($array_json);