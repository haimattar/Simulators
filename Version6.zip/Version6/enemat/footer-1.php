











<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package enemat
 */

?>

<div class="footer">
	<div class="wraper">
		<ul>
			<li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
			<li><a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
		</ul>
	<div class="clr"></div>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
	$(document).ready(function($){
          var parPosition = [];
        $('.par').each(function() {
            parPosition.push($(this).offset().top);
        });
        
		$('a').click(function(){
			$('html, body').animate({
				scrollTop: $( $.attr(this, 'href') ).offset().top
			}, 1000);
			return false;
		});
        
        	$('.vNav ul li a').click(function () {
			$('.vNav ul li a').removeClass('active');
				$(this).addClass('active');
		}); 
        
       $('.vNav a').hover(function() {
           $(this).find('.label').show();
           }, function() {
           $(this).find('.label').hide();
       });
        
           $(document).scroll(function(){
        var position = $(document).scrollTop(),
                index; 
                for (var i=0; i<parPosition.length; i++) {
                if (position <= parPosition[i]) {
                    index = i;
                    break;
                }
            }
      $('.vNav ul li a').removeClass('active');
            $('.vNav ul li a:eq('+index+')').addClass('active');
        });
        
        	$('.vNav ul li a').click(function () {
			$('.vNav ul li a').removeClass('active');
				$(this).addClass('active');
		});   
	});
</script>

<script>
$("#img").on({
 "mouseover" : function() {
      this.src='http://stagingenemat.apps-1and1.net/wp-content/uploads/2018/01/article11.png';
   
  },
  "mouseout" : function() {
    this.src = 'http://stagingenemat.apps-1and1.net/wp-content/uploads/2018/01/article1.png';
  }
});
</script>
<?php wp_footer(); ?>
</body>
</html>