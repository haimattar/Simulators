











<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$metaids = explode("-",$_POST['metaids']);
 //print_r($_POST);
$meta_id = $metaids[0];
$conditions = $metaids[2];
if($conditions=="Yes"){
$catid= $_POST['catid'];
$siteurl = get_option('siteurl');
$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$meta_id."' ORDER BY is_cond ASC";
$rsConditions = $wpdb->get_results($SQLCOND);
if(count($rsConditions)>0){
	$meta = "";
	$meta1 = "";
	$meta2 = "";
	$counter_meta_conds = 0;
	for($x=0;$x<count($rsConditions);$x++){
		if($rsConditions[$x]->is_cond=="Yes"){
		$cond_id = $rsConditions[$x]->id;
		$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
		$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
		//print_r($rsCondValues);
		if(count($rsCondValues)>0){
						$condionsvals = '<select name="condition_valuesid[]" id="condition_valuesid" onchange=\'return  get_sub_conditions(this.value,"'.$catid.'","'.$siteurl.'/wp-content/themes/enemat/filterajax/subconditions_data.php");\'>';
						 for($aa=0;$aa<count($rsCondValues);$aa++){
							$counter_meta_conds = $counter_meta_conds+1;
						if($counter_meta_conds ==1){
							$SQLSUBCONDS = "SELECT * FROM wp_cond_meta_cond WHERE cmcond_id='".$rsCondValues[$aa]->id."'";
							$rsSubconds = $wpdb->get_results($SQLSUBCONDS);
							if(count($rsSubconds)>0){								
								 for($xx=0;$xx<count($rsSubconds);$xx++){						
									$SQLCONDMETAVALUESVALUES = "SELECT * FROM wp_cond_meta_cond_values WHERE cmcond_id='".$rsSubconds[$xx]->id."'";
									$rsSubcondMetas = $wpdb->get_results($SQLCONDMETAVALUESVALUES);
									if(count($rsSubcondMetas)>0){
										$subcondionsvals = '<select name="subcondition_valuesid" id="subcondition_valuesid">';
										for($yy=0;$yy<count($rsSubcondMetas);$yy++){
											$subcondionsvals .= '<option value="'.$rsSubcondMetas[$yy]->id."-".$rsSubcondMetas[$yy]->cmcv_value."-".$rsSubcondMetas[$yy]->cond_id."-".$rsSubcondMetas[$yy]->subconds_id.'">'.$rsSubcondMetas[$yy]->cmcv_title.'</option>';
										}
										$subcondionsvals .= '</select>';	
									}
									 $meta2 .= '<tr id="trcpconmetas'.$catid.'" class="trcpnditions'.$catid.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsSubconds[$xx]->cmc_title.'</font></font>
									 <input type="hidden" name="subcondition_id" id="subcondition_id'.$catid.'" value="'.$rsSubconds[$xx]->id.'" style="display:none;"/>
									 </td><td>'.$subcondionsvals.'</td></tr>';
								}
							}
						}else{
							$meta2 .= "";
						}
							$condionsvals .= '<option value="'.$rsCondValues[$aa]->id."-".$rsCondValues[$aa]->mc_value.'">'.$rsCondValues[$aa]->mc_title.'</option>';
						 }
						$condionsvals .= '</select><input type="text" name="condition_id[]" id="condition_id'.$catid.'" value="'.$rsConditions[$x]->id.'" style="display:none;"/>';				
					  
					 $meta .= '<tr class="trcpnditions'.$catid.'"><td>'.$rsConditions[$x]->mc_title.'</td><td>'.$condionsvals.'</td></tr>';
					 if($x==0){
						$meta .= '<tr id="trconds0-'.$catid.'"style="display:none;"><td colspan="2"></td></tr>';
						$meta .= $meta2; 
					}
					 
		}
	  }
	  if($rsConditions[$x]->is_cond=="No"){
				if($rsConditions[$x]->otherparts=="No"){
				 $condsvaltext = '<input type="text" name="condition_text" id="condition_text"/>';
				 $meta .= '<tr class="trcpnditions'.$catid.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$condsvaltext.'</td></tr>';
				 $meta .= '<input type="hidden" name="condition_textid" id="condition_textid'.$catid.'" value="'.$rsConditions[$x]->id.'"/>';	
				}
				if($rsConditions[$x]->otherparts=="Yes"){
				 $meta .= '<tr class="trcpnditions'.$catid.'" style="display:none;"><td><input type="hidden" name="partssub" id="partssub'.$catid.'" value="'.$rsConditions[$x]->mc_value.'"/>
				 <input type="hidden" name="partssubopt" id="partssubopt'.$catid.'" value="'.$rsConditions[$x]->optypes.'"/></td></tr>';
				}
			 }	
	}
	echo $meta;
}
}else{
	echo "No";
	//$meta = "";
	//echo $meta;
}	
?>