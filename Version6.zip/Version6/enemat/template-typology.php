<?php
// Template Name: Typology
get_header(); ?>
<div class="main_vid">
	<video width="100%"  autoplay>
		<source style="height:300px" src="https://video.wixstatic.com/video/11062b_4f14b356c1df4854968cf1cc94ca98c5/1080p/mp4/file.mp4" type="video/mp4" codecs="theora, vorbis">
	</video>
<iframe width="420" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY">
</iframe>

	<h2>DANS QUEL CADRE S'INSCRIVENT VOS PROJETS</h2>
	<div class="clr"></div>	
</div>
<div class="con_pg">
	<div class="wraper">
		<ul>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/list1.png">
				<h6>BATIMENT RESIDENTIEL</h6>
				<ul class="list_itm">
					<li>Isolation &amp; Fenêtres</li>
					<li>Systèmes&nbsp;de chauffage (Pompe à chaleur; Chaudières, bois ...)</li>
					<li>Ventilation : VMC</li>
					<li>Equipement LED, réfrigérateur classe A++ ou A+++</li>
				</ul>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/list2.png">
				<h6>INDUSTRIE</h6>
				<ul class="list_itm">
					<li>Groupe et régulation froid</li>
					<li>moteur, VEV ,éclairage</li>
					<li>Récupération de chaleur</li>
					<li>Isolation en milieu industriel</li>
					<li>Air, Compresseur, Secheur</li>
					<li>Special DOM TOM industriel</li>
				</ul>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/list3.png">
				<h6>AGRICULTURE</h6>
				<ul class="list_itm">
					<li>Equipement thermique</li>
					<li>Dispositif de stockage</li>
					<li>Moteur et variateur de vitesse</li>
					<li>Echangeur air air pour élevage de volaille</li>
				</ul>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/list4.png">
				<h6>RESEAU</h6>
				<ul class="list_itm">
					<li>Chauffage</li>
					<li>Eclairage</li>
				</ul>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/list5.png">
				<h6>TERTIAIRE</h6>
				<ul class="list_itm">
					<li>Chauffage</li>
					<li>Eclairage</li>
				</ul>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/list6.png">
				<h6>TRANSPORT</h6>
				<ul class="list_itm">
					<li>Chauffage</li>
					<li>Eclairage</li>
				</ul>
			</li>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="contact">
	<div class="wraper">
		<div class="lf_con">
			<h5>PATIENCE, LE SIMULATEUR SERA PRET DANS QUELQUES JOURS</h5>
		</div>
		<div class="rg_con">
			<a href="">Nous contacter</a>
		</div>
	<div class="clr"></div>
	</div>
</div>
<?php get_footer(); ?>