<?php  
add_action ( 'show_user_profile', 'my_show_extra_profile_fields' );
add_action ( 'edit_user_profile', 'my_show_extra_profile_fields' );
add_action ( 'user_new_form', 'my_show_extra_profile_fields' );
// Update CSS within in Admin
function admin_style() {
  wp_enqueue_style('admin-styles', get_template_directory_uri().'/css/admin.css');
}
add_action('admin_enqueue_scripts', 'admin_style');


function my_show_extra_profile_fields ( $user )
{
$user_id = $user->ID;
$user_pass =  get_user_meta($user_id,'user_pass',true);
?>

<table class="form-table12" width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td><strong><?php _e( 'Mot de passe', 'enemat' ); ?>:</strong> <?php echo $user_pass;?></td>
		<td>&nbsp;</td>
	</tr>
	<tr>
	 <td width="50%" valign="top">
		<table class="form-table12" width="100%" cellpadding="0" cellspacing="0">
			<tr class="form-field">
			<th>
			<label for="company_name"><?php _e( 'Nom societe', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="company_name" id="company_name" class="input" value="<?php echo esc_attr( get_the_author_meta( 'company_name', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="society_number"><?php _e( 'N Siret', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="society_number" id="society_number" class="input" value="<?php echo esc_attr( get_the_author_meta( 'society_number', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="society_address"><?php _e( 'Society Adresse', 'enemat' ) ?><span>*</span></label>
			</th>
			<td>
			<textarea name="society_address" id="society_address" class="input" value="" size="25" required><?php echo esc_attr( get_the_author_meta( 'society_address', $user->ID ) ); ?></textarea>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="society_postcode"><?php _e( 'Society Code postale', 'enemat' ) ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="society_postcode" id="society_postcode" class="input" value="<?php echo esc_attr( get_the_author_meta( 'society_postcode', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="city"><?php _e( 'Ville', 'enemat' ) ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="city" id="city" class="input" value="<?php echo esc_attr( get_the_author_meta( 'city', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="salesname"><?php _e( 'Commercial', 'enemat' ) ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="salesname" id="salesname" class="input" value="<?php echo esc_attr( get_the_author_meta( 'salesname', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="notes"><?php _e( 'ENEMAT', 'enemat' ) ?><span>*</span></label>
			</th>
			<td>
			 <?php  $notes = esc_attr( get_the_author_meta( 'notes', $user->ID ) );
					if(empty($notes)){
						$notes = "Great business contact, need to called again next week.....";
					}
			 ?>
			<textarea name="notes" id="notes" class="input" aria-required="true" size="25"><?php echo $notes;?></textarea>
			</td>
			</tr>
			 
		</table>
	 </td>
	  <td width="50%" valign="top">
		<table class="form-table12" width="100%" cellpadding="0" cellspacing="0">
			<tr class="form-field">
			<th>
			<label for="job"><?php _e( 'functions', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="job" id="job" class="input" value="<?php echo esc_attr( get_the_author_meta( 'job', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="phone_number"><?php _e( 'Tel fixe', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="phone_number" id="phone_number" class="input" value="<?php echo esc_attr( get_the_author_meta( 'phone_number', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="mobile_number"><?php _e( 'Tel mobile', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<input type="text" name="mobile_number" id="mobile_number" class="input" value="<?php echo esc_attr( get_the_author_meta( 'mobile_number', $user->ID ) ); ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="prime_mwhc"><?php _e( 'Default Prime / Mwhc', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<?php 
			$prime_mwhc = esc_attr( get_the_author_meta( 'prime_mwhc', $user->ID ) );
			if(empty($prime_mwhc)){
				$prime_mwhc = "2,5";
			}			
			?>
			<input type="text" name="prime_mwhc" id="prime_mwhc" class="input" value="<?php echo $prime_mwhc; ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="precarite"><?php _e( 'Default Prime précarité / Mwhc', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<?php 
			$precarite = esc_attr( get_the_author_meta( 'precarite', $user->ID ) );
			if(empty($precarite)){
				$precarite = "2,8";
		    }
			?>
			<input type="text" name="precarite" id="precarite" class="input" value="<?php echo $precarite; ?>" size="25" required/>
			</td>
			</tr>
			<tr class="form-field">
			<th>
			<label for="highprecarite"><?php _e( 'Default Prime High Precariousness / Mwhc', 'enemat' ); ?><span>*</span></label>
			</th>
			<td>
			<?php 
			$highprecarite = esc_attr( get_the_author_meta( 'highprecarite', $user->ID ) );
			if(empty($highprecarite)){
				$highprecarite = 5;
			} 	
			?>
			<input type="text" name="highprecarite" id="highprecarite" class="input" value="<?php echo $highprecarite; ?>" size="25" required/>
			</td>
			</tr>
		</table>
	 </td>
	</tr>
</table>
<?php 
}
add_action('user_register', 'my_save_extra_profile_fields');
add_action ( 'personal_options_update', 'my_save_extra_profile_fields' );
add_action ( 'edit_user_profile_update', 'my_save_extra_profile_fields' );
function my_save_extra_profile_fields( $user_id )
{
        if ( ! empty( $_POST['job'] ) ) {
        update_user_meta( $user_id, 'job', trim( $_POST['job'] ) );
        }
        if ( ! empty( $_POST['phone_number'] ) ) {
            update_user_meta( $user_id, 'phone_number', trim( $_POST['phone_number'] ) );
        }
        if ( ! empty( $_POST['mobile_number'] ) ) {
            update_user_meta( $user_id, 'mobile_number', trim( $_POST['mobile_number'] ) );
        }
        if ( ! empty( $_POST['prime_mwhc'] ) ) {
            update_user_meta( $user_id, 'prime_mwhc', trim( $_POST['prime_mwhc'] ) );
        }
        if ( ! empty( $_POST['precarite'] ) ) {
            update_user_meta( $user_id, 'precarite', trim( $_POST['precarite'] ) );
        }
        if ( ! empty( $_POST['highprecarite'] ) ) {
            update_user_meta( $user_id, 'highprecarite', trim( $_POST['highprecarite'] ) );
        }
		if ( ! empty( $_POST['company_name'] ) ) {
            update_user_meta( $user_id, 'company_name', trim( $_POST['company_name'] ) );
        }
		if ( ! empty( $_POST['society_number'] ) ) {
            update_user_meta( $user_id, 'society_number', trim( $_POST['society_number'] ) );
        }
		if ( ! empty( $_POST['society_address'] ) ) {
            update_user_meta( $user_id, 'society_address', trim( $_POST['society_address'] ) );
        }
		if ( ! empty( $_POST['society_postcode'] ) ) {
			update_user_meta( $user_id, 'society_postcode', trim( $_POST['society_postcode'] ) );
		}
		if ( ! empty( $_POST['city'] ) ) {
			update_user_meta( $user_id, 'city', trim( $_POST['city'] ) );
		}
		if ( ! empty( $_POST['salesname'] ) ) {
			update_user_meta( $user_id, 'salesname', trim( $_POST['salesname'] ) );
		}
		if ( ! empty( $_POST['notes'] ) ) {
			update_user_meta( $user_id, 'notes', trim( $_POST['notes'] ) );
		}
		
}

add_action( 'register_form', 'myplugin_register_form', 0 );
function myplugin_register_form() {
    $first_name = ( ! empty( $_POST['first_name'] ) ) ? trim( $_POST['first_name'] ) : '';
   // $last_name = ( ! empty( $_POST['last_name'] ) ) ? trim( $_POST['last_name'] ) : '';
    $job = ( ! empty( $_POST['job'] ) ) ? trim( $_POST['job'] ) : '';
    $phone_number = ( ! empty( $_POST['phone_number'] ) ) ? trim( $_POST['phone_number'] ) : '';
    $mobile_number = ( ! empty( $_POST['mobile_number'] ) ) ? trim( $_POST['mobile_number'] ) : '';
    $prime_mwhc= ( ! empty( $_POST['prime_mwhc'] ) ) ? trim( $_POST['prime_mwhc'] ) : '2.5';
    $precarite= ( ! empty( $_POST['precarite'] ) ) ? trim( $_POST['precarite'] ) : '2.8';
    $highprecarite= ( ! empty( $_POST['highprecarite'] ) ) ? trim( $_POST['highprecarite'] ) : '5';
    $companyname= ( ! empty( $_POST['company_name'] ) ) ? trim( $_POST['company_name'] ) : '';
	$societynumber= ( ! empty( $_POST['society_number'] ) ) ? trim( $_POST['society_number'] ) : '';
	$societyaddress= ( ! empty( $_POST['society_address'] ) ) ? trim( $_POST['society_address'] ) : '';
	$societypostcode= ( ! empty( $_POST['society_postcode'] ) ) ? trim( $_POST['society_postcode'] ) : '';
	$city= ( ! empty( $_POST['city'] ) ) ? trim( $_POST['city'] ) : '';
	$salesname= ( ! empty( $_POST['salesname'] ) ) ? trim( $_POST['salesname'] ) : '';
 ?>

<p>
<label for="first_name"><?php _e( 'Prénom', 'enemat' ) ?><span>*</span><br />
<input type="text" name="first_name" id="first_name" class="input" value="<?php echo esc_attr( wp_unslash( $first_name ) ); ?>" size="25" /></label>
</p>
 
<p>
<label for="job"><?php _e( 'fonctions', 'enemat' ) ?><span>*</span><br />
<input type="text" name="job" id="job" class="input" value="<?php echo esc_attr( wp_unslash( $job ) ); ?>" size="25" /></label>
</p>

<p>
<label for="company_name"><?php _e( 'Nom societe', 'enemat' ) ?><span>*</span><br />
<input type="text" name="company_name" id="company_name" class="input" value="<?php echo esc_attr( wp_unslash( $companyname ) ); ?>" size="25" /></label>
</p>



<p>
<label for="phone_number"><?php _e( 'téléphone', 'enemat' ) ?><span>*</span><br />
<input type="text" name="phone_number" id="phone_number" class="input" value="<?php echo esc_attr( wp_unslash( $phone_number ) ); ?>" size="25" /></label>
</p>

<p>
<label for="society_number"><?php _e( 'N Siret', 'enemat' ) ?><span>*</span><br />
<input type="text" name="society_number" id="society_number" class="input" value="<?php echo esc_attr( wp_unslash( $societynumber ) ); ?>" size="25" /></label>
</p>
<p>
<label for="mobile_number"><?php _e( 'mobile', 'enemat' ) ?><span>*</span><br />
<input type="text" name="mobile_number" id="mobile_number" class="input" value="<?php echo esc_attr( wp_unslash( $mobile_number ) ); ?>" size="25" /></label>
</p>



<p>
<label for="society_address"><?php _e( 'Society Adresse', 'enemat' ) ?><span>*</span><br />
<input type="text" name="society_address" id="society_address" class="input" value="<?php echo esc_attr( wp_unslash( $societyaddress ) ); ?>" size="25" /></label>
</p>



<p>
<label for="prime_mwhc"><?php _e( 'Default Prime / Mwhc', 'enemat' ) ?><span>*</span><br />
<input type="text"  name="prime_mwhc" id="prime_mwhc" class="input" value="<?php echo esc_attr( wp_unslash( $prime_mwhc ) ); ?>" size="25" /></label>
</p>


<p>
<label for="society_postcode"><?php _e( 'Society Code postale', 'enemat' ) ?><span>*</span><br />
<input type="text" name="society_postcode" id="society_postcode" class="input" value="<?php echo esc_attr( wp_unslash( $societypostcode ) ); ?>" size="25" /></label>
</p>


<p>
<label for="precarite"><?php _e( 'Default Prime précarité / Mwhc', 'enemat' ) ?><span>*</span><br />
<input type="text"  name="precarite" id="precarite" class="input" value="<?php echo esc_attr( wp_unslash( $precarite ) ); ?>" size="25" /></label>
</p>

<p>
<label for="city"><?php _e( 'Ville', 'enemat' ) ?><span>*</span><br />
<input type="text" name="city" id="city" class="input" value="<?php echo esc_attr( wp_unslash( $city ) ); ?>" size="25" /></label>
</p>


<p>
<label for="highprecarite"><?php _e( 'Default Prime Grande précarité/ Mwhc', 'enemat' ) ?><span>*</span><br />
<input type="text"    name="highprecarite" id="highprecarite" class="input" value="<?php echo esc_attr( wp_unslash( $highprecarite ) ); ?>" size="25" /></label>
</p>

<p>
<label for="salesname"><?php _e( 'commercial', 'enemat' ) ?><span>*</span><br />
<input type="text" name="salesname" id="salesname" class="input" value="<?php echo esc_attr( wp_unslash( $salesname ) ); ?>" size="25" /></label>
</p>
<?php /*

<p>
<label for="clientsname"><?php _e( 'Client’s Name', 'enemat' ) ?><span>*</span><br />
<input type="text" name="clientsname" id="clientsname" class="input" value="<?php echo esc_attr( wp_unslash( $clientsname ) ); ?>" size="25" /></label>
</p>

<p>
<label for="clientsemail"><?php _e( 'Client’s email', 'enemat' ) ?><span>*</span><br />
<input type="email" name="clientsemail" id="clientsemail" class="input" value="<?php echo esc_attr( wp_unslash( $clientsemail ) ); ?>" size="25" /></label>
</p>

<p>
<label for="clientsmobile"><?php _e( 'Client’s Mobile', 'enemat' ) ?><span>*</span><br />
<input type="text" name="clientsmobile" id="clientsmobile" class="input" value="<?php echo esc_attr( wp_unslash( $clientsmobile ) ); ?>" size="25" /></label>
</p>

<p>
<label for="clientslandline"><?php _e( 'Client’s landline', 'enemat' ) ?><br />
<input type="text" name="clientslandline" id="clientslandline" class="input" value="<?php echo esc_attr( wp_unslash( $clientslandline ) ); ?>" size="25" /></label>
</p>
<p>
<label for="clientsaddress"><?php _e( 'Client’s Address', 'enemat' ) ?><br />
<input type="text" name="clientsaddress" id="clientsaddress" class="input" value="<?php echo esc_attr( wp_unslash( $clientsaddress ) ); ?>" size="25" /></label>
</p>
<p>
<label for="clientspostcode"><?php _e( 'Client’s postcode', 'enemat' ) ?><br />
<input type="text" name="clientspostcode" id="clientspostcode" class="input" value="<?php echo esc_attr( wp_unslash( $clientspostcode ) ); ?>" size="25" /></label>
</p>
<p>
<label for="clientscity"><?php _e( 'Client’s City', 'enemat' ) ?><br />
<input type="text" name="clientscity" id="clientscity" class="input" value="<?php echo esc_attr( wp_unslash( $clientscity ) ); ?>" size="25" /></label>
</p>
<p>
<label for="operationnumber"><?php _e( 'Operation number eg “bar-en-102.. Title &number”', 'enemat' ) ?><br />
<input type="text" name="operationnumber" id="operationnumber" class="input" value="<?php echo esc_attr( wp_unslash( $operationnumber ) ); ?>" size="25" /></label>
</p>
<p>
<label for="mwh_cumac"><?php _e( 'Mwh cumac', 'enemat' ) ?><br />
<input type="text" name="mwh_cumac" id="mwh_cumac" class="input" value="<?php echo esc_attr( wp_unslash( $mwh_cumac ) ); ?>" size="25" /></label>
</p>


<?php*/
    }
	
add_filter( 'registration_errors', 'myplugin_registration_errors', 10, 3 );
    function myplugin_registration_errors( $errors, $sanitized_user_login, $user_email ) {

        if ( empty( $_POST['first_name'] ) || !empty( $_POST['first_name'] ) && trim( $_POST['first_name'] ) == '' ) {
            $errors->add( 'first_name_error', __( '<strong>ERROR</strong>: Please enter your first name.', 'enemat.fr' ) );
        }
       /* if ( empty( $_POST['last_name'] ) || ! empty( $_POST['last_name'] ) && trim( $_POST['last_name'] ) == '' ) {
        $errors->add( 'last_name_error', __( '<strong>ERROR</strong>: Please enter your last name.', 'enemat.fr' ) );
        }*/
		if ( empty( $_POST['job'] )) {
        $errors->add( 'job_error', __( '<strong>ERROR</strong>: Enter fonctions name.', 'enemat.fr' ) );
        }
        if ( empty( $_POST['phone_number'] )) {
        $errors->add( 'phone_number_error', __( '<strong>ERROR</strong>: Enter téléphone number....', 'enemat.fr' ) );
        }
        if ( empty( $_POST['mobile_number'] )) {
        $errors->add( 'mobile_number_error', __( '<strong>ERROR</strong>: Enter mobile number........', 'enemat.fr' ) );
        }
        if(!empty( $_POST['mobile_number']) && !preg_match('/^[0-9]{10}+$/',$_POST['mobile_number']))
        {
        $errors->add( 'mobile_number_error', __( '<strong>ERROR</strong>: Please enter a valid mobile number', 'enemat.fr' ) );
        }
        if(empty($_POST['prime_mwhc']))
        {
        $errors->add( 'prime_error', __( '<strong>ERROR</strong>: Please enter a Prime  number', 'enemat.fr' ) );   
        }
        if(empty($_POST['precarite']))
        {
        $errors->add( 'precarite_error', __( '<strong>ERROR</strong>: Please enter a Prime precariousness number', 'enemat.fr' ) );   
        }
		if(empty($_POST['highprecarite']))
        {
        $errors->add( 'high_precarite_error', __( '<strong>ERROR</strong>: Please enter a Prime High Precariousness number', 'enemat.fr' ) );   
        }
		if(empty($_POST['company_name']))
        {
        $errors->add( 'company_name_error', __( '<strong>ERROR</strong>: Please enter a Nom societe', 'enemat.fr' ) );   
        }
		if(empty($_POST['society_number']))
        {
        $errors->add( 'society_number_error', __( '<strong>ERROR</strong>: Please enter a N Siret', 'enemat.fr' ) );   
        }
		if(empty($_POST['society_address']))
        {
        $errors->add( 'society_address_error', __( '<strong>ERROR</strong>: Please enter a Society Address', 'enemat.fr' ) );   
        }
		if(empty($_POST['society_postcode']))
        {
        $errors->add( 'society_postcode_error', __( '<strong>ERROR</strong>: Please enter a Society Postcode ', 'enemat.fr' ) );   
        }
		if(empty($_POST['city']))
        {
        $errors->add( 'city_error', __( '<strong>ERROR</strong>: Please enter a Ville name ', 'enemat.fr' ) );   
        }
		if(empty($_POST['salesname']))
        {
        $errors->add( 'sales_name_error', __( '<strong>ERROR</strong>: Please enter a sales name ', 'enemat.fr' ) );   
        }		 
	/*	if(empty($_POST['clientsname']))
		{
        $errors->add( 'clients_email_error', __( '<strong>ERROR</strong>: Please enter a clients name ', 'enemat.fr' ) );   
        }
		if(empty($_POST['clientsemail']))
		{
        $errors->add( 'clients_email_error', __( '<strong>ERROR</strong>: Please enter a clients email ', 'enemat.fr' ) );   
        }
		if(!empty( $_POST['clientsmobile']) && !preg_match('/^[0-9]{10}+$/',$_POST['clientsmobile']))
        {
        $errors->add( 'mobile_number_error', __( '<strong>ERROR</strong>: Please enter a Client Mobile number', 'enemat.fr' ) );
        }*/
	    return $errors;
    }
	 add_action( 'tml_new_user_registered', 'my_new_user_registered' );
    add_action( 'user_register', 'my_new_user_registered' );
    function my_new_user_registered( $user_id ) {
        if ( ! empty( $_POST['first_name'] ) ) {
            update_user_meta( $user_id, 'first_name', trim( $_POST['first_name'] ) );
            update_user_meta( $user_id, 'last_name', trim( $_POST['last_name'] ) );
        }
        if ( ! empty( $_POST['job'] ) ) {
            update_user_meta( $user_id, 'job', trim( $_POST['job'] ) );
        }
        if ( ! empty( $_POST['phone_number'] ) ) {
            update_user_meta( $user_id, 'phone_number', trim( $_POST['phone_number'] ) );
        }
        if ( ! empty( $_POST['mobile_number'] ) ) {
            update_user_meta( $user_id, 'mobile_number', trim( $_POST['mobile_number'] ) );
        }
        if ( ! empty( $_POST['prime_mwhc'] ) ) {
            update_user_meta( $user_id, 'prime_mwhc', trim( $_POST['prime_mwhc'] ) );
        }
        if ( ! empty( $_POST['precarite'] ) ) {
            update_user_meta( $user_id, 'precarite', trim( $_POST['precarite'] ) );
        }
        if ( ! empty( $_POST['highprecarite'] ) ) {
            update_user_meta( $user_id, 'highprecarite', trim( $_POST['highprecarite'] ) );
        }
		if ( ! empty( $_POST['company_name'] ) ) {
            update_user_meta( $user_id, 'company_name', trim( $_POST['company_name'] ) );
        }
		if ( ! empty( $_POST['society_number'] ) ) {
            update_user_meta( $user_id, 'society_number', trim( $_POST['society_number'] ) );
        }
		if ( ! empty( $_POST['society_address'] ) ) {
            update_user_meta( $user_id, 'society_address', trim( $_POST['society_address'] ) );
        }
		if ( ! empty( $_POST['society_postcode'] ) ) {
			update_user_meta( $user_id, 'society_postcode', trim( $_POST['society_postcode'] ) );
		}
		if ( ! empty( $_POST['city'] ) ) {
			update_user_meta( $user_id, 'city', trim( $_POST['city'] ) );
		}
		if ( ! empty( $_POST['salesname'] ) ) {
			update_user_meta( $user_id, 'salesname', trim( $_POST['salesname'] ) );
		}
		if ( ! empty( $_POST['notes'] ) ) {
			update_user_meta( $user_id, 'notes', trim( $_POST['notes'] ) );
		}
		/*if ( ! empty( $_POST['clientsname'] ) ) {
			update_user_meta( $user_id, 'clientsname', trim( $_POST['clientsname'] ) );
		}
		if ( ! empty( $_POST['clientsemail'] ) ) {
			update_user_meta( $user_id, 'clientsemail', trim( $_POST['clientsemail'] ) );
		}
		
		if ( ! empty( $_POST['clientsmobile'] ) ) {
			update_user_meta( $user_id, 'clientsmobile', trim( $_POST['clientsmobile'] ) );
		}
		if ( ! empty( $_POST['clientslandline'] ) ) {
			update_user_meta( $user_id, 'clientslandline', trim( $_POST['clientslandline'] ) );
		}
		if ( ! empty( $_POST['clientsaddress'] ) ) {
			update_user_meta( $user_id, 'clientsaddress', trim( $_POST['clientsaddress'] ) );
		}
		if ( ! empty( $_POST['clientspostcode'] ) ) {
			update_user_meta( $user_id, 'clientspostcode', trim( $_POST['clientspostcode'] ) );
		}
		if ( ! empty( $_POST['clientscity'] ) ) {
			update_user_meta( $user_id, 'clientscity', trim( $_POST['clientscity'] ) );
		}
		if ( ! empty( $_POST['operationnumber'] ) ) {
			update_user_meta( $user_id, 'operationnumber', trim( $_POST['operationnumber'] ) );
		}
		if ( ! empty( $_POST['mwh_cumac'] ) ) {
			update_user_meta( $user_id, 'mwh_cumac', trim( $_POST['mwh_cumac'] ) );
		}*/			       
    }
    function tml_action_template_message_filter( $message, $action ) {
    if ( 'register' == $action )
            return '<span>Contact chez l’installateur</span><span>La societe</span><br style="clear:both;">';
    return $message;
}
add_filter( 'tml_action_template_message', 'tml_action_template_message_filter', 10, 2 );
    ?>