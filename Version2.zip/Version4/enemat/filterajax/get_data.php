<?php
   //  echo "<pre>";
   // print_r($_POST);exit;
@session_start();   
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$catgsid = $_POST['sousSecteur'];
$user_id = get_current_user_id();
$browserid = session_id();
$siteurl = get_option("siteurl");
function get_subsector($subsector_id){
	global $wpdb;
	$SQL = "SELECT category_name FROM wp_subcategory WHERE id='".$subsector_id."'";
	$rsSubcat = $wpdb->get_results($SQL);
	$subsectors = $rsSubcat[0]->category_name;
	return $subsectors;
}

function get_designations($designation_id){
	global $wpdb;
	$SQL = "SELECT des_name FROM wp_designations WHERE id='".$designation_id."'";
	$rsDesc = $wpdb->get_results($SQL);
	$desname = $rsDesc[0]->des_name;
	return $desname;
}

function get_meta_conditions($wording_meta_wording_id,$wording_meta_id){
	global $wpdb;
	$rsconditions = "";
	$SQL = "SELECT * FROM wp_project_meta_conditions WHERE wording_meta_id='".$wording_meta_id."' AND wording_meta_wording_id='".$wording_meta_wording_id."'";
	$rsConds = $wpdb->get_results($SQL);
	if(count($rsConds)>0){
		for($i=0;$i<count($rsConds);$i++){
			$SQLCONDS = "SELECT mc_title FROM wp_meta_conditions WHERE id='".$rsConds[$i]->condition_id."'";
			$rsCondsLabel = $wpdb->get_results($SQLCONDS);
			if(!empty($rsConds[$i]->conditions_valueids)){
				$SQLCONDSVALS = "SELECT mc_title FROM wp_meta_conditions_values WHERE id='".$rsConds[$i]->conditions_valueids."'";
				$rsCondsLabelVals = $wpdb->get_results($SQLCONDSVALS);
				$mcndstitles = $rsCondsLabelVals[0]->mc_title;
			}else{
				$mcndstitles = $rsConds[$i]->consddacavle;
			}
			$rsconditions .= '<tr><td>'.stripslashes($rsCondsLabel[0]->mc_title).'</td><td>'.$mcndstitles.'</td></tr>';	
		}
	}
	return $rsconditions;
}

function get_wordings($project_meta_id,$designation_id){
	global $wpdb;
	$SQL = "SELECT * FROM wp_project_meta_wording WHERE project_meta_id ='".$project_meta_id."' ORDER BY id ASC";
	$rsMeta = $wpdb->get_results($SQL);
	//print_r($rsMeta);
	$arraywpmeta = array();
	if(count($rsMeta)>0){
		for($x=0;$x<count($rsMeta);$x++){
			if($rsMeta[$x]->wording_meta_id!=0){
				$arraywpmeta[$x] = $rsMeta[$x]->wording_meta_id."-".$rsMeta[$x]->value;
			}else{
				$arraywpmeta[$x] = $rsMeta[$x]->value;
			}
		}
	}
	
	$SQwording="SELECT * FROM wp_wording WHERE desg_id ='".$designation_id."' AND otherparts='No' ORDER BY `desg_id` ASC";
$resultWord = $wpdb->get_results($SQwording);
$meta = "";
$meta2 ="";
if(count($resultWord)>0){
	$wpmetaid = "";
	$wpmetavalues = "";
	$meta .= '<table width="100%">';
	for($y=0;$y<count($resultWord);$y++){
		if($resultWord[$y]->otherparts=="No"){
		$metaselectionsdata = $arraywpmeta[$y];
		if(strstr($metaselectionsdata,"-")){
			$metaselections = explode("-",$metaselectionsdata);
			$wpmetaid = $metaselections[0];
		}else{
			$wpmetavalues = number_format($rsMeta[$y]->value,0," "," ");
		}
		$wmts=$resultWord[$y]->id;
		$SQwordMeta="SELECT * FROM wp_wording_meta WHERE id='".$wpmetaid."' AND word_id ='".$wmts."' ORDER BY `id` ASC,is_cond ASC";
		$WMeta = $wpdb->get_results($SQwordMeta);
		$meta .= '<tr><td style="width:97px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
		'.stripslashes($resultWord[$y]->title).'
		</font></font></td>';
		$meta .= '<td class="param-input tac">';
		 if(!empty($WMeta)){
			$arraymetaconsd = array();
			//$meta .= '<select name="wmetavalue[]" onchange=\'return  get_conditions(this.value,"'.$catgsid.'","'.$siteurl.'/wp-content/themes/enemat/filterajax/conditions_data.php");\'>';
			foreach($WMeta as $wmr){
				$SQLPRODMETACONDS = "SELECT * FROM wp_project_meta_conditions WHERE project_meta_id='".$project_meta_id."' AND wording_meta_id='".$wmr->id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				
				if(count($rsProdMetaConditions)>0){					
					$arraymetaconsd[] = $wmr->id;
				}				
				 
				$meta .=  stripslashes($wmr->title);
			 }
			//$meta .= '</select>';
		}else{
			$meta .= str_replace(".",",",$wpmetavalues);
		}
		 
		$meta .= '</td></tr>';
		} 
	}
	if(count($arraymetaconsd)>0){
			array_unique($arraymetaconsd);
			foreach($arraymetaconsd as $values){				
				$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$values."' ORDER BY is_cond ASC";
				$rsConditions = $wpdb->get_results($SQLCOND);
				if(count($rsConditions)>0){
				$selected = "";
			$array_conds = array();
			$condisids = array();
			$condstextvalues = "";
			 for($x=0;$x<count($rsConditions);$x++){
				if($rsConditions[$x]->is_cond=="Yes"){ 
				$cond_id = $rsConditions[$x]->id;
				$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
				$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
				$condionsvals = '';
				$SQLPRODMETACONDS = "SELECT wp_meta_conditions_values.mc_title 
									 FROM wp_project_meta_conditions
									 LEFT JOIN wp_meta_conditions_values ON
									 wp_project_meta_conditions.conditions_valueids=wp_meta_conditions_values.id
									WHERE wp_project_meta_conditions.project_meta_id='".$project_meta_id."'
									AND wp_project_meta_conditions.wording_meta_id='".$values."'
									AND wp_project_meta_conditions.condition_id='".$cond_id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
						
			  for($jj=0;$jj<count($rsProdMetaConditions);$jj++){
				$SQLSUBCONDVALUES = "SELECT * FROM wp_project_meta_subconditions WHERE project_meta_id ='".$project_meta_id."' AND subparents_id='".$rsProdMetaConditions[$jj]->condition_id."'";				
				$rsSubConds = $wpdb->get_results($SQLSUBCONDVALUES);
				
				if(count($rsSubConds)>0){
					 $SQLSUBCONDSMETAS = "SELECT wp_cond_meta_cond.cmc_title
										FROM wp_cond_meta_cond
										LEFT JOIN wp_project_meta_subconditions ON
										wp_cond_meta_cond.id=wp_project_meta_subconditions.subcondition_id
										WHERE wp_cond_meta_cond.id='".$rsSubConds[0]->subcondition_id."'";
						
					$rsSubCondstitles = $wpdb->get_results($SQLSUBCONDSMETAS);
					
					$SQLSUBCONDSMETAS1 = "SELECT wp_cond_meta_cond_values.cmcv_title
										FROM wp_cond_meta_cond_values
										LEFT JOIN wp_project_meta_subconditions ON
										wp_cond_meta_cond_values.id=wp_project_meta_subconditions.subconditions_valueids
										WHERE wp_cond_meta_cond_values.id='".$rsSubConds[0]->subconditions_valueids."'";
						
					$rsSubCondsmetatitles = $wpdb->get_results($SQLSUBCONDSMETAS1);
					$meta2 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsSubCondstitles[0]->cmc_title.'</font></font></td><td>'.$rsSubCondsmetatitles[0]->cmcv_title.'</td></tr>';
				}
				$meta .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$rsProdMetaConditions[$jj]->mc_title.'</td></tr>';
			 }
			 }else if($rsConditions[$x]->is_cond=="No"){
					$cond_id = $rsConditions[$x]->id;
					$SQLPRODMETACONDS = "SELECT wp_project_meta_conditions.condition_id,wp_project_meta_conditions.consddacavle,wp_meta_conditions_values.mc_title 
									 FROM wp_project_meta_conditions
									 LEFT JOIN wp_meta_conditions_values ON
									 wp_project_meta_conditions.conditions_valueids=wp_meta_conditions_values.id
									WHERE wp_project_meta_conditions.project_meta_id='".$project_meta_id."'
									AND wp_project_meta_conditions.wording_meta_id='".$values."'
									AND wp_project_meta_conditions.condition_id='".$cond_id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				for($jj=0;$jj<count($rsProdMetaConditions);$jj++){
					$meta1 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$rsProdMetaConditions[$jj]->consddacavle.'</td></tr>';
				}
			 }
			  if($x==0){
				$meta1 .= $meta2;
			  }
			}
			}	
			}
			unset($condisids);
	}
		$meta .= '</table>';
 }
	return $meta;
}
$SQLPROJECTMETA = "SELECT * FROM wp_project_meta WHERE user_id='".$user_id."' AND sector_id='".$catgsid." AND browserid='".$browserid."' ORDER BY id DESC";
$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA);
if(count($rsProdmeta)>0){
	for($i=0;$i<count($rsProdmeta);$i++){
?>
<tr>
<td>
<?php 
 $subsectors = get_subsector($rsProdmeta[$i]->subsector_id);
echo $subsectors;?>
</td>


<td>
	<?php 
 $designations = get_designations($rsProdmeta[$i]->designation_id);
echo $designations;?>
<?php echo $rsProdmeta[$i]->number_title;?>
</td>
<td colspan="2"><?php 
	$wordings = get_wordings($rsProdmeta[$i]->id,$rsProdmeta[$i]->designation_id);
	echo $wordings;?></td>

<td  rowspan="1"><?php echo stripslashes($rsProdmeta[$i]->conditions);?></td>
<td   rowspan="1"><?php echo number_format($rsProdmeta[$i]->mwh_cumac,0," "," ");?></td>
<td  rowspan="1"><?php echo str_replace(".",",",number_format($rsProdmeta[$i]->cpe_bonus,0," "," "));?></td>
<td  style="text-align:center;" rowspan="1"><span class="updt_data" onclick="return edit_project('<?php echo $rsProdmeta[$i]->id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/edit_data.php','<?php echo $rsProdmeta[$i]->subsector_id;?>','<?php echo $rsProdmeta[$i]->designation_id;?>','','<?php echo $rsProdmeta[$i]->sector_id;?>');">modifier</span>
</td>
</tr>
<?php }
}?>