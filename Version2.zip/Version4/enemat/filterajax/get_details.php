<?php  
@session_start();   
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
if($_POST['strs']=="submitfinalreport"){
$current_date = date("Y-m-d H:i:s");

$datemontharray = array("01"=>"Janvier","02"=>"Février","03"=>"Mars","04"=>"Avril","05"=>"Mai","06"=>"Juin","07"=>"Juillet","08"=>"Août","09"=>"Septembre","10"=>"Octobre","11"=>"Novembre","12"=>"Décembre",);
$current_date_pdf = date("d")." ".$datemontharray[date("m")]." ".date("Y");

global $wpdb;
$userid=$_POST['userid'];
$useremail=$_POST['useremail'];
$desid=$_POST['scenarioids'];
$SQLDESIGNATION = "SELECT * FROM wp_designations WHERE id='".$desid."'";
$rsDesignation = $wpdb->get_results($SQLDESIGNATION); 
$companyname =get_the_author_meta( 'company_name', $userid );
$salesname =   get_the_author_meta('salesname',$userid);
$first_name =   get_the_author_meta('first_name',$userid);
$last_name =   get_the_author_meta('last_name',$userid);
$default_prime_mwhc = get_the_author_meta( 'prime_mwhc',$userid);
$default_precarite = get_the_author_meta( 'precarite',$userid);
$default_highprecarite = get_the_author_meta( 'highprecarite',$userid);
$full_name = $last_name." ".$first_name;
$table = $wpdb->prefix . "clientinfo";
$strs=$wpdb->insert( 
            $table, 
            array( 
                    'userid' => $_POST['userid'], 
                    'scenario_id' =>$_POST['scenarioids'],
                    'pmetaid' =>'0',
                    'Installeture' => $companyname, 
                    'fname' => $_POST['cname'],
                    'name' => $_POST['cfullname'],
                    'address' => $_POST['caddress'],
                    'post_code' => $_POST['postalcode'], 
                    'ville' => $_POST['ville'],
                    'tel' => $_POST['ctel'],
                    'mobile' => $_POST['cmobil'],
                    'email' => $_POST['cemail'],
                    'fiche'=>$_POST['fiche'],
                    'fichelink'=>$_POST['fichelink'],
                    'scenario_title'=>esc_sql($_POST['scenariotitle']),
                    'mwhcumac'=>$_POST['mwhcumac'],
                    'sendmaildate'=>$current_date,
                    'signdate'=>$current_date,       
                    'commercial' => $salesname,
                )
        );
     if($strs){
  $from=$_POST['useremail'];
  $to = $_POST['cemail'];
  $find_sub = "{name}";
  $subjectop = get_option("email_subject");
  $subject = str_replace("{name}",$_POST['cfullname']." ".$_POST['cname'],$subjectop);
  $user_id = get_current_user_id();
  if(empty($full_name)){
    $user_info = get_userdata($user_id);
	$full_name = $user_info->user_login;
  }
  $siteurl = get_option("siteurl");
  $logourl = "".$siteurl."/wp-content/uploads/2018/01/logo.png";
  $logoimages = '<img src="'.$logourl.'"/>';
  $emailbodyop = get_option("email_body");
  $find_body = array("{name}","{prime}","{logourl}");
  $primevals = $_POST['primeval'];
  $precarites = $_POST['precarite'];
  $grandprecarites = $_POST['grandprecarite'];
   
  $replace_body = array($_POST['cfullname']." ".$_POST['cname'],$primevals,$logoimages);  
  $message1 =  str_replace($find_body, $replace_body,$emailbodyop);
  $message = addslashes($message1);
  $html = '
        <html>
            <head>
                <title>'.$_POST['cname'].' Merci de valider votre prime energie</title>
            </head>
            <body>
<div id="scenariosummary">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td style="width:80%;"><img  align="left" width="300" height="100" src="'.get_site_url().'/wp-content/uploads/2018/04/logo1.png"> </td>
<td style="width:20%;"><p>&nbsp;</p><p>&nbsp;</p><img align="right" width="150" src="'.get_site_url().'/wp-content/uploads/2018/04/logo2.png"></td>
</tr>
<tr><td style="width:100%;padding-left:20px;"><p style="line-height:15px;font-weight:400;">Le dispositif national des certificats d’économies d’énergie(CEE) mis en place par le Ministère en charge de l’énergie impose à l’ensemble des 
fournisseurs d’énergie (électricité, gaz, fioul domestique, chaleur ou froid, carburants automobiles),
de réaliser des économies et de promouvoir les comportements vertueux auprès des consommateurs d’énergie.</p>
</td></tr>
<tr><td><p style="line-height:20px;font-weight:400;padding-top:0px; margin-top:0px;">Dans ce cadre, la société <b>ENEMAT (SASU)</b> s`engage à vous apporter :</p></td></tr>
<tr><td style="padding-left:20px;"><p><img src="'.get_site_url().'/wp-content/uploads/2018/05/squ2.png" width="10px" height="10px"> Une prime d`un montant de '.$primevals.'</p></td></tr>
<tr><td style="padding-left:20px;"><p><img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">Un bon d’achat pour des produits de consommation courante d’un montant …………. € ;</p></td></tr>
<tr><td style="padding-left:20px;"><p><img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">Un prêt bonifié d’un montant de ………….. € proposé par …………. au taux effectif global (TEG) de …… % (valeur de la bonification = ………….. €);</p></td></tr>
<tr><td style="padding-left:20px;"><p><img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">Un audit ou conseil personnalisé, remis sous forme écrite au bénéficiaire (valeur …………. €);</p></td></tr>
<tr><td style="padding-left:20px;"><p><img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">Un produit ou service offert : …………….  …………….d’une valeur de …………….. €;</p></td></tr>
<tr><td><p style="line-height:25px;font-weight:400;">Dans le cadre des travaux suivants (1 ligne par opération) :</p></td></tr>
</table>

<table colspan="1" style="border: 1px solid black;border-collapse: collapse; width:100%;">

<tr><td style="border: 1px solid black;border-collapse: collapse; padding:10px 20px;text-align:center;"><b>Nature des travaux </b></td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;text-align:center;"><b>Fiche CEE</b></td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;text-align:center;"><b>Condition a respecter</b></td></tr>
<tr><td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;text-align:center;">'.stripslashes($_POST['scenariotitle']).'</td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;text-align:center;"><a href="'.$_POST['fichelink'].'" target="_blank">'.$_POST['fiche'].'</a></td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;text-align:center;">Veir less conditions contractuel dans l\'enseignement page suivante</td></tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr><td><p>au bénéfice de : <b>'.$_POST['cfullname'].' '.$_POST['cname'].'</b><br/>					
Tel : '.$_POST['ctel'].', '.$_POST['cmobil'].'<br/>
Email:'.$_POST['cemail'].'<br/>
Adresse: '.$_POST['caddress'].'<br/>'.$_POST['postalcode'].' '.$_POST['ville'].'
</p></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td style="padding:10px 0;"><p><b>*Pour le calcul détaillé du montant de votre prime et son mode de paiement :<br/>voir les conditions contractuelles, dans l`engagement page suivante.</b></p></td></tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td><p>Date de cette proposition: <b>'.$current_date_pdf.'</b></p></td></tr>
<tr><td><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Signature :<b> Stamp</b></p></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>

<tr>
<td style="width:5%;border:none;"><img src="'.get_site_url().'/wp-content/uploads/2018/05/attention.png" width="50px" padding-right="0px"></td>
<td style="width:95%;border:none;"><p style="font-size:8px; line-height:13px;"> Attention, seules les propositions remises avant l’acceptation du devis ou du bon de commande sont valables, et vous ne pouvez pas cumuler plusieurs offres CEE différentes pour la même opération.</p></td>
</tr>
</table>

<table cellspacing="1" cellpadding="2" style="border: 1px solid #000;  width:100%; background-color:#e6ebef;">
  <tr>
	<td width="80%" valign="top" align="left">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	  <tr><td>
	  <a style="color:#000; line-height:15px;">Où se renseigner pour bénéficier de cette offre ?</a></td></tr>
		   <tr><td  style="line-height:15px;">
<b>SAS ENEMAT <a style="color:#0000ff;">www.enemat.fr</a> | email: <a style="color:#0000ff;">gestion@enemat.fr </a> | tel: 06 49 88 80 55</b><br/>
<a style="color:#000;">Où s’informer sur les aides pour les travaux d’économies d’énergie ?</a></td></tr>
 
 <tr><td style="line-height:15px;">
Site du Ministère en charge de l’énergie:</td></tr> 

<tr><td style="line-height:15px;">
www.ecologique−solidaire.gouv.fr/aides−financieres−renovation−energetique Plateforme  Rénovation  info  service:<img src="'.get_site_url().'/wp-content/uploads/2018/05/8000.png" width="150px"></td></tr>
		</table>
	</td>
	<td width="20%" valign="top" align="right">
	<table width="auto" border="0" cellpadding="0" cellspacing="3">
	<tr><td>
<img src="'.get_site_url().'/wp-content/uploads/2018/05/ministry.png" style="border:1px solid #000;margin-right:10px;"/>	</td></tr>
		</table>
	</td>
		 
  </tr>
</table>
<p>&nbsp;</p>

<p><b style="font-size:13px;">Vous  avez  droit  à  une  Prime  Énergie </b> (sans  condition  de  revenus)<br/>Mais  en  plus,  si  votre  revenu  fiscal  de  référence  :<br/>
•est  inférieur  à  la  grille  B, <b> une  surprime  s ajoute  à  la  Prime  Énergie</b><br/>
•est  inférieur  à  la  grille  A, <b>cette  surprime  sera  bonifiée</b></p>
<table width="100%" border="0" cellpadding="10" cellspacing="0">
<tr>
<td style="width:60%;border:none;"><table width="100%" border="1" cellpadding="0" cellspacing="0">
  <tr style="font-size:8px;">
	<td rowspan="2" align="center">Nombre de personnes dans le ménage</td>
	<td colspan="2" align="center">GRILLE A<br/>Prime + Surprimebonifiée</td>
	<td colspan="2" align="center">GRILLE B<br/>Prime + Surprime</td>
  </tr>
  <tr style="font-size:7px;">
	<td align="center">Revenus Max lle−de− France (€)</td>
	<td align="center">Revenus Max Autresrégions (€)</td>
	<td align="center">Revenus Max lle−de− France (€)</td>
	<td align="center">Revenus Max Autresrégions (€)</td>
  </tr>
  <tr style="padding:3px 0 ;">
	<td align="center" >1</td>
	<td align="center">19 875</td>
	<td align="center">14 360</td>
	<td align="center">24 194</td>
	<td align="center">18 409</td>
  </tr>
  <tr style="padding:3px 0 ;">
	<td align="center">2</td>
	<td align="center">29 171</td>
	<td align="center">21 001</td>
	<td align="center">35 510</td>
	<td align="center">26 923</td>
  </tr>
  <tr style="padding:3px 0 ;">
	<td align="center">3</td>
	<td align="center">35 032</td>
	<td align="center">25 257</td>
	<td align="center">42 648</td>
	<td align="center">32 377</td>
  </tr>
   <tr style="padding:3px 0 ;"> 
	<td align="center">4</td>
	<td align="center">40 905</td>
	<td align="center">29 506</td>
	<td align="center">49 799</td>
	<td align="center">37 826</td>
  </tr>
  <tr style="padding:3px 0 ;">
	<td align="center">5</td>
	<td align="center">46 798</td>
	<td align="center">33 774</td>
	<td align="center">56 970</td>
	<td align="center">43 297</td>
  </tr>
  <tr style="padding:3px 0 ;">
	<td align="center">... +1</td>
	<td align="center">+ 5 882</td>
	<td align="center">+ 4 257</td>
	<td align="center">+ 7 162</td>
	<td align="center">+ 5 454</td>
  </tr>
  </table>
  <p>Si vous  n\'avez  pas  encore  fourni  les  informations  nécessaires et vous</p>
<p>pensez que votre foyer est dans les critères de revenus de la Surprime,
Indiquez à la société '.$companyname.':<br/>
-	Votre/vos N° de déclarant fiscal (enrouge)<br/>
-	Le/les N° de votre dernier avis d\'imposition(envert)</p>
  </td>
<td style="width:100%;border:none;"><img src="'.get_site_url().'/wp-content/uploads/2018/05/avis.png"></td>
</tr>

</table>
<hr style="border-top:1px solid #000">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td style="width:60%;">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr><td> <span style="color:#b3bab8;">Datez et signez puis remettez ce document a<br/> la société '.$companyname.'</span>
</td></tr>
<tr><td><span style="color:#b3bab8;">En cas de signature électronique le renvoi<br/> est automatique</span></td></tr>
<tr><td>Signature: </td></tr>
<tr><td>'.$_POST['cfullname'].' '.$_POST['cname'].'<br/>
'.$_POST['cemail']. '<br/>'.$_POST['ctel'].', '.$_POST['cmobil']. '<br/>'.$_POST['caddress'].'<br/>
'.$_POST['postalcode'].' '.$_POST['ville'].'</td></tr>
</table>
</td>
<td style="width:40%;border:none;">

<table width="100%" border="0" cellpadding="3" cellspacing="0">

<tr><td>Date : ..............................</td></tr>
<tr>
<td style="border:2px solid #000; height:95px;">
<b style="line-height:25px;">&nbsp;&nbsp;&nbsp;&nbsp;Signataire :</b>
</td>
</tr>
</table>
</td>
</tr>

</table>
<hr style="border-bottom:1px solid #000">
<table width="100%" border="0" cellpadding="2" cellspacing="0" style="font-size:9px;">

<tr><td><b style="color:#b3bab8; font-size:12px; ">Engagement - Conditions contractuelles - Modalités de calcul de la prime</b></td></tr>
<tr><td>SASU ENEMAT s\'engage, si votre dossier est complet et valide à vous faire bénéficier d\'une Prime Énergie au titre du
 dispositif des certificats d\'économies d\'énergie. Vous n\'avez pas encore indiqué vos informations fiscales. En fonction de vos
justificatifs de revenus, le montant de votre prime est estimée à ce jour soit à : '.$primevals.'(prime énergie seule), soit '.$precarites.'
prime + surprime grille B), soit '.$grandprecarites.' (prime + surprime grille A).
Cette incitation financièreapparaitra comme un débours (remise appliquée sur le total TTC) sur la facture finale de la société '.$companyname.', elle sera réévaluée en fin de travaux en fonction :
1-	Pour la prime totale : des données techniques (volume de MWh Cumac) indiquées par votre installateur sur
I ‘Attestation sur I‘Honneur en cohérence avec sa facture (prime calculée sur un taux fixe de '.$default_prime_mwhc.' €/MWh Cumac classique).
2-	Pour la surprime : de la validité de votre justificatif de revenu. En cas d\'absence ou d\'invalidité du justificatif, seule la
prime rentrera dans le montant de I‘incitation financière (surprime calculée sur un taux fixe de '.$default_precarite.' €/MWh Cumac précarité).
Votre facture des travaux devra être cohérente avec votre justificatif de revenu, c\'est-à-dire : au nom du déclarant fiscal et a
son adresse fiscale (ou complétée par une attestation de déménagement ou de résidence secondaire).
Toute fausse déclaration ou faux justificatif invalidera le droit à cette incitation financière ou son remboursement. Cette prime
n\'est pas cumulable avec des aides à I ‘investissement de I ‘Agence de I ‘environnement et de la maîtrise de l\'énergie (ADEME), ni
avec d\'autres contributions basées sur le dispositif des certificats d\'économies d\'énergie.</td></tr>
<tr><td><b style="color:#b3bab8; font-size:12px;">Conditions à respecter</b></td></tr>
<tr><td>Vous vous engagez à respecter toutes les conditions fixées par le Ministère, comme les performances des produits/matériaux a
Installer, la qualification RGE de votre installateur (si nécessaire) ainsi que les documents que nous vous demanderons de fournir.
Votre dossier devra être complet avant le '.date('d/m/Y',strtotime("+1 Year")).'.</td></tr>
<tr><td>Les conditions d\'obtention de la prime, sa formule de calcul et les conditions de « précarité énergétique » sont disponibles surle
site du Ministère en charge de l\'énergie (voir fiche opération: <a href="'.$_POST['fichelink'].'" target="_blank">'.$_POST['fiche'].'</a> : '.$_POST['pmtitle'].'</td></tr>
<tr><td><a style="color:#475faa;">https://www.ecologique-solidaire.gouv.fr/operations-standardisees</a></td></tr>
</table>
</body>
        </html>'; 
$headers  = "Content-type: text/html; charset=utf-8 \r\n"; 
//$headers .= "From: Site <$from>\r\n"; 
$headers  .= 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
// Create email headers
$headers .= 'From: '.$from."\r\n".

    'Reply-To: '.$from."\r\n" .

    'X-Mailer: PHP/' . phpversion();
//$attachments = ABSPATH."wp-content/themes/enemat/pdfs/TRA-EQ-114.pdf";
//=====Generate PDF=======//
			require_once('tcpdf/tcpdf.php');
			$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
			$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
			$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
			// set default monospaced font
			$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
			// set auto page breaks
			$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
			$pdf->setPrintHeader(false);
			$pdf->setPrintFooter(false);
			// set some language-dependent strings (optional)
			if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
				require_once(dirname(__FILE__).'/lang/eng.php');
				$pdf->setLanguageArray($l);
			}
			// set default font subsetting mode
			$pdf->setFontSubsetting(true);
			// Set font
			// dejavusans is a UTF-8 Unicode font, if you only need to
			// print standard ASCII chars, you can use core fonts like
			// helvetica or times to reduce file size.
			$pdf->SetFont('dejavusans', '', 10, '', true);
			// Add a page
			// This method has several options, check the source code documentation for more information.
			$pdf->AddPage();
			// set text shadow effect
			$pdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,196,196), 'opacity'=>1, 'blend_mode'=>'Normal'));
			// Set some content to print
			$find = array("<",">");
			$replace = array("&lt;","&gt;");
			$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
			ob_end_clean();
			$filename = ABSPATH."wp-content/themes/enemat/pdfs/".time().'-pdf.pdf';
			$pdf->Output($filename, 'F');
			$attachments = $filename;
			//=====Generate PDF=======//
			//=========Integrate API=======//
			 $docdesigns = api_integrate($filename,$_POST['cname'],$to,$subject,$message);
			//=========Integrate API=======//
			//wp_mail($to, $subject, $message, $headers, $attachments);
if($docdesigns=="success"){
	@unlink($filename);
	echo json_encode(array('status' => 'success'));
} else {
echo json_encode(array('status' => 'error'));
}
}else {
echo json_encode(array('status' => 'error'));
} 
}else{
$currency = $_POST['currency'];
$mwhvalue = $_POST['mwhvalue']/1000;
$userid = $_POST['userid'];
//echo $amounts = $_POST['vals']?$_POST['vals']:'100';
$amounts=$_POST['vals']/100;

$key1='prime_mwhc';
$key2='precarite';
$key3='highprecarite';
$single = true;

$prime_mwhc= get_user_meta( $userid, $key1, $single );
$precarites= get_user_meta( $userid, $key2, $single );
$highprecarites= get_user_meta( $userid, $key3, $single );

$prime=$mwhvalue*$prime_mwhc*$amounts;
$precarite=$mwhvalue*$precarites*$amounts;
$highprecarite=$mwhvalue*$highprecarites*$amounts;

$grade_prime=(1-$amounts)*$mwhvalue*$prime_mwhc;
$grade_precarite=(1-$amounts)*$mwhvalue*$precarites;
$grade_highprecarite=(1-$amounts)*$mwhvalue*$highprecarites;


$array_heads = "";
$array_heads .= '<table with="100%">';
$array_heads .= '<tbody><tr><td>&nbsp;</td><td>Pour votre client</td><td>Pour votre</td></tr>';
$array_heads .= '<tr><td>Prime sans precarite</td>
<td><input readonly value="'.number_format($prime,0," "," ")." ".$currency.'" name="primevalaj" id="primevalaj" ></td>
<td><input readonly value="'.number_format($grade_prime,0," "," ")." ".$currency.'" name="g_primevalaj" id="g_primevalaj" ></td></tr>
<tr><td>Prime avac precarite (avec justificatif)</td>
<td><input readonly value="'.number_format($precarite,0," "," ")." ".$currency.'" name="precariteaj" id="precariteaj" ></td>
<td><input readonly value="'.number_format($grade_precarite,0," "," ")." ".$currency.'" name="g_precariteaj" id="g_precariteaj" ></td></tr>
<tr><td>Prime grand avac precarite (avec justificatif)</td>
<td><input readonly value="'.number_format($highprecarite,0," "," ")." ".$currency.'" name="grandprecariteaj" id="grandprecariteaj" ></td>
<td><input readonly value="'.number_format($grade_highprecarite,0," "," ")." ".$currency.'" name="g_grandprecariteaj" id="g_grandprecariteaj" ></td>
</tr>';
$array_heads .= '</tbody></table>';
$arrays = array("amount1"=>number_format($prime,2)." ".$currency,"amount2"=>number_format($grade_prime,0," "," ")." ".$currency,"details"=>$array_heads);
echo json_encode($arrays);
}

function api_integrate($filename,$cname,$to,$subject,$message){ 
	$integratorKey = '3f656d44-4632-4fbc-bb4c-d2f18612175b';
$email = 'Emmanuel.attar@enemat.fr';
$password = 'AsdfgH!@#45';

$recipient_email = $to;
$name = $cname;
$document_name = $filename;

// construct the authentication header:
$header = "<DocuSignCredentials><Username>" . $email . "</Username><Password>" . $password . "</Password><IntegratorKey>" . $integratorKey . "</IntegratorKey></DocuSignCredentials>";

/////////////////////////////////////////////////////////////////////////////////////////////////
// STEP 1 - Login (to retrieve baseUrl and accountId)
/////////////////////////////////////////////////////////////////////////////////////////////////
$url = "https://demo.docusign.net/restapi/v2/login_information";
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array("X-DocuSign-Authentication: $header"));

$json_response = curl_exec($curl);
$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
//print_r($json_response);
if ( $status != 200 ) {
	echo "error calling webservice, status is:" . $status;
	exit(-1);
}

$response = json_decode($json_response, true);
$accountId = $response["loginAccounts"][0]["accountId"];
$baseUrl = $response["loginAccounts"][0]["baseUrl"];
curl_close($curl);

//--- display results
//echo "\naccountId = " . $accountId . "\nbaseUrl = " . $baseUrl . "\n";

/////////////////////////////////////////////////////////////////////////////////////////////////
// STEP 2 - Create an envelope with one recipient, one tab, one document and send!
/////////////////////////////////////////////////////////////////////////////////////////////////
$data = "{
  \"emailBlurb\":\"".$message."\",
  \"emailSubject\":\"".$subject."\",
  \"documents\":[
    {
      \"documentId\":\"1\",
      \"name\":\"".$document_name."\"
    }
  ],
  \"recipients\":{
    \"signers\":[
      {
        \"email\":\"$recipient_email\",
        \"name\":\"$name\",
        \"recipientId\":\"1\",
        \"tabs\":{
		 \"dateSignedTabs\":[
            {
              \"anchorString\":\"Date :\",
              \"anchorXOffset\":\"50\",
              \"anchorYOffset\":\"0\",
			  \"documentId\":\"1\",
			  \"pageNumber\":\"2\",
            }
          ],
          \"signHereTabs\":[
            {
              \"anchorString\":\"Signataire :\",
              \"anchorXOffset\":\"10\",
              \"anchorYOffset\":\"50\",
			  \"documentId\":\"1\",
			  \"pageNumber\":\"2\",
            }
          ]
        }
      }
    ]
  },
  \"status\":\"sent\"
}";  

$file_contents = file_get_contents($document_name);

$requestBody = "\r\n"
."\r\n"
."--myboundary\r\n"
."Content-Type: application/json\r\n"
."Content-Disposition: form-data\r\n"
."\r\n"
."$data\r\n"
."--myboundary\r\n"
."Content-Type:application/pdf\r\n"
."Content-Disposition: file; filename=\"$filename.\"; documentid=1 \r\n"
."\r\n"
."$file_contents\r\n"
."--myboundary--\r\n"
."\r\n";

// *** append "/envelopes" to baseUrl and as signature request endpoint
$curl = curl_init($baseUrl . "/envelopes" );
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $requestBody);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
	'Content-Type: multipart/form-data;boundary=myboundary',
	'Content-Length: ' . strlen($requestBody),
	"X-DocuSign-Authentication: $header" )
);

$json_response = curl_exec($curl);
$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
if ( $status != 201 ) {
	echo "error calling webservice, status is:" . $status . "\nerror text is --> ";
	print_r($json_response); echo "\n";
	exit(-1);
}

//$response = json_decode($json_response, true);
//$envelopeId = $response["envelopeId"];

//--- display results
//echo "Document is sent! Envelope ID = " . $envelopeId . "\n\n";
return "success";
}
?>