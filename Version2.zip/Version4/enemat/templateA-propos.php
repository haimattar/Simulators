<?php
// Template Name: APropos
get_header(); ?>
<div class="main_pro">
	<div class="wraper">
		<div class="txt_pro">
			<h3>À PROPOS</h3>
		</div>
		<div class="clr"></div>
	</div>
</div>
<div class="ser_pro">
	<div class="wraper">
		<div class="lf_ser">
			<h5>ENEMAT</h5>
		<p>	Société de conseil spécialisée dans les dispositifs d'Economie d'Energie.</p>
<p>Nous vous accompagnons dans vos problématiques techniques, administratives et financières</p>
		</div>	
		<div class="clr"></div>
	</div>
</div>
<div class="rw_bg">
	<div class="wraper">
	<h5 style="letter-spacing:0.2em;">Notre équipe</h5>
		<ul>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/rw1.jpg">
				<h6>Emmanuel Attar, Directeur associé</h6>
				<p>Diplômé EM LYON</p>
				<p>MBA CEIBS</p>
				<p>Responsable Financier et Commercial</p>
				<p>Passioné par le climat et les energies renouvelables.</p>
				<p>12 ans d’expérience en financement d’entreprises,&nbsp;et dans le conseil&nbsp;sur le segment&nbsp;de l'energie.</p>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/rw2.jpg">
				<h6>Gabriel Attar, Directeur associé</h6>
				<p>Diplômé en Droit et Sciences Politiques à l'université de Nice.</p>
<p>Master droit privé</p>
<p>Responsable juridique</p>
<p>9 ans d'expérience dans le domaine des économies d'energies</p>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/rw3.jpg">
				<h6>Wechsler Alexandra</h6>
<p>Diplômé EM LYON</p>
<p>Master spécialisé en Marketing</p>
<p>Responsable de la communication et du marketing</p>
			</li>
			<li>
				<img src="<?php echo get_template_directory_uri(); ?>/images/rw4.png">
				<h6>Rachel Fikman</h6>
				<p>Responsable des Ressources Humaines</p>
				</li>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="contact_pro">
<hr>
	<div class="wraper">
		<div class="lf_con">
			<h5>N'hésitez pas à nous contacter</h5>
			<p>Nous nous engageons à vous repondre sous 24H</p>
		</div>
		<div class="rg_con">
			<a href="/contact">Nous contacter</a>
		</div>
	<div class="clr"></div>
	</div>
</div>
<?php get_footer(); ?>