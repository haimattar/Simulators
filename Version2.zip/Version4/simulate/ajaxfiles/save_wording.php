<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
	//print_r($_POST);
if($_POST["stats"]=="wupdate" || $_POST["stats"]=="wordnew"){
	
$current_date = date("Y-m-d H:i:s");
$weditid=$_POST['weditid'];
$table = $wpdb->prefix.$_POST['table_name'];
if($_POST['iswmeta']=="Yes"){
$wordvalue='';
$wotherparts='No';
$woptypes='Mult';
$iswmeta=$_POST['iswmeta'];
}
if($_POST['iswmeta']=="No" && $_POST['wotherparts']=="No")
{
$iswmeta=$_POST['iswmeta'];	
$wotherparts=$_POST['wotherparts']?$_POST['wotherparts']:'';
$woptypes='Mult';
$wordvalue='';
}
if($_POST['iswmeta']=="No" && $_POST['wotherparts']=="Yes")
{
$iswmeta=$_POST['iswmeta'];
$wordvalue=$_POST['wordvalue']?$_POST['wordvalue']:'';
$wotherparts=$_POST['wotherparts']?$_POST['wotherparts']:'';
$woptypes=$_POST['woptypes']?$_POST['woptypes']:'';
}
if(!empty($weditid)){
$SQLup = "UPDATE ".$table." SET desg_id='".$_POST['designationid']."',title='".$_POST['wording']."',word_value ='".$wordvalue."'
,is_meta ='".$iswmeta."',otherparts ='".$wotherparts."',optypes ='".$woptypes."' WHERE id='".$weditid."'";
$result=$wpdb->query($SQLup);
}else{
$data=array('desg_id' => $_POST['designationid'],'title' => $_POST['wording'],'word_value' =>$wordvalue,
'is_meta' =>$iswmeta,'otherparts'=>$wotherparts,'optypes' =>$woptypes);
$result=$wpdb->insert( $table, $data);
}
}
if($_POST["stats"]=="deletewording"){
global $wpdb;
$wid=$_POST['wid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE a,b,c,d FROM ".$table."  a 
LEFT JOIN wp_wording_meta b ON ( a.id = b.word_id)
LEFT JOIN wp_meta_conditions c ON ( b.id = c.meta_id)
LEFT JOIN wp_meta_conditions_values d ON ( c.id = d.cond_id)
WHERE a.id  ='".$wid."'";
$result=$wpdb->query($SQLwm);
}
if($result){ 
echo get_designationfiles($_POST['designationid']);
}