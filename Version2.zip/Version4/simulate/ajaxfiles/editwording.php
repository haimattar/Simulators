<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$designid = $_POST['desgid'];
$w_ID = $_POST['word_ID'];
$submttitle = $_POST['sbmt'];
$wordtype = $_POST['wordtype'];
$title = $_POST['wordtitle'];
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
		if($w_ID){
		$SQLw = "SELECT * FROM wp_wording WHERE id  = '".$w_ID."' AND  desg_id  = '".$designid."'";
		$wTPT = $wpdb->get_results($SQLw);
		}
?>
<form style="display:block;" id="newform3" action="" method="POST" enctype="multipart/form-data">
<h2>Wording Settings of Scenario</h2>
<h2><?php echo $title?$title.' Wording':"Add New Wording";?>  </h2>
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="weditid" id="weditid" value="<?php echo $w_ID; ?>">
<input type="hidden" id="designationid" name="designationid" class="designationid" readonly value="<?php echo $designid; ?>">
<p><label>Wording Title : </label><input type="text" name="wording" id="wording" value="<?php echo $wTPT[0]->title?$wTPT[0]->title:'';?>"></p>
<p><label>Is Meta? : </label>
<select name="iswmeta" id="iswmeta" onchange="leaveChange(this.value)">
<option value="">Select </option>
<option value="Yes" <?php echo ($wTPT[0]->is_meta=='Yes')?'selected':''; ?>>Yes</option>
<option value="No" <?php echo ($wTPT[0]->is_meta=='No')?'selected':''; ?>>No</option>
</select>
</p>
<?php $d=($wTPT[0]->is_meta=='No')?'block':'none'; ?>
<p id="iscmetaop" style="display:<?php echo $d?$d:'none';?>;"><label>Other Parts? : </label>
<select name="wotherparts" id="wotherparts" onchange="leaveChange1(this.value)">
<option value="">Select Value</option>
<option value="No" <?php echo ($wTPT[0]->otherparts=='No')?'selected':''; ?>>No</option>
<option value="Yes" <?php echo ($wTPT[0]->otherparts=='Yes')?'selected':''; ?>>Yes</option>
</select>
</p>
<?php $dislays2=($wTPT[0]->otherparts=='Yes')?'block':'none'; ?>
<p id="iscmetaop2" style="display:<?php echo $dislays2?:'none';?>;"><label>Optional Types? : </label>
<select name="woptypes" id="woptypes" onchange="leaveChange6(this.value)">
<option value="">Select Value</option>
<option value="Add" <?php echo ($wTPT[0]->optypes=='Add')?'selected':''; ?>>Add</option>
<option value="Sub" <?php echo ($wTPT[0]->optypes=='Sub')?'selected':''; ?>>Sub</option>
<option value="Mult" <?php echo ($wTPT[0]->optypes=='Mult')?'selected':''; ?>>Mult</option>
<option value="Div" <?php echo ($wTPT[0]->optypes=='Div')?'selected':''; ?>>Div</option>
</select>
</p>
<?php $displayc=($wTPT[0]->otherparts=='Yes')?'block':'none'; ?>
<p id="iscmetaop1" style="display:<?php echo $displayc?$displayc:'none';?>;"><label>Wording Value</label><input type="text" name="wordvalue" id="wordvalue" value="<?php echo $wTPT[0]->word_value?$wTPT[0]->word_value:'';?>"></p>
<p><label></label><input type="button" class="btn btn-info" onclick="return datawordinginsertt('<?php echo $wTPT[0]->id;?>','<?php echo $designid;?>','<?php echo plugins_url('ajaxfiles/save_wording.php' ,dirname(__FILE__));?>','wording','<?php echo $wordtype;?>');"  name="<?php echo "designationsubmit";?>" value="<?php echo $submttitle;?>" id="submit"></p>
<p id="response"></p>
</form>
