<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
include($_SERVER['DOCUMENT_ROOT']."/wp-content/plugins/simulate/ajaxfiles/functions.php"); 
global $wpdb;
/*************************Get List of Sub Sectors***************************************/
		if($_POST["stats"]=="getsubcats"){
		$q=$_POST["catids"];
		$subcatid=$_POST["subcatid"];
		$table = $wpdb->prefix.$_POST['table_name'];
		$SQLcatp="SELECT * FROM ".$table."  WHERE catid ='$q' ORDER BY id DESC";
		$result = $wpdb->get_results($SQLcatp); ?>
		<label>Sub Sectors</label>
		<select id="subsectors" name="subsectors" class="subsectors" onchange="return showDesignation(this.value,'<?php echo plugins_url('ajaxfiles/ajaxfile.php' ,dirname(__FILE__));?>','designations')">
		<option>Select Sub Sector</option>
		<?php foreach($result as $row)
		{
		if($subcatid==$row->id)
		{ $selected="selected"; }else{ $selected="";}
		?><option value="<?php echo $row->id;?>" <?php echo $selected; ?> ><?php echo $row->category_name;?></option>
		<?php } ?>
		</select>
		<?php }
/*************************Get List of Scenarios***************************************/
if($_POST["stats"]=="fetchdesig"){
$q=$_POST["catids"];
$urls="'".$_POST['URLS']."'";
$table = $wpdb->prefix.$_POST['table_name'];
$SQLcatp="SELECT * FROM ".$table."  WHERE subcatid ='$q' ORDER BY id DESC";
$result = $wpdb->get_results($SQLcatp);
$catid = $result[0]->catid;

?>
<label>Title : </label>
<select id="design" name="fiche" onchange="return getdestinationsdata(this.value,<?php echo $catid;?>,'<?php echo plugins_url('ajaxfiles/ajaxfile.php' ,dirname(__FILE__));?>','designations')" id="fiche<?php echo $catid;?>">
<option>Select Scenario</option>
<?php 
foreach($result as $row){?>
<option value="<?php echo $row->id;?>"><?php echo stripslashes($row->number);?></option>
<?php } ?>
</select>
<?php }


if($_POST["stats"]=="fetchdesignationdata"){
    	
$DESIGID=$_POST['destiid'];
global $wpdb;
$adminurl = admin_url();
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
if($_POST['searchvar']=="searchsenario"){
$WHERE = "WHERE des_name LIKE '%".trim($_REQUEST['destiid'])."%' OR number LIKE '%".trim($_REQUEST['destiid'])."%' OR id LIKE '%".trim($_REQUEST['destiid'])."%'";
$SQLdesg="SELECT * FROM wp_designations ".$WHERE." ORDER BY id DESC";
}else{
$SQLdesg="SELECT * FROM wp_designations WHERE id ='".$DESIGID."'";
}
$resultdesg = $wpdb->get_results($SQLdesg);
$designid=$resultdesg[0]->id;
$catid = $resultdesg[0]->catid;
$SQLcatvalue="SELECT * FROM wp_categories  WHERE id ='$catid' ORDER BY id DESC";
$catvalcurr = $wpdb->get_results($SQLcatvalue);
//print_r($catvalcurr);
$catprimevalue= $catvalcurr[0]->prime_value;
$catprimecurr=$catvalcurr[0]->prime_currency;

echo '<div id="detailsscenario">';
echo '<a href="'.get_site_url().'/wp-admin/admin.php?page=designation&action=designation&type=edit&d_ID='.$resultdesg[0]->id.'">
<img src="'.get_site_url().'/wp-content/uploads/2018/03/editlink.png"></a>';
if($resultdesg[0]->number){
	$target = get_site_url()."/wp-content/plugins/simulate/uploads/".$resultdesg[0]->number;
    $resultCS =  basename($resultdesg[0]->number, ".pdf");
	echo '<p><a target="_blank" href="'.$target.'"><font style="vertical-align: inherit;"><font  style="vertical-align: inherit;">'.$resultCS.'</font></font></a></p>';
}
if($resultdesg[0]->des_name){
echo '<p><b>'.stripslashes($resultdesg[0]->des_name).'</b></p>';
}
echo '</div>';
if($resultdesg[0]->conditions){
echo '<div id="senariodescription">';
echo '<a href="'.get_site_url().'/wp-admin/admin.php?page=designation&action=designation&type=edit&d_ID='.$resultdesg[0]->id.'">
<img src="'.get_site_url().'/wp-content/uploads/2018/03/editlink.png"></a>';
echo '<p><font style="vertical-align: inherit;"><font  style="vertical-align: inherit;">'.stripslashes($resultdesg[0]->conditions).'</font></font></p>';
echo '</div>';
}
echo '<div id="senariometa">';
?>

<section id="projecttypelist" class="tabcontent1">
<form id="posts-filter" method="post">
<h3 style="clear: both; float: left;">Wording Title : </h3>
<img id="addword" src="<?php echo get_site_url();?>/wp-content/uploads/2018/03/add.png" onclick="addnewwording('Submit','<?php echo plugins_url('ajaxfiles/editwording.php' ,dirname(__FILE__));?>','','<?php echo $designid ;?>')"> 
<?php if($catprimevalue){?>
<span class="sa_extra"><label>General Prime Value: </label><b><?php echo $catprimevalue;?> <?php echo $catprimecurr;?></b></span>
<?php } ?>
<?php 
echo get_designationfiles($designid);
?>
</form>
</section>
</div>
		<div class="hover_bkgr_fricc">
		<span class="helper"></span>
		<div>
		<div onclick="closenewwording()" class="popupCloseButton">X</div>
		<div id="forms2" class="wrap">
		</div>
		</div>
		</div>
<?php echo '</div>';
}
?>