<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
$mw_ID = $_POST['word_ID'];
$wm_ID = $_POST['meta_ID'];
$buttontext = $_POST['sbmt'];
$formtype = $_POST['wordtype'];
$title = $_POST['wordtitle'];
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
if($wm_ID){
$SQLwm = "SELECT * FROM ".$table_wording_meta." WHERE id  ='".$wm_ID."' AND word_id  ='".$mw_ID."'";
$wmTPT = $wpdb->get_results($SQLwm);
$subtitlem=$wmTPT[0]->title?$wmTPT[0]->title:'';
$wmTPTd=$wmTPT[0]->word_id;
}		
$Allw = "SELECT * FROM ".$table_wording." WHERE id='".$mw_ID."'";
$wmTPT1 = $wpdb->get_results($Allw);
$desgid=$wmTPT1[0]->desg_id;
$subtitle=$wmTPT1[0]->title;
$wmTPTid=$wmTPT1[0]->id;
?>
<form id="newform4" action="" method="POST" enctype="multipart/form-data">
<h2>Wording Meta Settings of Scenario</h2>
<h2><?php echo $title?$title.' Wording Meta':"Add New Wording Meta";?>  </h2>
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="wmeditid" id="wmeditid" value="<?php echo $wm_ID; ?>">
<input type="hidden" name="location" id="location" value="<?php echo $rurl; ?>">
<p id="designation" style=" border:0px solid gray;">
<label>Wording Title:</label>
<?php 
echo '<input type="hidden" value="'.$wmTPTid.'" id="wordid" name="wordid" class="wordid">';
echo '<input readonly type="text" value="'.$subtitle.'" id="wordidname" name="wordidname" class="wordid">';
?>
</p>
<p><label>Word Meta Title</label><input type="text" name="wmtitle" id="wmtitle" value="<?php echo $subtitlem;?>"></p>
<p><label>Word Meta Value</label><input type="text" name="wmvalue" id="wmvalue" value="<?php echo $wmTPT[0]->value;?>"></p>
<p><label>Is Conditions?</label>
<select name="iscond" id="iscond">
<option value="">Select Value</option>
<option value="Yes" <?php echo ($wmTPT[0]->is_cond=='Yes')?'selected':''; ?>>Yes</option>
<option value="No" <?php echo ($wmTPT[0]->is_cond=='No')?'selected':''; ?>>No</option>
</select>
</p>
<p><label></label><input type="button" class="btn btn-info" onclick="return datametainsertt('<?php echo $wmTPTid; ?>','<?php echo plugins_url('ajaxfiles/save_word_meta.php' ,dirname(__FILE__));?>','wording_meta','<?php echo $formtype; ?>');"  name="<?php echo "wmsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>
