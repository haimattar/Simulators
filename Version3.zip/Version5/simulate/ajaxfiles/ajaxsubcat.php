<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
//echo $_POST["stats"];
if($_POST["stats"]=="getcats"){
$q=$_POST["catids"];
$subcatid=$_POST["subcatid"];
$table = $wpdb->prefix.$_POST['table_name'];
$SQLcatp="SELECT * FROM ".$table."  WHERE catid ='$q'";
$result = $wpdb->get_results($SQLcatp); 
echo "<label>Sub Sectors</label>";
echo '<select id="subsectors" name="subsectors" class="subsectors">';
foreach($result as $row)
{
 if($subcatid==$row->id)
{ $selected="selected"; }else{ $selected="";}
echo '<option value="'.$row->id.'" '.$selected.' >'.$row->category_name.'</option>';
}
echo "</select>";
}
/*
if($_POST["stats"]=="fetchsubcat"){
$q=$_POST["catids"];
$table = $wpdb->prefix.$_POST['table_name'];
$SQLcatp="SELECT * FROM ".$table."  WHERE catid ='$q'";
$result = $wpdb->get_results($SQLcatp); 
echo '<select id="subsectors" class="subsectors" name="fiche" style="max-width: 110px;">';
foreach($result as $row)
{
echo "<option value=".$row->id.">" . $row->des_name. "</option>";
}
echo "</select>";
}
*/

if($_POST["stats"]=="newinsert" || $_POST["stats"]=="newupdate"){
$current_date = date("Y-m-d H:i:s");
$editid=$_POST['editid'];
$table = $wpdb->prefix.$_POST['table_name'];
$desig_numbers = $_FILES["desig_numbers"]["name"];
if(empty($desig_numbers)){
 $SQLcatp="SELECT * FROM ".$table."  WHERE id ='$editid'";
$result = $wpdb->get_results($SQLcatp);    
//print_r($result);
$desgname=$result[0]->number;
}else{
$target = MY_PLUGIN_PATH."uploads/".$desig_numbers;
if(move_uploaded_file($_FILES['desig_numbers']['tmp_name'],$target)){
$desgname=$_FILES["desig_numbers"]["name"];
} }
$desig_title=isset($_POST['desig_title'])?$_POST['desig_title']:'';
$desig_desc=isset($_POST['desig_desc'])?$_POST['desig_desc']:'';
$desig_cond=isset($_POST['desig_cond'])?$_POST['desig_cond']:'';
$desig_aarea=isset($_POST['desig_aarea'])?$_POST['desig_aarea']:'';
$desig_orderpartner=isset($_POST['desig_orderpartner'])?$_POST['desig_orderpartner']:'';
$desgnames=isset($desgname)?$desgname:'';
if(!empty($editid)){
$SQLup = "UPDATE ".$table." SET author='".$_POST['userid']."',des_name='".$desig_title."',description='".$desig_desc."',catid='".$_POST['sectors']."',subcatid='".$_POST['subsectors']."',number='".$desgnames."',order_partner='".$desig_orderpartner."',application_area='".$desig_aarea."',conditions='".$desig_cond."',status='Active',modify='".$current_date."' WHERE id='".$editid."'";
$result=$wpdb->query($SQLup);
$errmsg="Updating";
}else{

$data=array('author' => $_POST['userid'],'des_name' => $desig_title,'description' =>$desig_desc,'catid' =>$_POST['sectors'],
'subcatid' =>$_POST['subsectors'],'number' =>$desgnames,'order_partner' =>$desig_orderpartner,'application_area' =>$desig_aarea,'conditions' =>$desig_cond,'status' => 'Active','created' => $current_date);
$result=$wpdb->insert( $table, $data);
$lastid = $wpdb->insert_id;
$errmsg="Inserting";

}
if($result){
	$msg="Your Data ".$errmsg." Successfully";
	$result='ok';
}else{
	$msg="Something Error";	
	$result='ko';
}
$this_insert=array('lastid'=>$lastid,'result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}

if($_POST["stats"]=="wupdate" || $_POST["stats"]=="wordnew"){
$current_date = date("Y-m-d H:i:s");
$weditid=$_POST['weditid'];
$table = $wpdb->prefix.$_POST['table_name'];
if($_POST['iswmeta']=="Yes"){
$wordvalue='';
$wotherparts='No';
$woptypes='Mult';
$iswmeta=$_POST['iswmeta'];
}
if($_POST['iswmeta']=="No" && $_POST['wotherparts']=="No")
{
$iswmeta=$_POST['iswmeta'];	
$wotherparts=$_POST['wotherparts']?$_POST['wotherparts']:'';
$woptypes='Mult';
$wordvalue='';
}
if($_POST['iswmeta']=="No" && $_POST['wotherparts']=="Yes")
{
$iswmeta=$_POST['iswmeta'];
$wordvalue=$_POST['wordvalue']?$_POST['wordvalue']:'';
$wotherparts=$_POST['wotherparts']?$_POST['wotherparts']:'';
$woptypes=$_POST['woptypes']?$_POST['woptypes']:'';
}
if(!empty($weditid)){
$SQLup = "UPDATE ".$table." SET desg_id='".$_POST['designationid']."',title='".$_POST['wording']."',word_value ='".$wordvalue."'
,is_meta ='".$iswmeta."',otherparts ='".$wotherparts."',optypes ='".$woptypes."' WHERE id='".$weditid."'";
$result=$wpdb->query($SQLup);
$errmsg="Updating";
}else{
$data=array('desg_id' => $_POST['designationid'],'title' => $_POST['wording'],'word_value' =>$wordvalue,
'is_meta' =>$iswmeta,'otherparts'=>$wotherparts,'optypes' =>$woptypes);
$result=$wpdb->insert( $table, $data);
$lastid = $wpdb->insert_id;
$errmsg="Inserting";
}
if($result){
	$msg="Your Data ".$errmsg." Successfully";
	$result='ok';
}else{
	$msg="Something Error";	
	$result='ko';
}
$this_insert=array('lastid'=>$lastid,'result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}


if($_POST["stats"]=="wordmetaupdate" || $_POST["stats"]=="wordmetanew"){
$current_date = date("Y-m-d H:i:s");
$wmeditid=$_POST['wmeditid'];
$table = $wpdb->prefix.$_POST['table_name'];
$wmvalue=$_POST['wmvalue']?$_POST['wmvalue']:'';
if(!empty($wmeditid)){
	$SQLup = "UPDATE ".$table." SET word_id='".$_POST['wordid']."',title='".$_POST['wmtitle']."',value='".$wmvalue."',is_cond ='".$_POST['iscond']."' WHERE id='".$wmeditid."'";
$result=$wpdb->query($SQLup);
$errmsg="Updating";
}else{
$data=array('word_id' =>$_POST['wordid'],'title' =>$_POST['wmtitle'],'value' =>$wmvalue,'is_cond' =>$_POST['iscond']);
$result=$wpdb->insert( $table, $data);
//$lastid = $wpdb->insert_id;
$errmsg="Inserting";
}
if($result){
	$msg="Your Data ".$errmsg." Successfully";
	$result='ok';
}else{
	$msg="Something Error";	
	$result='ko';
}
$this_insert=array('lastid'=>$SQLup,'result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}

/***************************Condition Title Start Here****************************/
if($_POST["stats"]=="metacinditionnew" || $_POST["stats"]=="metacinditionupdate"){
$current_date = date("Y-m-d H:i:s");
$wmcid=$_POST['wmcid'];
$table = $wpdb->prefix.$_POST['table_name'];

if($_POST['iscmeta']=="Yes"){
$wmvalue='';
$oparts='No';
$otypes='Mult';
$iscmeta=$_POST['iscmeta'];
}
if($_POST['iscmeta']=="No" && $_POST['otherparts']=="No")
{
$iscmeta=$_POST['iscmeta'];	
$oparts=$_POST['otherparts']?$_POST['otherparts']:'';
$otypes='Mult';
$wmvalue='';
}
if($_POST['iscmeta']=="No" && $_POST['otherparts']=="Yes")
{
$iscmeta=$_POST['iscmeta'];
$wmvalue=$_POST['wmcvalue']?$_POST['wmcvalue']:'';
$oparts=$_POST['otherparts']?$_POST['otherparts']:'';
$otypes=$_POST['optypes']?$_POST['optypes']:'';
}
	if(!empty($wmcid)){
	$SQLup = "UPDATE ".$table." SET meta_id='".$_POST['metaid']."',word_id='".$_POST['wordid']."',mc_title='".$_POST['mctitle']."',mc_value='".$wmvalue."', 
	is_cond ='".$iscmeta."',otherparts ='".$oparts."',optypes ='".$otypes."' WHERE id='".$wmcid."'";
	$result=$wpdb->query($SQLup);
	$errmsg="Updating";
	}else{
	$data=array('meta_id'=>$_POST['metaid'],'word_id' =>$_POST['wordid'],'mc_title' =>$_POST['mctitle'],'mc_value' =>$wmvalue,
	'is_cond' =>$iscmeta,'otherparts' =>$oparts,'optypes' =>$otypes);
	$result=$wpdb->insert( $table, $data);
	//$lastid = $wpdb->insert_id;
	$errmsg="Inserting";
	}
	if($result){
	$msg="Your Data ".$errmsg." Successfully";
	$result='ok';
	}else{
	$msg="Something Error";	
	$result='ko';
	}
//$this_insert=array('lastid'=>$SQLup,'result'=>$result,'msg'=>$msg);
$this_insert=array('lastid'=>$SQLup,'result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}
/***************************Condition title Ed here****************************/

/***************************Condition Meta Start Here****************************/
if($_POST["stats"]=="conditionvaluenew" || $_POST["stats"]=="conditionvalueedit"){
$current_date = date("Y-m-d H:i:s");
$MCVid=$_POST['MCVid'];
$table = $wpdb->prefix.$_POST['table_name'];
$cvalues=$_POST['cvalue']?$_POST['cvalue']:'';

function rspecial($string,$rp = '') {
    $string = str_replace(' ', ',', $string);
    return preg_replace('/[^A-Za-z0-9\-]/', $rp, $string);
  }
 $cvalue=rspecial($cvalues,'.'); //  output: _index_id_666
	if(!empty($MCVid)){
	$SQLup = "UPDATE ".$table." SET meta_id='".$_POST['metaid']."',word_id='".$_POST['wordid']."',cond_id='".$_POST['condid']."',mc_title='".html_entity_decode($_POST['cvtitle'])."',mc_value='".$cvalue."' WHERE id='".$MCVid."'";
	$result=$wpdb->query($SQLup);
	$errmsg="Updating";
	}else{
	$data=array('meta_id'=>$_POST['metaid'],'word_id' =>$_POST['wordid'],'cond_id'=>$_POST['condid'],'mc_title' =>html_entity_decode($_POST['cvtitle']),'mc_value' =>$cvalue);
	$result=$wpdb->insert( $table, $data);
	//$lastid = $wpdb->insert_id;
	$errmsg="Inserting";
	}
	if($result){
	$msg="Your Data ".$errmsg." Successfully";
	$result='ok';
	}else{
	$msg="Something Error";	
	$result='ko';
	}
//$this_insert=array('lastid'=>$lastid,'result'=>$result,'msg'=>$msg);
$this_insert=array('lastid'=>$lastid,'result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}
/***************************Condition Meta Ed here****************************/




if($_POST["stats"]=="deleteddesignation"){
	global $wpdb;
	$did=$_POST['did'];
	$table = $wpdb->prefix.$_POST['table_name'];
	$errmsg="Deleting";
	$SQLwm="DELETE a,b,c,d,e FROM ".$table."  a 
	LEFT JOIN wp_wording b ON ( a.id = b.desg_id) LEFT JOIN wp_wording_meta c ON ( b.id = c.word_id ) 
	LEFT JOIN wp_meta_conditions d ON ( c.id = d.meta_id) LEFT JOIN wp_meta_conditions_values e ON ( d.id = e.cond_id) WHERE a.id  ='".$did."'";
	$results=$wpdb->query($SQLwm);
	if($results){
	$msg="Your Data Deleted Successfully";
	$result='ok';
	}else{
	$msg="Something Error";	
	$result='ko';
	}	
	$this_insert=array('result'=>$result,'msg'=>'<p>'.$msg.'</p>');
	echo json_encode($this_insert);
	}


if($_POST["stats"]=="deletewording"){
global $wpdb;
$wid=$_POST['wid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE a,b,c,d FROM ".$table."  a 
LEFT JOIN wp_wording_meta b ON ( a.id = b.word_id)
LEFT JOIN wp_meta_conditions c ON ( b.id = c.meta_id)
LEFT JOIN wp_meta_conditions_values d ON ( c.id = d.cond_id)
WHERE a.id  ='".$wid."'";
$results=$wpdb->query($SQLwm);
if($results){
$msg="Your Data Deleted Successfully";
$result='ok';
}else{
$msg="Something Error";	
$result='ko';
}
$this_insert=array('result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}

if($_POST["stats"]=="deletewordingmeta"){
global $wpdb;
$mid=$_POST['mid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE a,b,c FROM ".$table." a
LEFT JOIN wp_meta_conditions b ON ( a.id = b.meta_id)
LEFT JOIN wp_meta_conditions_values c ON ( b.id = c.cond_id)
WHERE a.id  ='".$mid."'";
$results=$wpdb->query($SQLwm);
if($results){
	$msg="Your Data Deleted Successfully";
	$result='ok';
}else{
	$msg="Something Error";	
	$result='ko';
}
$this_insert=array('result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}

if($_POST["stats"]=="deleteconditions"){
global $wpdb;
$cid=$_POST['cid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE a,b FROM ".$table."  a 
LEFT JOIN wp_meta_conditions_values b ON ( a.id = b.cond_id) WHERE a.id  ='".$cid."'";
$results=$wpdb->query($SQLwm);
if($results){
$msg="Your Data Deleted Successfully";
$result='ok';
}else{
$msg="Something Error";	
$result='ko';
}
$this_insert=array('result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}

if($_POST["stats"]=="deleteconditionsvalue"){
global $wpdb;
$cvid=$_POST['cvid'];
$table = $wpdb->prefix.$_POST['table_name'];
$errmsg="Deleting";
$SQLwm="DELETE FROM ".$table."  WHERE id  ='".$cvid."'";
$results=$wpdb->query($SQLwm);
if($results){
$msg="Your Data Deleted Successfully";
$result='ok';
}else{
$msg="Something Error";	
$result='ko';
}
$this_insert=array('result'=>$result,'msg'=>'<p>'.$msg.'</p>');
echo json_encode($this_insert);
}
    


?>