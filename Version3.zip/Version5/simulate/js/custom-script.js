var $ = jQuery.noConflict();
 
function toggleDiv(divId) {
$("#"+divId).toggle();
}
function view_all(viewallurl){
window.location.href= viewallurl;	
} 
function leaveChange(str){
	document.getElementById('iscmetaop').style.display = "none";
	if(str=="No"){
    document.getElementById('iscmetaop').style.display = "block";
	document.getElementById('wotherparts').value = "";
   } else{
    document.getElementById('iscmetaop').style.display = "none";
	document.getElementById('iscmetaop2').style.display = "none";
	document.getElementById('iscmetaop1').style.display = "none";
	var selectedString = select.options[select.selectedIndex].value;
    alert(selectedString);
   }
}
function leaveChange1(str){
	if(str=="No" || str=="" ){
	document.getElementById('iscmetaop2').style.display = "none";
	document.getElementById('iscmetaop1').style.display = "none";
	document.getElementById('iscmetaop1').value = "";
	} else{
	document.getElementById('iscmetaop2').style.display = "block";
	document.getElementById('iscmetaop1').style.display = "block";
	}
}
function cmcChange(str){
   if(str=="")
   {
       document.getElementById('iscmetacv').style.display = "none";
   }
   else if(str=="No"){
	document.getElementById('iscmetacv').style.display = "block";
	} else{
		document.getElementById('cvalue').value = "";
	document.getElementById('iscmetacv').style.display = "none";
	
	}
}
function leaveChange6(str){
	if(str=="" ){
	document.getElementById('iscmetaop1').style.display = "none";
	} else{
	document.getElementById('iscmetaop1').style.display = "block";
	}
}
function  showSubcat(str,url,tname)
{
  
  var subcat=$('#subcat').val();
   var strs="getcats";
	$.ajax({
	   type: "POST",
	   data: {"stats":strs,"catids":str,"table_name":tname,"subcatid":subcat},
	   url: url,
	   success: function(msg){
//	alert("Status updated successfully!");
		$('#txtHint').html(msg);
	   },
	   error: function(){
		$('#txtHint').html(msg);
	   }
	});
}

function datainsert(url,tname,strs){
 // alert (strs); 
var formData = new FormData($("#newform")[0]);
formData.append('table_name', tname);
formData.append('stats', strs);
//alert (formData);
var location_url=document.getElementById('location').value;
           var dsubsectors=document.getElementById("subsectors");
             var dsectors=document.getElementById("sectors");
            var dtitle=document.getElementById("desig_title");
            var dnumbers=document.getElementById("desig_numbers");
            var file= dnumbers.value;
            var reg = /(.*?)\.(pdf|docs|jpeg|png)$/;           
            if(dsectors.value==""){
            dsectors.focus();
            //dsectors.style.border= "1px solid red";   
            return false;
            }
            if(dsubsectors.value==""){
            dsubsectors.focus();
            //dsubsectors.style.border= "1px solid red";   
            return false;
            }
            if(dtitle.value==""){
            dtitle.focus();
           // dtitle.style.border= "1px solid red";   
            return false;
            }
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                contentType: false,       // The content type used when sending data to the server.
                cache: false,             // To unable request pages to be cached
                processData:false,  
                url: url,
				//dataType:'text',
				success: function(results){
				    //alert (results);
    			var obj = jQuery.parseJSON( results );
				if( obj.result === "ok" ){
				$('#rdata').html(obj.msg);
				setTimeout(function () {
				window.location.href = location_url;
				}, 1000);
				}
				},
                error: function(){
                 $('#rdata').html(results);
                }
	           });
    }
function datawordinginsert(url,tname,strs){
//alert (strs); 
var formData = new FormData($("#newform3")[0]);
formData.append('table_name', tname);
formData.append('stats', strs);
			var location_url=document.getElementById('location').value;
			var designationid=document.getElementById("designationid");
			var wording=document.getElementById("wording");    
			var ismeta=document.getElementById("iswmeta");
			if(designationid.value==""){
			designationid.focus();
			return false;
			}
			if(wording.value==""){
			wording.focus();
			return false;
			}
			if(ismeta.value==""){
			ismeta.focus();
			return false;
			}
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			contentType: false,       // The content type used when sending data to the server.
			cache: false,             // To unable request pages to be cached
			processData:false,  
			url: url,
			//dataType:'text',
			success: function(results){
			//	alert (results);
			var obj = jQuery.parseJSON( results );
			if( obj.result === "ok" ){
			$('#response').html(obj.msg);
			setTimeout(function () {
			window.location.href = location_url;
			}, 1000);
			}
			},
			error: function(){
			$('#response').html(results);
			}
			});
    }
function datametainsert(url,tname,strs){
		// alert (strs); 
		var formData = new FormData($("#newform4")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		//alert (formData);
		var location_url=document.getElementById('location').value;
		var iscond=document.getElementById("iscond");
		var wmtitle=document.getElementById("wmtitle");
		var wmvalue=document.getElementById("wmvalue");
		
		if(wmtitle.value==""){
		wmtitle.focus();
		//wmtitle.style.border= "1px solid red";   
		return false;
		}
		if(iscond.value==""){
		iscond.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datas){
		//alert (datas);
		var obj = jQuery.parseJSON( datas );
		if( obj.result === "ok" ){
		$('#rdata').html(obj.msg);
		setTimeout(function () {
		window.location.href = location_url;
		}, 1000);
		}else{
		$('#response').html(obj.msg);
		}
		},
		error: function(){
		$('#response').html(datas);
		}
		});
    }
	
function datametacondinsert(url,tname,strs){
			var formData = new FormData($("#newform6")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		//alert (formData);
		var location_url=document.getElementById('location').value;
		var metatitle=document.getElementById("mctitle");
		var iscmeta=document.getElementById("iscmeta");
		if(metatitle.value==""){
		metatitle.focus();
		return false;
		}
		if(iscmeta.value==""){
		iscmeta.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datac){
		//alert (datac);
		var obj = jQuery.parseJSON( datac );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		setTimeout(function () {
		window.location.href = location_url;
		}, 1000);
		}else{
		$('#response').html(obj.msg);
		}
		},
		error: function(){
		$('#rdata').html(datac);
		}
		});
	}	
	function metacondvalueinsert(url,tname,strs){
		//alert (url+tname+strs);
			var formData = new FormData($("#newform7")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		//alert (formData);
		var location_url=document.getElementById('location').value;
		var cvtitle=document.getElementById("cvtitle");
		var cvalue=document.getElementById("cvalue");
		if(cvtitle.value==""){
		cvtitle.focus();
		return false;
		}
		if(cvalue.value==""){
		cvalue.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datacv){
		//alert (datacv);
		var obj = jQuery.parseJSON( datacv );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		setTimeout(function () {
		window.location.href = location_url;
		}, 1000);
		}else{
		$('#response').html(obj.msg);
		}
		},
		error: function(){
		$('#rdata').html(datac);
		}
		});
	}
	
	function delete_wording(tname,url,ids,strs){
	//alert (tname+url+ids+strs);
		var wordlocation_url=document.getElementById('location').value;
if(confirm("Do you want to delete?")){
$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"wid":ids,"stats":strs},
		url: url,
		success: function(dataw){
		//alert (dataw);
		var obj = $.parseJSON( dataw );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		$('#response').show();
			setTimeout(function () {
			window.location.href = wordlocation_url;
			}, 1000);
		}else{
		$('#response').html(obj.msg);
		$('#response').show();
		}
		},
		error: function(){
		$('#response').html(dataw);
		$('#response').show();
		}
});
}
}
function delete_wordmeta(tname,url,ids,strs){
	var metalocation_url=document.getElementById('location').value;
if(confirm("Do you want to delete?")){
	//alert (tname+url+ids+strs);
 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"table_name":tname,"mid":ids,"stats":strs},
                url: url,
				success: function(datas){
				   // alert (datas);
    			var obj = $.parseJSON( datas );
				if( obj.result === "ok" ){
			$('#response').html(obj.msg);
			$('#response').show();
				setTimeout(function () {
				window.location.href = metalocation_url;
				}, 1000);
				}else{
				   $('#response').html(obj.msg);
				   $('#response').show();
				    }
				},
                error: function(){
                 $('#response').html(datas);
				 $('#response').show();
                }
	           });
}
}
function delete_cond(tname,url,ids,strs){
		//alert (tname+url+ids+strs);
		var condlocation_url=document.getElementById('location').value;
		if(confirm("Do you want to delete?")){
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"cid":ids,"stats":strs},
		url: url,
		success: function(datamc){
		// alert (datamc);
		var obj = $.parseJSON( datamc );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		$('#response').show();
		setTimeout(function () {
		window.location.href = condlocation_url;
		}, 1000);
		}else{
		$('#response').html(obj.msg);
		$('#response').show();
		}
		},
		error: function(){
		$('#response').html(datamc);
		$('#response').show();
		}
		});
		}
}

function delete_condvalue(tname,url,ids,strs){
		//alert (tname+url+ids+strs);
		var condlocationv_url=document.getElementById('location').value;
		if(confirm("Do you want to delete?")){
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"cvid":ids,"stats":strs},
		url: url,
		success: function(datamcv){
		// alert (datamcv);
		var obj = $.parseJSON( datamcv );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		$('#response').show();
		setTimeout(function () {
		window.location.href = condlocationv_url;
		}, 1000);
		}else{
		$('#response').html(obj.msg);
		$('#response').show();
		}
		},
		error: function(){
		$('#response').html(datamcv);
		$('#response').show();
		}
		});
		}
}
function  showSubcat(str,url,tname)
{
	//alert (str+url+tname);
  var strs="getsubcats";
	$.ajax({
	   type: "POST",
	   data: {"stats":strs,"catids":str,"table_name":tname},
	   url: url,
	   success: function(msg){
//	alert("Status updated successfully!");
		$('#txtHints').html(msg);
	   },
	   error: function(){
		$('#txtHints').html(msg);
	   }
	});
}
function  showDesignation(str,url,tname,URLs)
{
	//alert (str+url+tname);
  var strs="fetchdesig";
	$.ajax({
	   type: "POST",
	   data: {"stats":strs,"catids":str,"table_name":tname,"URLS":URLs},
	   url: url,
	   success: function(msg){
//	alert("Status updated successfully!");
		$('#senariopdflist').html(msg);
	   },
	   error: function(){
		$('#senariopdflist').html(msg);
	   }
	});
}
function getdestinationsdata(id,sid,urls){
var strs="fetchdesignationdata";
$.ajax({
type: "POST",             // Type of request to be send, called as method
data: {"stats":strs,"destiid":id,"URLS":urls},
url: urls,
success: function(msg){
$('#resultlistd').html(msg);
},
error: function(){
$('#resultlistd').html(msg);
}
});
}
/************************WORDING DATA***************************************/
function addnewwording(sbmt,pageurl,wid,desgid)
{
	//alert (sbmt+pageurl+wid+desgid);
		var wordtype='wordnew';
		var wordtitle='Add New';
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"desgid":desgid,"word_ID":wid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
		url: pageurl,
		success: function(msgformdatasupdates){
		$('.hover_bkgr_fricc').show();
		$("#forms2").html(msgformdatasupdates);
		},
		error: function(){  
		}
		});
}

function editwording(sbmt,pageurl,wid,desgid)
{
		var wordtype='wupdate';
		var wordtitle='Edit';
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"desgid":desgid,"word_ID":wid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
		url: pageurl,
		success: function(msgformdatasupdates){
		//alert(msgformdatasupdates);
		$('.hover_bkgr_fricc').show();
		$("#forms2").html(msgformdatasupdates);
		},
		error: function(){  
		}
		});
}

function closenewwording()
{
	$('.hover_bkgr_fricc').hide();
}

function datawordinginsertt(wid,desgid,url,tname,strs)
{
	//alert (desgid+url+tname+strs);
//alert (strs); 
var formData = new FormData($("#newform3")[0]);
formData.append('table_name', tname);
formData.append('stats', strs);
			//var location_url=document.getElementById('location').value;
			var designationid=document.getElementById("designationid");
			var wording=document.getElementById("wording");    
			var ismeta=document.getElementById("iswmeta");
			if(designationid.value==""){
			designationid.focus();
			return false;
			}
			if(wording.value==""){
			wording.focus();
			return false;
			}
			if(ismeta.value==""){
			ismeta.focus();
			return false;
			}
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			contentType: false,       // The content type used when sending data to the server.
			cache: false,             // To unable request pages to be cached
			processData:false,  
			url: url,
			success: function(dataw){
		$('.hover_bkgr_fricc').hide();
			$("#wordingsection"+desgid).replaceWith(dataw);
		},
		error: function(){
		$('#wordingsection'+desgid).html(dataw);
		}
			});
}
	

/*****************************Meta Section********************************************/
function add_wordmeta(sbmt,pageurl,mid,wordid){
			var wordtype='wordmetanew';
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"word_ID":wordid,"meta_ID":mid,"sbmt":sbmt,"wordtype":wordtype},
			url: pageurl,
			success: function(wordingmeta){
			//alert (wordingmeta);
			$('.hover_bkgr_fricc').show();
			$("#forms2").html(wordingmeta);
			},
			error: function(){  
			}
			});
}

function editmeta(sbmt,pageurl,mid,wordid){
		var wordtype='wordmetaupdate';
		var wordtitle='Edit';
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"meta_ID":mid,"word_ID":wordid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
		url: pageurl,
		success: function(msgformdatasupdates){
		//alert(msgformdatasupdates);
		$('.hover_bkgr_fricc').show();
		$("#forms2").html(msgformdatasupdates);
		},
		error: function(){  
		}
		});
}
function datametainsertt(wordid,url,tname,strs){
		// alert (strs); 
		var formData = new FormData($("#newform4")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		//alert (formData);
		//var location_url=document.getElementById('location').value;
		var iscond=document.getElementById("iscond");
		var wmtitle=document.getElementById("wmtitle");
		var wmvalue=document.getElementById("wmvalue");
		
		if(wmtitle.value==""){
		wmtitle.focus();
		//wmtitle.style.border= "1px solid red";   
		return false;
		}
		if(iscond.value==""){
		iscond.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datas){
		$('.hover_bkgr_fricc').hide();
			$("#a1wordingmetaid"+wordid).replaceWith(datas);
		},
		error: function(){
		$('#a1wordingmetaid').html(datas);
		}
		});
	
}
/*****************************Conditional Title********************************************/
function add_metacondtitle(sbmt,pageurl,condid,metaid){
	//alert (sbmt+'-'+pageurl+'-'+condid+'-'+metaid)
	var wordtype='metacinditionnew';
		var wordtitle='New';
		$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"mc_ID":condid,"meta_ID":metaid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
			url: pageurl,
			success: function(metacondition){
				//alert (metacondition);
			$('.hover_bkgr_fricc').show();
			$("#forms2").html(metacondition);
			},
			error: function(){  
			}
			});
	
}

function edit_metacond(sbmt,pageurl,condid,metaid){
		var wordtype='metacinditionupdate';
		var wordtitle='Edit';
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"mc_ID":condid,"meta_ID":metaid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
		url: pageurl,
		success: function(metacondition){
		//alert(metacondition);
		$('.hover_bkgr_fricc').show();
		$("#forms2").html(metacondition);
		},
		error: function(){  
		}
		});
}

function insertcondinserttitle(metaid,url,tname,strs){
			var formData = new FormData($("#newform6")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		var metatitle=document.getElementById("mctitle");
		var iscmeta=document.getElementById("iscmeta");
		if(metatitle.value==""){
		metatitle.focus();
		return false;
		}
		if(iscmeta.value==""){
		iscmeta.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(dataw){
			//alert (dataw);
			$('.hover_bkgr_fricc').hide();
		$("#metacondtitles"+metaid).replaceWith(dataw);
		},
		error: function(){
		$("#metacondtitles"+metaid).html(dataw);
		}
		});
	}	
/************************Condition value Section************************************/

function add_condvalues(sbmt,pageurl,cvid,condid)
		{
		var wordtype='conditionvaluenew';
		var wordtitle='New';
		$.ajax({
				type: "POST",             // Type of request to be send, called as method
				data: {"cond_id":condid,"cv_ID":cvid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
				url: pageurl,
				success: function(metacondition){
				$('.hover_bkgr_fricc').show();
				$("#forms2").html(metacondition);
				},
				error: function(){  
				}
			});
		}

function edit_condvalue(sbmt,pageurl,cvid,condid){
		var wordtype='conditionvalueedit';
		var wordtitle='Edit';
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"cond_id":condid,"cv_ID":cvid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
		url: pageurl,
		success: function(msgformdatasupdates){
		//alert(msgformdatasupdates);
		$('.hover_bkgr_fricc').show();
		$("#forms2").html(msgformdatasupdates);
		},
		error: function(){  
		}
		});
}



function condvalueinsert(condid,url,tname,strs)
{
		//alert (url+tname+strs);
		var formData = new FormData($("#newform7")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		var cvtitle=document.getElementById("cvtitle");
		var cvalue=document.getElementById("cvalue");
		if(cvtitle.value==""){
		cvtitle.focus();
		return false;
		}
		/*if(cvalue.value==""){
		cvalue.focus();
		return false;
		}*/
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datacv){
		$('.hover_bkgr_fricc').hide();
		$("#metacondvalues"+condid).replaceWith(datacv);
		},
		error: function(){
		$("#metacondvalues"+condid).replaceWith(datacv);
		}
		});	
}

/*************************Delete Sections****************************************/
function delete_word(tname,url,ids,strs,desgid){
//alert (tname+url+ids+strs);
if(confirm("Do you want to delete?")){
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"wid":ids,"stats":strs,"designationid":desgid},
		url: url,
		success: function(dataw){
		$("#wordingsection"+desgid).replaceWith(dataw);
		},
		error: function(){
		$("#wordingsection"+desgid).html(dataw);
		}
		});
}
}
function delete_wordmetadata(tname,url,ids,strs,wordid){
	//alert (tname+url+ids+strs);
if(confirm("Do you want to delete?")){
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"table_name":tname,"mid":ids,"stats":strs,"wordid":wordid},
			url: url,
			success: function(datas){
			$("#a1wordingmetaid"+wordid).replaceWith(datas);			
			},
			error: function(){
			$("#a1wordingmetaid"+wordid).html(datas);
			}
			});
}
}
function delete_conditiontitle(tname,url,ids,strs,metaid){
	//alert (tname+url+ids+strs);
if(confirm("Do you want to delete?")){
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"table_name":tname,"cid":ids,"stats":strs,"metaid":metaid},
			url: url,
			success: function(datas){
			$("#metacondtitles"+metaid).replaceWith(datas);			
			},
			error: function(){
			$("#metacondtitles"+metaid).html(datas);
			}
			});
}
}
function delete_condvalues(tname,url,ids,strs,metaid){
	//alert (tname+url+ids+strs);
if(confirm("Do you want to delete?")){
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"table_name":tname,"cvid":ids,"stats":strs,"condid":metaid},
			url: url,
			success: function(datas){
			$("#metacondvalues"+metaid).replaceWith(datas);			
			},
			error: function(){
			$("#metacondvalues"+metaid).html(datas);
			}
			});
}
}
function  SearchDesignation(urls)
{
			var id=$('#des_name').val();
			var strs="fetchdesignationdata";
			var searchvar="searchsenario";
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"stats":strs,"destiid":id,"searchvar":searchvar},
			url: urls,
			success: function(msg){
			$('#resultlistd').html(msg);
			},
			error: function(){
			$('#resultlistd').html(msg);
			}
			});
}
/*---------------------------------Condition Meta Condition--------------------------------*/
function add_condmetacondtitle(sbmt,pageurl,cmcid,condid){
	//alert (sbmt+'-'+pageurl+'-'+condid+'-'+metaid)
	var wordtype='metacinditionnew';
		var wordtitle='New';
		$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"cmc_ID":cmcid,"cond_ID":condid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
			url: pageurl,
			success: function(metacondition){
				//alert (metacondition);
			$('.hover_bkgr_fricc').show();
			$("#forms2").html(metacondition);
			},
			error: function(){  
			}
			});
	
}
function add_cmcvalue(sbmt,pageurl,cmcvid,cmcid){
	//alert (sbmt+'-'+pageurl+'-'+condid+'-'+metaid)
	var wordtype='cmetacvaluenew';
		var wordtitle='New';
		$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: {"cmcv_ID":cmcvid,"cmc_id":cmcid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
			url: pageurl,
			success: function(cmcvdata){
			$('.hover_bkgr_fricc').show();
			$("#forms2").html(cmcvdata);
			},
			error: function(){  
			}
			});
	
}
function leaveChangeadd(str){
	document.getElementById('iscmetacop').style.display = "none";
	if(str=="No"){
    document.getElementById('iscmetacop').style.display = "block";	
	document.getElementById('cmcotherparts').style.display = "inline-block";
   } else{
    document.getElementById('iscmetacop').style.display = "none";
	document.getElementById('cmcotherparts').style.display = "none";
	document.getElementById('iscmetacop1').style.display = "none";
	document.getElementById('iscmetacop2').style.display = "none";
   }
}
function leaveChange2(str){
	if(str=="No" || str=="" ){
	document.getElementById('iscmetacop2').style.display = "none";
	document.getElementById('iscmetacop1').style.display = "none";
	document.getElementById('iscmetacop1').value = "";
	} else{
	document.getElementById('iscmetacop2').style.display = "block";
	document.getElementById('iscmetacop1').style.display = "block";
	}
}
function leaveChange7(str){
	if(str=="" ){
	document.getElementById('iscmetacop1').style.display = "none";
	} else{
	document.getElementById('iscmetacop1').style.display = "block";
	}
}
function edit_condmetacond(sbmt,pageurl,cmcid,condid){
		var wordtype='metacinditionupdate';
		var wordtitle='Edit';
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"cmc_ID":cmcid,"cond_ID":condid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
		url: pageurl,
		success: function(metacondition){
		//alert(metacondition);
		$('.hover_bkgr_fricc').show();
		$("#forms2").html(metacondition);
		},
		error: function(){  
		}
		});
}

function edit_cmcvalue(sbmt,pageurl,cmcvid,cmcid){
		var wordtype='cmetacvalueedit';
		var wordtitle='Edit';
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"cmcv_ID":cmcvid,"cmc_id":cmcid,"sbmt":sbmt,"wordtype":wordtype,"wordtitle":wordtitle},
		url: pageurl,
		success: function(cmcvdata){
		$('.hover_bkgr_fricc').show();
		$("#forms2").html(cmcvdata);
		},
		error: function(){  
		}
		});	
}



function insertcondmetaconditiontitle(condid,url,tname,strs){
			//alert (condid);
			var formData = new FormData($("#newform8")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		var metatitle=document.getElementById("cmctitle");
		var iscmeta=document.getElementById("iscmetac");
		var cmcotherparts=document.getElementById("cmcotherparts");
		var optypes=document.getElementById("optypes");
		var cmcvalue=document.getElementById("cmcvalue");
		
		
		if(metatitle.value==""){
		metatitle.focus();
		return false;
		}
		if(iscmeta.value==""){
		iscmeta.focus();
		return false;
		}
		if(iscmeta.value=="No" && cmcotherparts.value==""){
		cmcotherparts.focus();
		return false;
		}
		if(iscmeta.value=="No" && cmcotherparts.value=="Yes" && optypes.value==""){
		optypes.focus();
		return false;
		}
		if(iscmeta.value=="No" && cmcotherparts.value=="Yes" && optypes.value!="" && cmcvalue.value==""){
		cmcvalue.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datacmc){
		//	alert (dataw);
		$('.hover_bkgr_fricc').hide();
		$("#condmetacondtitles"+condid).replaceWith(datacmc);
		},
		error: function(){
		$("#condmetacondtitles"+condid).html(datacmc);
		}
		});
	}	


function cmcvalueinsert(cmcid,url,tname,strs){
			//alert (condid);
			var formData = new FormData($("#newform9")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		var cmcvtitle=document.getElementById("cmcvtitle");
		var cmcotherparts=document.getElementById("cmcotherparts");
		var optypes=document.getElementById("optypes");
		var cmcvalue=document.getElementById("cmcvalue");
		
		if(cmcvtitle.value==""){
		cmcvtitle.focus();
		return false;
		}
		if(cmcvalue.value==""){
		cmcvalue.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datacmcv){
		//alert (datacmcv);
		$('.hover_bkgr_fricc').hide();
		$("#condmetacondvalues"+cmcid).replaceWith(datacmcv);
		},
		error: function(){
		//$("#condmetacondvalues"+cmcid).html(datacmcv);
		}
		});
	}	
	
function delete_cmctitle(tname,url,cmcids,strs,condid){
		//alert (tname+url+cmcids+strs+condid);
		if(confirm("Do you want to delete?")){
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"cmcid":cmcids,"stats":strs,"cmetacid":condid},
		url: url,
		success: function(datacmc){
		//	alert (datacmc);
		$("#condmetacondtitles"+condid).replaceWith(datacmc);			
		},
		error: function(){
		$("#condmetacondtitles"+condid).html(datacmc);
		}
		});
		}
}
function delete_cmcvalue(tname,url,cmcvids,strs,condid){
		//alert (tname+url+cmcvids+strs+condid);
		if(confirm("Do you want to delete?")){
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"cmcvid":cmcvids,"stats":strs,"cmcid":condid},
		url: url,
		success: function(datacmc){
			//alert (datacmc);
		$("#condmetacondvalues"+condid).replaceWith(datacmc);			
		},
		error: function(){
		$("#condmetacondvalues"+condid).html(datacmc);
		}
		});
		}
}