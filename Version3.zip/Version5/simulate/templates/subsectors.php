<?php global $wpdb;
@session_start();
$adminurl = admin_url();
$siteurl = get_option("siteurl");
$tablename= $wpdb->prefix . "subcategory";
$current_date = date("Y-m-d H:i:s");
$SQLcat = "SELECT * FROM $tablename";
$allCategoriess = $wpdb->get_results($SQLcat);
$total = count($allCategoriess);

 //===========Paging=============//
$items_per_page =5;	
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;
$SQLcatp = "SELECT * FROM $tablename  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
$allCategories = $wpdb->get_results($SQLcatp); 

if($_GET['type']=='edit'){
$type=$_GET['type']=='edit';
$editids=$_GET['edit_ID'];
}
else if($_GET['type']=='delet'){
$type=	$_GET['type']=='del';
$delids=$_GET['del_ID'];
}
$parentcatid=$_POST['parentcatid'];
if($_GET['type']=='edit' && $_GET['action']=="subsector"){
$title="Edit Sub Sector";
$buttontext="Update";
$aurl=$adminurl."admin.php?page=sectors&action=subsector";						
$addurl='<a class="page-title-action" id="addnewurl" href="'.$aurl.'">Add Sub Sector</a>';
$SQLecat = "SELECT * FROM $tablename WHERE id  LIKE '%".$editids."%'";
$edCat = $wpdb->get_results($SQLecat);
$id=$edCat[0]->id;
if(isset($_POST['Update'])){
$cat_name=$_POST['catname'];
$parentcatid=$_POST['parentcatid'];
$catdescription=$_POST['catdescription'];
$SQLup = "UPDATE ".$tablename." SET catid='".$parentcatid."',category_name='".$cat_name."',description='".$catdescription."'
,modify='".$current_date."' WHERE id='".$id."'";
$c=$wpdb->query($SQLup);
if($c){
$_SESSION['id']="success";
$_SESSION['SuccessMsg']="Record Updated Successfully";
wp_redirect($siteurl."/wp-admin/admin.php?page=sectors&action=subsector");	
exit;
}
}
}else if($_GET['type']=='delet' && $_GET['action']=="subsector"){
$SQLD = "DELETE FROM $tablename WHERE id =$delids";
$Del=$wpdb->query($SQLD);
if($Del){
$_SESSION['id']="success";
$_SESSION['SuccessMsg']="Record Deleted Successfully";
wp_redirect($siteurl."/wp-admin/admin.php?page=sectors&action=subsector");	
exit; 
}else{
$_SESSION['id']="error";
$_SESSION['SuccessMsg']="Record Deleted Error";
}
}else {
if(isset($_POST['Submit'])){
$cat_name=$_POST['catname'];
$parentcatid=$_POST['parentcatid'];
$catdescription=$_POST['catdescription'];
if(empty($cat_name)){
$_SESSION['SuccessMsg']="Enter Sub Sector Name.........";		
}
else
{
global $wpdb;
	
$data=array('catid'=>$parentcatid,'category_name' =>$cat_name, 'description' => $catdescription,
'status' => 'Active','created' => $current_date);
$insert=$wpdb->insert( $tablename, $data);
$_SESSION['id']="success";
$_SESSION['SuccessMsg']="Sub Sector added Successfully";
wp_redirect($siteurl."/wp-admin/admin.php?page=sectors&action=subsector");	
exit;
}
}
$title="Add Sub Sector";
$buttontext="Submit";
$aurl=$adminurl."admin.php?page=sectors";						
$addurl='<a class="page-title-action" id="addnewurl" href="'.$aurl.'">Back Main Category</a>';
}
global $wpdb;
$tablenamep= $wpdb->prefix . "categories";
$SQLcat = "SELECT * FROM $tablenamep";
$allParentCategories = $wpdb->get_results($SQLcat);
?>
<div id="primary" class="content-area">
<div id="wrapper">
<div id="col-container" class="wp-clearfix">
<div id="col-left">
<div class="form-wrap wrap">
<h2><?php echo $title?$title:"";?> <?php echo $addurl; ?></h2>
<?php if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php } ?>
<form id="addcat" method="post" action="" class="validate">
<div class="form-field form-required term-name-wrap">
<label for="catname">Name</label>
<input name="catname" id="catname" value="<?php echo $edCat[0]->category_name?$edCat[0]->category_name:''; ?>" size="40" aria-required="true" type="text">
</div>
<div class="form-field form-required term-name-wrap">
<h2 for="catname">Parent Sectors</h2>
<select id="parentcat" name="parentcatid">
<?php 
foreach($allParentCategories as $pcat){
$selected = ($edCat[0]->catid == $pcat->id) ? 'selected="selected"' : '';
echo '<option  value="'.$pcat->id.'" '.$selected.'>'.$pcat->category_name.' </option>';
}
?>
</select>
</div>
<div class="form-field term-description-wrap">
<label for="cat-description">Description</label>
<textarea name="catdescription" id="catdescription" rows="5" cols="40"><?php echo $edCat[0]->description?$edCat[0]->description:''; ?></textarea>
</div>
<p class="submit"><input name="<?php echo $buttontext;?>" id="submit" class="button button-primary" value="<?php echo $buttontext;?>" type="submit"></p>
</form>
</div>
</div><!-- /col-left -->
<div id="col-right">
<div class="col-wrap">
<h2 class="1screen-reader-text">Sectors Lists</h2>
<table class="wp-list-table widefat fixed striped cats">
	<thead>
	<tr><th id="cb" class="manage-column column-cb check-column">
	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
	<span><a href="#">P.ID</a></span></th>
	<th scope="col" id="name" class="manage-column column-name column-primary sortable desc">
	<a href="#"><span>Name</span><span class="sorting-indicator"></span></a></th>
	<th scope="col" id="name" class="manage-column column-name column-primary sortable desc">
	<a href="#"><span>Parent Sectors</span><span class="sorting-indicator"></span></a></th>
	<th scope="col" id="description" class="manage-column column-description sortable desc"><a href="#"><span>Description</span><span class="sorting-indicator"></span></a></th><th scope="col" id="posts" class="manage-column column-posts num sortable desc"><a href="#"><span>Status</span><span class="sorting-indicator"></span></a></th>	</tr>
	</thead>
<tbody id="the-list" data-wp-lists="list:cat">
		<?php 
global $wpdb;

            if(count($allCategories)>0){ 
            foreach($allCategories as $pc){
            $pcid=$pc->id;
            $catid=$pc->catid;
            $SQEDIT = "SELECT * FROM wp_categories WHERE id  = '".$catid."'";
$SQEDIT = $wpdb->get_results($SQEDIT);
             ?>
			<tr id="cat-2">			
			<th scope="row" class="check-column">
			<label class="screen-reader-tex1t" for="cb-select-2"><?php echo $pcid; ?></label>
			</th>			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="(Edit)"><?php echo $pc->category_name;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=sectors&action=subsector&type=edit&edit_ID=<?php echo $pcid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> | </span><span class="delete"><a role="button" href="<?php echo $adminurl;?>admin.php?page=sectors&action=subsector&type=delet&del_ID=<?php echo $pcid; ?>" class="delete-cat aria-button-if-js" aria-label="Delete “a”">Delete</a> | </span></div>
			</td>
            
            <td class="description column-description" data-colname="Description">
            <span class="tscreen-reader-text"><?php echo $SQEDIT[0]->category_name; ?></span></td>

			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo $pc->description;?></span></td>
			<td class="posts column-posts" data-colname="Count"><a href="#"><?php echo $pc->status;?></a></td>
			</tr>
<?php       }
            }
			else
			{
			?>
			<tr id="cat-2">			
			<th scope="row" class="check-column">
			</th>			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"></a></strong><br>
			</td>
			<td class="description column-description" data-colname="Description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts" data-colname="Count">
			<a href="#"></a></td>
			</tr>	
			<?php } ?>			
			</tbody>
			<tfoot>
	<tr>
		<th id="cb"  class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-2">Select All</label><span><a href="#">P.ID</a></span></th><th scope="col" class="manage-column column-name column-primary sortable desc"><a href="#"><span>Name</span><span class="sorting-indicator"></span></a></th><th scope="col" class="manage-column column-description sortable desc"><a href="#"><span>Description</span><span class="sorting-indicator"></span></a></th><th scope="col" class="manage-column column-posts num sortable desc"><a href="#"><span>Count</span><span class="sorting-indicator"></span></a></th>	</tr>
	</tfoot>
	<section id="pagination">
	<?php echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total/$items_per_page),
        'current' => $page
    ));?>
	</section>
</table>

</div>
</div><!-- /col-right -->
</div>
</div>
</div>