<?php 
global $wpdb;
$adminurl = admin_url();
$current_date = date("Y-m-d H:i:s");
$table_category = $wpdb->prefix . "categories";
$table_subcategory= $wpdb->prefix . "subcategory";
$table_desig = $wpdb->prefix . "designations";
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
$table_meta_conditions=$wpdb->prefix."meta_conditions";
$table_neta_conditionsvalue=$wpdb->prefix."meta_conditions_values";
$currentuserid=get_current_user_id();
//------------------------------------------
$designation=$adminurl."admin.php?page=designation&action=designation";
$deswording=$adminurl."admin.php?page=designation&action=deswording";
$wordmeta=$adminurl."admin.php?page=designation&action=wordmeta";


$wtaddurl='<a class="page-title-action" id="addnewurl" href="'.$deswording.'">Back List</a>';
$wmtaddurl='<a class="page-title-action" id="addnewurl" href="'.$wordmeta.'">Back List</a>';

/**********************Designation Start**************************/
if($_GET['action']=="designation"){?>
	<script>
window.onload = function() {
document.getElementById('sectors').onchange();
};	  
    </script> <?php 
if($_GET['type']=='edit' && $_GET['action']=="designation"){
		$title="Edit";
		$buttontext="Update";
		$formtype="newupdate"; 
		$durl='';
		$d_ID=$_GET['d_ID'];
		$SQLd = "SELECT * FROM ".$table_desig." WHERE id  ='".$d_ID."'";
		$desTPT = $wpdb->get_results($SQLd);
		$desgnnumber=$desTPT[0]->id;
$designation=$adminurl."admin.php?page=designation&action=scenario&type=scenarioslist&des_name=$desgnnumber";
$ptaddurl='<a class="page-title-action" id="addnewurl" href="'.$designation.'">Back List</a>';
}
if($_GET['type']=='new' && $_GET['action']=="designation"){
		$title="Add New";
		$buttontext="Submit";
		$formtype="newinsert"; 
		$durl='';
$designation=$adminurl."admin.php?page=designation&action=designation";    
$ptaddurl='<a class="page-title-action" id="addnewurl" href="'.$designation.'">Back List</a>';

}
if($_GET['type']=='delete' && $_GET['action']=="designation"){
		$dd_ID=$_GET['d_ID'];
		$SQLd = "DELETE  * FROM ".$table_desig." WHERE id  ='".$dd_ID."'";
		$desTPT = $wpdb->get_results($SQLd);
}
}
/**********************Designation End**************************/


/**********************Wording Start**************************/
if($_GET['action']=="deswording"){
if($_GET['type']=='edit' && $_GET['action']=="deswording"){
		$title="Edit";
		$buttontext="Update";  
		$formtype="wupdate"; 
		$w_ID=$_GET['w_ID'];
		//$rurl=$deswording;
		$rurl='';		
		if(empty($_GET['did']))
		{
		$desg_id=$_GET['desg_id'];
		}else{
		$desg_id=$_GET['did'];			
		}
		$SQLw = "SELECT * FROM ".$table_wording." WHERE id  = '".$w_ID."' AND  desg_id  = '".$desg_id."'";
		$wTPT = $wpdb->get_results($SQLw);
		$subtitlew=$wTPT[0]->title?$wTPT[0]->title:'';
		$wTPTid=$wTPT[0]->desg_id;
		$Allwm = "SELECT * FROM ".$table_wording." WHERE desg_id='".$desg_id."'";
		$dwResult= $wpdb->get_results($Allwm);
		$Alld = "SELECT * FROM ".$table_desig." WHERE id  = '".$wTPTid."'";
		$wTPTd = $wpdb->get_results($Alld);
		$designtitle=$wTPTd[0]->des_name;
		$designid=$wTPTd[0]->id;
		$awurl=$adminurl."admin.php?page=designation&action=deswording&type=new&did=$designid";
		$addwurl='<a class="page-title-action" id="addnewurl" href="'.$awurl.'">Add New</a>';
}
if($_GET['type']=='new' && $_GET['action']=="deswording"){
		$title="Add a New";
		$buttontext="Submit";
		$formtype="wordnew";
		$rurl='';
		$backurl=$adminurl."admin.php?page=designation&action=deswording";
		$did_id=$_GET['did'];
		$Allwm = "SELECT * FROM ".$table_wording." WHERE desg_id='".$did_id."'";
		$dwResult= $wpdb->get_results($Allwm);
		$Alld = "SELECT * FROM ".$table_desig." WHERE id  = '".$did_id."'";
		$wTPT = $wpdb->get_results($Alld);
		$designtitle=$wTPT[0]->des_name;
		$designid=$wTPT[0]->id;
}
}
/**********************Wording End**************************/


/**********************Word Meta Start**************************/
if($_GET['action']=="wordmeta"){
if($_GET['type']=='edit' && $_GET['action']=="wordmeta"){
		$title="Edit";
		$buttontext="Update";   
		$wm_ID=$_GET['wm_ID'];
		global $wpdb;
		$mw_ID=$_GET['wid_ID'];
		//$rurl=$wordmeta;
		$rurl='';
		$formtype="wordmetaupdate";
		$SQLwm = "SELECT * FROM ".$table_wording_meta." WHERE id  ='".$wm_ID."' AND word_id  ='".$mw_ID."'";
		$wmTPT = $wpdb->get_results($SQLwm);
		$subtitlem=$wmTPT[0]->title?$wmTPT[0]->title:'';
		$wmTPTd=$wmTPT[0]->word_id;
		
		$Allw = "SELECT * FROM $table_wording WHERE id='".$wmTPTd."'";
		$wmTPT1 = $wpdb->get_results($Allw);
		$Allwm = "SELECT * FROM $table_wording_meta WHERE word_id='".$mw_ID."'";
		$wmResult = $wpdb->get_results($Allwm);
		$desgid=$wmTPT1[0]->desg_id;
		$subtitle=$wmTPT1[0]->title;
		$wmTPTid=$wmTPT1[0]->id;
	$awmurl=$adminurl."admin.php?page=designation&action=wordmeta&type=new&wid_ID=$wmTPTid";
	$addwmurl='<a class="page-title-action" id="addnewurl" href="'.$awmurl.'">Add New</a>';
	
		$awmurl=$adminurl."admin.php?page=designation&action=deswording&type=new&did=$desgid";
		$backurlw='<a class="page-title-action" id="addnewurl" href="'.$awmurl.'">Back List</a>';
}
if($_GET['type']=='new' && $_GET['action']=="wordmeta"){
		$title="Add New";
		global $wpdb;
		$buttontext="Submit";
		$formtype="wordmetanew";
		$wids_ID=$_GET['wid_ID'];
		$rurl='';
		$Allwm = "SELECT * FROM $table_wording_meta WHERE word_id='".$wids_ID."'";
		$wmResult = $wpdb->get_results($Allwm);
		$Allw = "SELECT * FROM $table_wording WHERE id='".$wids_ID."'";
		$wmTPT2 = $wpdb->get_results($Allw);
		$subtitle=$wmTPT2[0]->title;
		$wmTPTid=$wmTPT2[0]->id;
		$desgid=$wmTPT2[0]->desg_id;
		$awmurl=$adminurl."admin.php?page=designation&action=deswording&type=new&did=$desgid";
		$backurlw='<a class="page-title-action" id="addnewurl" href="'.$awmurl.'">Back List</a>';
}
}
/**********************Word Meta End**************************/
/**********************Word Meta Condition Start**************************/
if($_GET['action']=="metaconditon"){
if($_GET['type']=='edit' && $_GET['action']=="metaconditon"){
		$title="Edit";
		$buttontext="Update";   
		$formtype="metacinditionupdate";
		$metaid=$_GET['metaid_ID'];
		$wmc_ID=$_GET['mc_ID'];
		$rurl='';
		$SQLcondS = "SELECT * FROM ".$table_meta_conditions." WHERE meta_id='".$metaid."' AND id='".$wmc_ID."'";
		$condTPTS = $wpdb->get_results($SQLcondS);
		$condtitle=$condTPTS[0]->mc_title?$condTPTS[0]->mc_title:'';
		$condid=$condTPTS[0]->id;		
		$SQLwmcond = "SELECT * FROM ".$table_wording_meta." WHERE id='".$metaid."'";
		$wmcondTPT = $wpdb->get_results($SQLwmcond);
		$subtitlem=$wmcondTPT[0]->title?$wmcondTPT[0]->title:'';
		$wmTPTid=$wmcondTPT[0]->id;
		$mwTPTid=$wmcondTPT[0]->word_id;		
		$SQLcond = "SELECT * FROM ".$table_meta_conditions." WHERE meta_id='".$metaid."'";
		$condTPT = $wpdb->get_results($SQLcond);
$awmurl=$adminurl."admin.php?page=designation&action=metaconditon&type=new&metaid_ID=$metaid";
$addwmcurl='<a class="page-title-action" id="addnewurl" href="'.$awmurl.'">Add New</a>';

$awmurl=$adminurl."admin.php?page=designation&action=wordmeta&type=new&wid_ID=$mwTPTid";
		$backurlwm='<a class="page-title-action" id="addnewurl" href="'.$awmurl.'">Back List</a>';
		}
if($_GET['type']=='new' && $_GET['action']=="metaconditon"){
		$title="Add New";
		global $wpdb;
		$buttontext="Submit";
		$rurl='';
		$formtype="metacinditionnew";
		$metaid=$_GET['metaid_ID'];
		$SQLwmcond = "SELECT * FROM ".$table_wording_meta." WHERE id='".$metaid."'";
		$wmcondTPT = $wpdb->get_results($SQLwmcond);
		$subtitlem=$wmcondTPT[0]->title?$wmcondTPT[0]->title:'';
		$wmTPTid=$wmcondTPT[0]->id;
		$mwTPTid=$wmcondTPT[0]->word_id;
		$awmurl=$adminurl."admin.php?page=designation&action=wordmeta&type=new&wid_ID=$mwTPTid";
		$backurlwm='<a class="page-title-action" id="addnewurl" href="'.$awmurl.'">Back List</a>';
		$SQLcond = "SELECT * FROM ".$table_meta_conditions." WHERE meta_id='".$metaid."'";
		$condTPT = $wpdb->get_results($SQLcond);
		}
}
/**********************Word Meta conditions End**************************/

/********************************Word Meta Condition Start**************************************/
if($_GET['action']=="mconditonvalue"){
if($_GET['type']=='edit' && $_GET['action']=="mconditonvalue"){
		$title="Edit";
		$buttontext="Update";   
		$formtype="conditionvalueedit";
		$cv_id=$_GET['cv_id'];
		$cond_id=$_GET['cond_id'];
		$rurl='';
		$SQLcondv = "SELECT * FROM ".$table_neta_conditionsvalue." WHERE cond_id='".$cond_id."' AND id='".$cv_id."'";
		$condvTPT = $wpdb->get_results($SQLcondv);
		$MCVtitle=$condvTPT[0]->mc_title;
		$MCVid=$condvTPT[0]->id;
			
		$SQLcond = "SELECT * FROM ".$table_meta_conditions." WHERE id='".$cond_id."'";
		$condTPT = $wpdb->get_results($SQLcond);
		$mctitle=$condTPT[0]->mc_title;
		$mcid=$condTPT[0]->id;
		$metaid=$condTPT[0]->meta_id;
		$cwordid=$condTPT[0]->word_id;
		
        $awmcvurl=$adminurl."admin.php?page=designation&action=metaconditon&type=new&metaid_ID=$metaid";
        $backwmcurl='<a class="page-title-action" id="addnewurl" href="'.$awmcvurl.'">Back List</a>';
		
		$AllCV = "SELECT * FROM $table_wording_meta WHERE id='".$metaid."'";
		$CVResult = $wpdb->get_results($AllCV);
		$cmetaname=$CVResult[0]->title;
		$cmetaid=$CVResult[0]->id;
		
		$SQLcondV = "SELECT * FROM ".$table_neta_conditionsvalue." WHERE cond_id='".$cond_id."'";
		$ALLcondVALUE = $wpdb->get_results($SQLcondV);
	
$awmcvurl=$adminurl."admin.php?page=designation&action=mconditonvalue&type=new&cond_id=$cond_id";
$addwmcvurl='<a class="page-title-action" id="addnewurl" href="'.$awmcvurl.'">Add New</a>';
		}
if($_GET['type']=='new' && $_GET['action']=="mconditonvalue"){
     	$title="Add New";
		global $wpdb;
		$buttontext="Submit";
		$rurl='';
		$formtype="conditionvaluenew";
		if($_GET['mc_ID']){
			$mc_ID=$_GET['mc_ID'];
		}else{
		$mc_ID=$_GET['cond_id'];
		}
		$SQLcondv = "SELECT * FROM ".$table_meta_conditions." WHERE id='".$mc_ID."'";
		$condTPT = $wpdb->get_results($SQLcondv);
		$mctitle=$condTPT[0]->mc_title;
		$mcid=$condTPT[0]->id;
		$metaid=$condTPT[0]->meta_id;
		$cwordid=$condTPT[0]->word_id;

$awmcvurl=$adminurl."admin.php?page=designation&action=metaconditon&type=new&metaid_ID=$metaid";
$backwmcurl='<a class="page-title-action" id="addnewurl" href="'.$awmcvurl.'">Back List</a>';
			
		$AllCV = "SELECT * FROM $table_wording_meta WHERE id='".$metaid."'";
		$CVResult = $wpdb->get_results($AllCV);
		$cmetaname=$CVResult[0]->title;
		$cmetaid=$CVResult[0]->id;
		$SQLcondV1 = "SELECT * FROM ".$table_neta_conditionsvalue." WHERE cond_id='".$mc_ID."'";
		$ALLcondVALUE = $wpdb->get_results($SQLcondV1);
		
		}
}
/**********************Word Meta conditions End**************************/


//===Get categories========//
$ALLCATEGORIES = "SELECT * FROM $table_category  WHERE status='Active' ORDER BY id DESC";
$ALLCAT = $wpdb->get_results($ALLCATEGORIES);
//============================================//
//$Alld = "SELECT * FROM $table_desig  WHERE status='Active' ORDER BY id ASC";
/*$Allw = "SELECT * FROM $table_wording";
$wResult = $wpdb->get_results($Allw);
*/

$current_date = date("Y-m-d H:i:s");
//===========Paging=============//
$items_per_page =5;	
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;
?>
<script>

function datawordinginsert(url,tname,strs){
//alert (strs); 
var formData = new FormData($("#newform3")[0]);
formData.append('table_name', tname);
formData.append('stats', strs);
			var location_url=document.getElementById('location').value;
			var designationid=document.getElementById("designationid");
			var wording=document.getElementById("wording");    
			var ismeta=document.getElementById("iswmeta");
			if(designationid.value==""){
			designationid.focus();
			return false;
			}
			if(wording.value==""){
			wording.focus();
			return false;
			}
			if(ismeta.value==""){
			ismeta.focus();
			return false;
			}
			$.ajax({
			type: "POST",             // Type of request to be send, called as method
			data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			contentType: false,       // The content type used when sending data to the server.
			cache: false,             // To unable request pages to be cached
			processData:false,  
			url: url,
			//dataType:'text',
			success: function(results){
			//	alert (results);
			var obj = jQuery.parseJSON( results );
			if( obj.result === "ok" ){
			$('#response').html(obj.msg);
			setTimeout(function () {
			window.location.href = location_url;
			}, 500);
			}
			},
			error: function(){
			$('#response').html(results);
			}
			});
    }
function datametainsert(url,tname,strs){
		// alert (strs); 
		var formData = new FormData($("#newform4")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		//alert (formData);
		var location_url=document.getElementById('location').value;
		var iscond=document.getElementById("iscond");
		var wmtitle=document.getElementById("wmtitle");
		var wmvalue=document.getElementById("wmvalue");
		
		if(wmtitle.value==""){
		wmtitle.focus();
		//wmtitle.style.border= "1px solid red";   
		return false;
		}
		if(iscond.value==""){
		iscond.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datas){
		//alert (datas);
		var obj = jQuery.parseJSON( datas );
		if( obj.result === "ok" ){
		$('#rdata').html(obj.msg);
		setTimeout(function () {
		window.location.href = location_url;
		}, 500);
		}else{
		$('#response').html(obj.msg);
		}
		},
		error: function(){
		$('#response').html(datas);
		}
		});
    }
	
function datametacondinsert(url,tname,strs){
		var formData = new FormData($("#newform6")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		//alert (formData);
		var location_url=document.getElementById('location').value;
		var metatitle=document.getElementById("mctitle");
		var iscmeta=document.getElementById("iscmeta");
		if(metatitle.value==""){
		metatitle.focus();
		return false;
		}
		if(iscmeta.value==""){
		iscmeta.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datac){
		//alert (datac);
		var obj = jQuery.parseJSON( datac );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		setTimeout(function () {
		window.location.href = location_url;
		}, 500);
		}else{
		$('#response').html(obj.msg);
		}
		},
		error: function(){
		$('#rdata').html(datac);
		}
		});
	}	
	function metacondvalueinsert(url,tname,strs){
		//alert (url+tname+strs);
			var formData = new FormData($("#newform7")[0]);
		formData.append('table_name', tname);
		formData.append('stats', strs);
		//alert (formData);
		var location_url=document.getElementById('location').value;
		var cvtitle=document.getElementById("cvtitle");
		var cvalue=document.getElementById("cvalue");
		if(cvtitle.value==""){
		cvtitle.focus();
		return false;
		}
		if(cvalue.value==""){
		cvalue.focus();
		return false;
		}
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,  
		url: url,
		success: function(datacv){
		//alert (datacv);
		var obj = jQuery.parseJSON( datacv );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		setTimeout(function () {
		window.location.href = location_url;
		}, 500);
		}else{
		$('#response').html(obj.msg);
		}
		},
		error: function(){
		$('#rdata').html(datac);
		}
		});
	}
	
	function delete_wording(tname,url,ids,strs){
	//alert (tname+url+ids+strs);
		var wordlocation_url=document.getElementById('location').value;
if(confirm("Do you want to delete?")){
$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"wid":ids,"stats":strs},
		url: url,
		success: function(dataw){
		//alert (dataw);
		var obj = $.parseJSON( dataw );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		$('#response').show();
			setTimeout(function () {
			window.location.href = wordlocation_url;
			}, 500);
		}else{
		$('#response').html(obj.msg);
		$('#response').show();
		}
		},
		error: function(){
		$('#response').html(dataw);
		$('#response').show();
		}
});
}
}
function delete_wordmeta(tname,url,ids,strs){
	var metalocation_url=document.getElementById('location').value;
if(confirm("Do you want to delete?")){
	//alert (tname+url+ids+strs);
 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"table_name":tname,"mid":ids,"stats":strs},
                url: url,
				success: function(datas){
				   // alert (datas);
    			var obj = $.parseJSON( datas );
				if( obj.result === "ok" ){
			$('#response').html(obj.msg);
			$('#response').show();
				setTimeout(function () {
				window.location.href = metalocation_url;
				}, 500);
				}else{
				   $('#response').html(obj.msg);
				   $('#response').show();
				    }
				},
                error: function(){
                 $('#response').html(datas);
				 $('#response').show();
                }
	           });
}
}
function delete_cond(tname,url,ids,strs){
		//alert (tname+url+ids+strs);
		var condlocation_url=document.getElementById('location').value;
		if(confirm("Do you want to delete?")){
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"cid":ids,"stats":strs},
		url: url,
		success: function(datamc){
		// alert (datamc);
		var obj = $.parseJSON( datamc );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		$('#response').show();
		setTimeout(function () {
		window.location.href = condlocation_url;
		}, 500);
		}else{
		$('#response').html(obj.msg);
		$('#response').show();
		}
		},
		error: function(){
		$('#response').html(datamc);
		$('#response').show();
		}
		});
		}
}

function delete_condvalue(tname,url,ids,strs){
		//alert (tname+url+ids+strs);
		var condlocationv_url=document.getElementById('location').value;
		if(confirm("Do you want to delete?")){
		$.ajax({
		type: "POST",             // Type of request to be send, called as method
		data: {"table_name":tname,"cvid":ids,"stats":strs},
		url: url,
		success: function(datamcv){
		// alert (datamcv);
		var obj = $.parseJSON( datamcv );
		if( obj.result === "ok" ){
		$('#response').html(obj.msg);
		$('#response').show();
		setTimeout(function () {
		window.location.href = condlocationv_url;
		}, 500);
		}else{
		$('#response').html(obj.msg);
		$('#response').show();
		}
		},
		error: function(){
		$('#response').html(datamcv);
		$('#response').show();
		}
		});
		}
}


function  showSubcat(str,url,tname)
{
  
  var subcat=$('#subcat').val();
   var strs="getcats";
	$.ajax({
	   type: "POST",
	   data: {"stats":strs,"catids":str,"table_name":tname,"subcatid":subcat},
	   url: url,
	   success: function(msg){
//	alert("Status updated successfully!");
		$('#txtHint').html(msg);
	   },
	   error: function(){
		$('#txtHint').html(msg);
	   }
	});
}
function datainsert(url,tname,strs){
 // alert (strs); 
var formData = new FormData($("#newform")[0]);
formData.append('table_name', tname);
formData.append('stats', strs);
//alert (formData);
var location_url=document.getElementById('location').value;
           var dsubsectors=document.getElementById("subsectors");
             var dsectors=document.getElementById("sectors");
            var dtitle=document.getElementById("desig_title");
            var dnumbers=document.getElementById("desig_numbers");
            var file= dnumbers.value;
            var reg = /(.*?)\.(pdf|docs|jpeg|png)$/;           
            if(dsectors.value==""){
            dsectors.focus();
            //dsectors.style.border= "1px solid red";   
            return false;
            }
            if(dsubsectors.value==""){
            dsubsectors.focus();
            //dsubsectors.style.border= "1px solid red";   
            return false;
            }
            if(dtitle.value==""){
            dtitle.focus();
           // dtitle.style.border= "1px solid red";   
            return false;
            }
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: formData, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                contentType: false,       // The content type used when sending data to the server.
                cache: false,             // To unable request pages to be cached
                processData:false,  
                url: url,
				//dataType:'text',
				success: function(results){
				    //alert (results);
    			var obj = jQuery.parseJSON( results );
				if( obj.result === "ok" ){
				$('#rdata').html(obj.msg);
				setTimeout(function () {
				window.location.href = location_url;
				}, 500);
				}
				},
                error: function(){
                 $('#rdata').html(results);
                }
	           });
    }
     function readURL(input) {
      var name = document.getElementById('desig_numbers'); 
      $('#blah').val(name.files.item(0).name);
    }
</script>
<section id="sellingprice2" class="tabcontent1 ">
<?php if($_GET['action']=="")
{
$pagest=($_GET['page']=="designation");
}else{
$pagest=($_GET['action']=="designation");
}
?>


<?php if($_GET['type']=='edit' && $_GET['action']=='designation' || $_GET['type']=='new' && $_GET['action']=='designation'){ ?>
<div id="forms1" class="wrap">
<h3><?php echo $title?$title.' Scenario':"Add New Scenario";?>  </h3>
<h3><?php echo $ptaddurl; ?></h3>
		<form id="newform" action="" method="POST" enctype="multipart/form-data">
		<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
		<input type="hidden" name="editid" id="editid" value="<?php echo $d_ID; ?>">
		<input type="hidden" name="location" id="location" value="<?php echo $durl; ?>">
		<input type="hidden" name="subcat" id="subcat" value="<?php echo $desTPT[0]->subcatid; ?>">
		<p><label>Sectors</label>
		<select id="sectors" name="sectors" class="subsectors" onchange="return showSubcat(this.value,'<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','subcategory')">
		<option value="">Select Sectors</option>
		<?php if(count($ALLCAT)>0){
		foreach($ALLCAT as $allc){
		if($desTPT[0]->catid==$allc->id)
		{ $selected="selected"; $ids="defaultOpen";}else{ $selected=""; $ids="";}
		?>
		<option value="<?php echo $allc->id;?>" <?php echo $selected; ?> id="<?php echo $ids; ?>" ><?php echo $allc->category_name;?></option>
		<?php }
		}
		?>
		</select></p>
		<p id="txtHint" style=" border:0px solid gray;">
		<label>Sub Sectors</label>
		<select id="subsectors" name="subsectors" class="subsectors">
		<option value="">Select Sub Sectors</option>
		</select>
		</p>
		<p><label>Title:</label><input type="text" name="desig_title" id="desig_title" value="<?php echo $desTPT[0]->des_name?$desTPT[0]->des_name:$desig_title; ?>"></p>
		<p><label>Numbers <br>(Upload file here): </label><input onchange="readURL(this);"  type="file" name="desig_numbers" id="desig_numbers" value="<?php echo $desTPT[0]->number?$desTPT[0]->number:$number; ?>">
		<label>&nbsp;&nbsp;</label><input id="blah"  value="<?php echo $desTPT[0]->number?$desTPT[0]->number:'Add New Pdf'; ?>"/>
		</p>
		<p><label>Main application conditions: </label>
		<textarea style="width: 415px" name="desig_cond" id="desig_cond" rows="4" cols="45"><?php echo $desTPT[0]->conditions?$desTPT[0]->conditions:$desig_cpe; ?></textarea></p>
		<p><label></label><input type="button" class="btn btn-info" onclick="return datainsert('<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','designations','<?php echo $formtype; ?>');"  name="<?php echo "designationupdate";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
		</form>
</div>
<?php }
/********************************Wording Data********************************/
 if($_GET['type']=='edit' && $_GET['action']=='deswording' || $_GET['type']=='new' && $_GET['action']=='deswording'){ 
 ?>
	<div id="forms2" class="wrap">
	<h2>Wording Settings of Scenario</h2>
	<h3><?php echo $title?$title.' Wording':"Add New Wording";?>  </h3>
	<?php echo $addwurl?'<h3 id="rigticons">'.$addwurl.'</h3>':'';?><h3 id="rigticons"><?php echo $ptaddurl; ?></h3>
	<form style="display:block;" id="newform3" action="" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
	<input type="hidden" name="weditid" id="weditid" value="<?php echo $w_ID; ?>">
	<input type="hidden" name="location" id="location" value="<?php echo $rurl; ?>">

	<p id="designation" style=" border:0px solid gray;">
	<label>Designation Name:</label>
	<input type="text" id="designationname" name="designationname" class="designationname" readonly value="<?php echo $designtitle; ?>">
	<input type="hidden" id="designationid" name="designationid" class="designationid" readonly value="<?php echo $designid; ?>">
	</p>
	<p><label>Wording Title</label><input type="text" name="wording" id="wording" value="<?php echo $subtitlew;?>"></p>
	<p><label>Is Meta?: </label>
	<select name="iswmeta" id="iswmeta" onchange="leaveChange(this.value)">
	<option value="">Select Value</option>
	<option value="Yes" <?php echo ($wTPT[0]->is_meta=='Yes')?'selected':''; ?>>Yes</option>
	<option value="No" <?php echo ($wTPT[0]->is_meta=='No')?'selected':''; ?>>No</option>
	</select>
	</p>
	<?php $d=($wTPT[0]->is_meta=='No')?'block':'none'; ?>
<p id="iscmetaop" style="display:<?php echo $d?$d:'none';?>;"><label>Other Parts?: </label>
<select name="wotherparts" id="otherparts" onchange="leaveChange1(this.value)">
<option value="">Select Value</option>
<option value="No" <?php echo ($wTPT[0]->otherparts=='No')?'selected':''; ?>>No</option>
<option value="Yes" <?php echo ($wTPT[0]->otherparts=='Yes')?'selected':''; ?>>Yes</option>
</select>
</p>
<?php $dislays2=($wTPT[0]->otherparts=='Yes')?'block':'none'; ?>
<p id="iscmetaop2" style="display:<?php echo $dislays2?:'none';?>;"><label>Optional Types?: </label>
<select name="woptypes" id="woptypes" onchange="leaveChange6(this.value)">
<option value="">Select Value</option>
<option value="Add" <?php echo ($wTPT[0]->optypes=='Add')?'selected':''; ?>>Add</option>
<option value="Sub" <?php echo ($wTPT[0]->optypes=='Sub')?'selected':''; ?>>Sub</option>
<option value="Mult" <?php echo ($wTPT[0]->optypes=='Mult')?'selected':''; ?>>Mult</option>
<option value="Div" <?php echo ($wTPT[0]->optypes=='Div')?'selected':''; ?>>Div</option>
</select>
</p>
<?php $displayc=($wTPT[0]->otherparts=='Yes')?'block':'none'; ?>
<p id="iscmetaop1" style="display:<?php echo $displayc?$displayc:'none';?>;"><label>Wording Value</label><input type="text" name="wordvalue" id="wordvalue" value="<?php echo $wTPT[0]->word_value?$wTPT[0]->word_value:'';?>"></p>

	
	
	<p><label></label><input type="button" class="btn btn-info" onclick="return datawordinginsert('<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','wording','<?php echo $formtype; ?>');"  name="<?php echo "designationsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
	<p id="response"></p>
	<?php  ?>
	</form>
	</div>
<section id="projecttypelist" class="tabcontent1">
		<form id="posts-filter" method="post">
		<table class="wp-list-table widefat fixed striped cats">
		<thead>
		<tr>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Wording Title</span></a></th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Is Meta?</span></span></a>
		</th>
		<th scope="col" class="manage-column column-description sortable desc">
		<a href="#"><span>Action</span></span></a>
		</th>
		</tr>
		</thead>
		<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($dwResult)>0){
		foreach($dwResult as $allwm){
		$cid=$allwm->id;
		$desg_id=$allwm->desg_id;
		$is_meta=$allwm->is_meta;
		?>
		<tr id="cat-2">		
		<td class="name column-name has-row-actions column-primary" data-colname="Name">
		<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->title;?></a></strong>
		</td>	
		
		<td class="description column-description" data-colname="Description"><?php echo $allwm->is_meta;?></td>
		<td class="description column-description" data-colname="Description">
<span class="edit">
<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=deswording&did=<?php echo $desg_id; ?>&type=edit&w_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Edit</a>
</span>/
<span class="delete">
<a role="button" onclick="return delete_wording('wording','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $cid ;?>','deletewording');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete</a> </span>
<?php if(($is_meta=="Yes")){?>
/
<span class="delete">
<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=wordmeta&type=new&wid_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
View Meta</a> </span>
<?php } ?>
		</td>
		</tr>
		<?php }
		}else{
		?>
		<tr id="cat-2">			
		<td class="posts column-posts">
		</td>
		<td class="posts column-posts">
		</td>
		<td class="posts column-posts">
		</td>
		<td class="description column-description">
		<span class="ascreen-reader-text">No Record found!</span></td>
		<td class="posts column-posts">
		</td>
		<td class="posts column-posts">
		</td>
		<td class="posts column-posts">
		</td>
		</tr>	
		<?php } ?>			
		</tbody>
		<section id="pagination">
		<?php  echo paginate_links( array(
		'base' => add_query_arg( 'cpage', '%#%' ),
		'format' => '',
		'prev_text' => __('&laquo;'),
		'next_text' => __('&raquo;'),
		'total' => ceil($totalwm/$items_per_page),
		'current' => $page
		)); ?>
		</section>
		</table>
		</form>
		
		</section>
<?php 
}
/********************************Wording Data********************************/

if($_GET['type']=='edit' && $_GET['action']=='wordmeta' || $_GET['type']=='new' && $_GET['action']=='wordmeta'){ ?>
<div id="forms2" class="wrap">
<h2>Wording Meta Settings of Scenario</h2>
<h3><?php echo $title?$title.' Wording Meta':"Add New Wording Meta";?>  </h3>
<?php echo $addwmurl?'<h3 id="rigticons">'.$addwmurl.'</h3>':'';?><h3 id="rigticons"><?php echo $backurlw; ?></h3>
<form style="display:block;" id="newform4" action="" method="POST" enctype="multipart/form-data">
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="wmeditid" id="wmeditid" value="<?php echo $wm_ID; ?>">
<input type="hidden" name="location" id="location" value="<?php echo $rurl; ?>">
<p id="designation" style=" border:0px solid gray;">
<label>Wording Title:</label>
<?php 
	echo '<input type="hidden" value="'.$wmTPTid.'" id="wordid" name="wordid" class="wordid">';
	echo '<input readonly type="text" value="'.$subtitle.'" id="wordidname" name="wordidname" class="wordid">';
?>
</p>
<p><label>Word Meta Title</label><input type="text" name="wmtitle" id="wmtitle" value="<?php echo $subtitlem;?>"></p>
<p><label>Word Meta Value</label><input type="text" name="wmvalue" id="wmvalue" value="<?php echo $wmTPT[0]->value;?>"></p>
<p><label>Is Conditions?</label>
<select name="iscond" id="iscond">
<option value="">Select Value</option>
<option value="Yes" <?php echo ($wmTPT[0]->is_cond=='Yes')?'selected':''; ?>>Yes</option>
<option value="No" <?php echo ($wmTPT[0]->is_cond=='No')?'selected':''; ?>>No</option>
</select>
</p>
<p><label></label><input type="button" class="btn btn-info" onclick="return datametainsert('<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','wording_meta','<?php echo $formtype; ?>');"  name="<?php echo "wmsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>
</div>
<?php 
?>
<section id="projecttypelist" class="tabcontent1">
<form id="posts-filter" method="post">
<table class="wp-list-table widefat fixed striped cats">
<thead>
<tr>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Meta Title</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Value</span></span></a>
</th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Is Conditions?</span></span></a>
</th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Action</span></span></a>
</th>
</tr>	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($wmResult)>0){
			foreach($wmResult as $allwm){
			$cid=$allwm->id;
			$word_id=$allwm->word_id;
			?>
			<tr id="cat-2">		
			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->title;?></a></strong>
			</td>	
			<td class="description column-description" data-colname="Description"><?php echo $allwm->value?$allwm->value:'--';?></td>
			<td class="description column-description" data-colname="Description"><?php echo $allwm->is_cond;?></td>
<td class="description column-description" data-colname="Description">
<span class="edit">
<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=wordmeta&wid_ID=<?php echo $word_id; ?>&type=edit&wm_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Edit</a>
</span>/
<span class="delete">
<a role="button" onclick="return delete_wordmeta('wording_meta','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $cid;?>','deletewordingmeta');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete</a> </span>
<?php if(($allwm->is_cond=="Yes")){?>
/
<span class="delete">
<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=metaconditon&type=new&metaid_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">
Manage Conditions</a> </span>
<?php } ?>
</td>
			
			</tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
            <td class="posts column-posts">
            </td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			</tr>	
			<?php } ?>			
			</tbody>
			<section id="pagination">
	<?php  echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($totalwm/$items_per_page),
        'current' => $page
    )); ?>
	</section>
</table>
</form>
</section>
<?php 
 
}
/********************************Wording Data********************************/
/********************************Meta Condition Section Start Here***********/
if($_GET['type']=='edit' && $_GET['action']=='metaconditon' || $_GET['type']=='new' && $_GET['action']=='metaconditon'){ ?>
<div id="forms2" class="wrap">
<h2>Wording Meta Condition Settings </h2>
<h3><?php echo $title?$title.' Meta Conditions':"Add New Meta Conditions";?>  </h3>
<?php echo $addwmcurl?'<h3 id="rigticons">'.$addwmcurl.'</h3>':'';?><h3 id="rigticons"><?php echo $backurlwm; ?></h3>
<form style="display:block;" id="newform6" action="" method="POST" enctype="multipart/form-data">
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="wmcid" id="wmcid" value="<?php echo $wmc_ID; ?>">
<input type="hidden" name="location" id="location" value="<?php echo $rurl; ?>">
<p id="designation" style=" border:0px solid gray;">
<label>Wording Meta Title</label>
<?php 
	echo '<input type="hidden" value="'.$mwTPTid.'" id="wordid" name="wordid" class="wordid">';
	echo '<input type="hidden" value="'.$wmTPTid.'" id="metaid" name="metaid" class="metaid">';
	echo '<input readonly type="text" value="'.$subtitlem.'" id="metatitle" name="metatitle" class="metatitle">';
?>
</p>
<p><label>Condition Title</label><input type="text" name="mctitle" id="mctitle" value="<?php echo $condtitle?$condtitle:'';?>"></p>
<p><label>Is Condition Meta?: </label>
<select name="iscmeta" id="iscmeta" onchange="leaveChange(this.value)">
<option value="">Select Value</option>
<option value="Yes" <?php echo ($condTPTS[0]->is_cond=='Yes')?'selected':''; ?>>Yes</option>
<option value="No" <?php echo ($condTPTS[0]->is_cond=='No')?'selected':''; ?>>No</option>
</select>
</p>
<?php $dislay=($condTPTS[0]->is_cond=='No')?'block':'none'; ?>
<p id="iscmetaop" style="display:<?php echo $dislay ;?>;"><label>Other Parts?: </label>
<select name="otherparts" id="otherparts" onchange="leaveChange1(this.value)">
<option value="">Select Value</option>
<option value="No" <?php echo ($condTPTS[0]->otherparts=='No')?'selected':''; ?>>No</option>
<option value="Yes" <?php echo ($condTPTS[0]->otherparts=='Yes')?'selected':''; ?>>Yes</option>
</select>
</p>
<?php $dislays2=($condTPTS[0]->otherparts=='Yes')?'block':'none'; ?>
<p id="iscmetaop2" style="display:<?php echo $dislays2?:'none';?>;"><label>Optional Types?: </label>
<select name="optypes" id="optypes" onchange="leaveChange6(this.value)">
<option value="">Select Value</option>
<option value="Add" <?php echo ($condTPTS[0]->optypes=='Add')?'selected':''; ?>>Add</option>
<option value="Sub" <?php echo ($condTPTS[0]->optypes=='Sub')?'selected':''; ?>>Sub</option>
<option value="Mult" <?php echo ($condTPTS[0]->optypes=='Mult')?'selected':''; ?>>Mult</option>
<option value="Div" <?php echo ($condTPTS[0]->optypes=='Div')?'selected':''; ?>>Div</option>
</select>
</p>
<?php $displayc=($condTPTS[0]->otherparts=="Yes")?'block':'none';?>
<p id="iscmetaop1" style="display:<?php echo $displayc?$displayc:'none';?>;"><label>Condition Value</label><input type="text" name="wmcvalue" id="wmcvalue" value="<?php echo $condTPTS[0]->mc_value; ?>"></p>
<p><label></label><input type="button" class="btn btn-info" onclick="return datametacondinsert('<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','meta_conditions','<?php echo $formtype; ?>');"  name="<?php echo "mcsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>
</div>
<section id="projecttypelist" class="tabcontent1">
<form id="posts-filter" method="post">
<table class="wp-list-table widefat fixed striped cats">
<thead>
<tr>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Condition Title</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Is Condition?</span></span></a>
</th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Action</span></span></a>
</th>
</tr>	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($condTPT)>0){
			foreach($condTPT as $allwm){
			$cid=$allwm->id;
			$meta_id=$allwm->meta_id;
			?>
			<tr id="cat-2">		
			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->mc_title;?></a></strong>
			</td>	
			<td class="description column-description" data-colname="Description"><?php echo $allwm->is_cond;?></td>
			<td class="description column-description" data-colname="Description">
<span class="edit">
<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=metaconditon&metaid_ID=<?php echo $meta_id; ?>&type=edit&mc_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Edit</a>
</span>/
<span class="delete">
<a role="button" onclick="return delete_cond('meta_conditions','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $cid;?>','deleteconditions');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete </a> </span>
<?php if(($allwm->is_cond=="Yes")){?>
/
<span class="delete">
<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=mconditonvalue&type=new&mc_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Manage Condition Meta</a>
</span>
<?php } ?>
</td>
</tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
            <td class="posts column-posts">
            </td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			</tr>	
			<?php } ?>			
			</tbody>
			<section id="pagination">
	<?php  echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($totalwm/$items_per_page),
        'current' => $page
    )); ?>
	</section>
</table>
</form>
</section>
<?php } 
/********************************Meta Condition Section End Here********************************/
/********************************Meta Condition Section Start Here******************************/
if($_GET['type']=='edit' && $_GET['action']=='mconditonvalue' || $_GET['type']=='new' && $_GET['action']=='mconditonvalue'){ 
?>
<div id="forms2" class="wrap">
<h2>Conditional Meta Value Settings</h2>
<h3><?php echo $title?$title.' Conditional Value':"Add New Conditional Value";?>  </h3>
<?php echo $addwmcvurl?'<h3 id="rigticons">'.$addwmcvurl.'</h3>':'';?><h3 id="rigticons"><?php echo $backwmcurl; ?></h3>
<form style="display:block;" id="newform7" action="" method="POST" enctype="multipart/form-data">
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="MCVid" id="MCVid" value="<?php echo $MCVid; ?>">
<input type="hidden" name="location" id="location" value="<?php echo $rurl; ?>">
<p id="designation" style=" border:0px solid gray;">
<label>Meta Title:</label>
<?php 
    echo '<input type="hidden" value="'.$cwordid.'" id="wordid" name="wordid" class="wordid">';
	echo '<input type="hidden" value="'.$cmetaid.'" id="metaid" name="metaid" class="metaid">';
	echo '<input readonly type="text" value="'.$cmetaname.'" id="metaname" name="metadname" class="metadname">';
?>
</p>
<p id="designation" style=" border:0px solid gray;">
<label>Condition Title:</label>
<?php 
	echo '<input type="hidden" value="'.$mcid.'" id="condid" name="condid" class="condid">';
	echo '<input readonly type="text" value="'.$mctitle.'" id="condname" name="condname" class="condname">';
?>
</p>
<p><label>Condition Meta Title</label><input type="text" name="cvtitle" id="cvtitle" value="<?php echo $MCVtitle?$MCVtitle:'';?>"></p>
<p><label>Value</label><input type="text" name="cvalue" id="cvalue" value="<?php echo $condvTPT[0]->mc_value?$condvTPT[0]->mc_value:'';?>"></p>
<p><label></label><input type="button" class="btn btn-info" onclick="return metacondvalueinsert('<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','meta_conditions_values','<?php echo $formtype; ?>');"  name="<?php echo "cvsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>
</div>
<section id="projecttypelist" class="tabcontent1">
<form id="posts-filter" method="post">
<table class="wp-list-table widefat fixed striped cats">
<thead>
<tr>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Title</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Value</span></a></th>
<th scope="col" class="manage-column column-description sortable desc">
<a href="#"><span>Action</span></span></a>
</th>
</tr>	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php if(count($ALLcondVALUE)>0){
			foreach($ALLcondVALUE as $allwm){
			$cid=$allwm->id;
			$cond_id=$allwm->cond_id;
			?>
			<tr id="cat-2">		
			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $allwm->mc_title;?></a></strong>
			</td>	
			<td class="description column-description" data-colname="Description"><?php echo $allwm->mc_value;?></td>
			<td class="description column-description" data-colname="Description">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=designation&action=mconditonvalue&cond_id=<?php echo $cond_id; ?>&type=edit&cv_id=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Edit</a>
			<span class="delete">/
<a role="button" onclick="return delete_condvalue('meta_conditions_values','<?php echo plugins_url('ajaxfiles/ajaxsubcat.php' ,dirname(__FILE__));?>','<?php echo $cid;?>','deleteconditionsvalue');" 
href="#" class="delete-cat aria-button-if-js" aria-label="Delete “a”">
Delete </a> </span>
			</td>
			</tr>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
            <td class="posts column-posts">
            </td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="description column-description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			<td class="posts column-posts">
			</td>
			</tr>	
			<?php } ?>			
			</tbody>
			<section id="pagination">
	<?php  echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($totalwm/$items_per_page),
        'current' => $page
    )); ?>
	</section>
</table>
</form>
</section>
<?php 
}
?>
<p id="rdata"></p><br class="clr" />
</section>