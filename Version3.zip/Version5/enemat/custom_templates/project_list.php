<?php 
ob_start();
// Template name: Project List
get_header();
session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
$siteurl = get_option("siteurl");
$currentuserid=get_current_user_id();
$user=wp_get_current_user();
if(in_array("administrator", $user->roles)){
$WHERES="";
}
else
{
$WHERES="WHERE userid='".$user->ID."'";
}

//===============Delete Records============//
$id = isset($_GET['id'])?$_GET['id']:"";
$redirect_myprojects = get_page_by_path("my-projects");
$redirectmyprojectslink = get_permalink($redirect_myprojects->ID);

$redirect_editproject = get_page_by_path("edit-project");
$redirecteditprojectlink = get_permalink($redirect_editproject->ID);
if(!empty($id)){
	//Delete Meta Wordings
	$SQLMETAWORDINGS = "DELETE FROM wp_project_meta_wording WHERE project_id='".$id."'";
	$wpdb->query($SQLMETAWORDINGS);	
		
	//Delete Meta
	$SQLMETA = "DELETE FROM wp_project_meta WHERE project_id='".$id."'";
	$wpdb->query($SQLMETA);	
	  
	 $SQL = "DELETE FROM wp_projects WHERE id='".$id."'";
	 $wpdb->query($SQL);
	$_SESSION['SuccessMsg'] = "Record Deleted Successfully.....";	 
	wp_redirect($redirectmyprojectslink);	
	exit; 
 }
//===============Delete Records============//

$table_name = $wpdb->prefix . "projects";
$table_prefix = $wpdb->prefix;
$items_per_page =20;
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ($page * $items_per_page) - $items_per_page;

$SQLTOTAL = "SELECT * FROM wp_projects ".$WHERES." ORDER BY id DESC";
$rsTotals = $wpdb->get_results($SQLTOTAL);
$total = count($rsTotals);
				 
$SQL = "SELECT * FROM wp_projects ".$WHERES." ORDER BY id DESC
		LIMIT ".$offset.",".$items_per_page."";
$rs = $wpdb->get_results($SQL);
function get_operations($project_id){
	global $wpdb;
	$SQLMETA = "SELECT COUNT(project_id) AS TOTAL  FROM wp_project_meta WHERE project_id='".$project_id."'";
	$rsTotal = $wpdb->get_results($SQLMETA);
	$totals = $rsTotal[0]->TOTAL;
	return $totals;	
}	   
if(isset($_SESSION['SuccessMsg'])){?>
<div class="success-msg">
<h5><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></h5>
</div>
<?php }?>
<div class="mem_vid1">
</div>
<div class="mainform plist">
<div class="wraper">
<div class="tab notab">
 
</div>
<div class="main_project">
  <h3 class="opt_hg">Operations</h3>
  <?php if($total>0){?>
  <div class="pge_nmbr">
				  <?php echo  paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '<li></li>',
       'total' => ceil($total/$items_per_page),
        'current' => $page,
         'prev_text'          => __( 'Previous' ),
    'next_text'          => __( 'Next'),
    'type' => 'list'
    )); ?></div>
	<?php }?>
<form class="frmdatas" name="frmdata" id="frmdata" method="post" action="">

<table class="table_a smpl_tbl prjct_tble"> 
<tr>
 <td>Date</td>
 <td>Name</td>
 <td>Description</td>
 <td>No of operations</td>
 <td>Total EEC</td>
 <td>Validation of EWCs</td>
 <td>Cost min. Works</td>
 <td>Max cost Works</td>
 <td>Average coverage rate</td>
 <td>Action</td>
</tr> 
 <?php if(count($rs)>0){
	for($i=0;$i<count($rs);$i++){
		$total_operations = get_operations($rs[$i]->id);
	?>
  <tr>
 <td><?php echo date("d/m/Y",strtotime($rs[$i]->created));?></td>
 <td><?php echo $rs[$i]->name;?></td>
 <td><?php echo $rs[$i]->description;?></td>
 <td><?php echo $total_operations;?></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 <td></td>
 <td><a href="<?php echo $redirecteditprojectlink;?>?id=<?php echo $rs[$i]->id;?>"><img src="<?php echo $siteurl;?>/wp-content/uploads/2018/02/edit.png"></a>
 <img src="<?php echo $siteurl;?>/wp-content/uploads/2018/02/delete.png" onclick="return deletest('<?php echo $redirectmyprojectslink;?>','<?php echo $rs[$i]->id;?>');">

 
 </td>
</tr> 
 <?php }
 }?>
</table> 
</form> 
</div>
 
<div class="clr"></div>

</div>
<!-- The Modal -->
<script type='text/javascript'>

function deletest(url,ids)
{
 if(confirm("Do you want to delete?")){
		document.location.href=""+url+"?id="+ids+"";
}	 
}

</script>
<?php 

get_footer();
?>