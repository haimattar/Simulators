	<?php 
 function get_wordings($project_meta_id){
	global $wpdb;
	$SQL = "SELECT * FROM wp_project_meta_wording WHERE project_meta_id ='".$project_meta_id."' ORDER BY id ASC";
	$rsMeta = $wpdb->get_results($SQL);
	//print_r($rsMeta);
	$arraywpmeta = array();
	if(count($rsMeta)>0){
		for($x=0;$x<count($rsMeta);$x++){
			if($rsMeta[$x]->wording_meta_id!=0){
				$arraywpmeta[$x] = $rsMeta[$x]->wording_meta_id."-".$rsMeta[$x]->value;
			}else{
				$arraywpmeta[$x] = $rsMeta[$x]->value;
			}
		}
	}
	$SQLPROJECTMETA = "SELECT designation_id FROM wp_project_meta WHERE id='".$project_meta_id."'";
	$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA);
	$designation_id = $rsProdmeta[0]->designation_id;
	$SQwording="SELECT * FROM wp_wording WHERE desg_id ='".$designation_id."' AND otherparts='No' ORDER BY `desg_id` ASC";
$resultWord = $wpdb->get_results($SQwording);
$meta = "";
$meta1 = "";
$meta2 = "";
if(count($resultWord)>0){
	$wpmetaid = "";
	$wpmetavalues = "";
	$meta .= '<table width="100%">';
	for($y=0;$y<count($resultWord);$y++){
		if($resultWord[$y]->otherparts=="No"){
		$metaselectionsdata = $arraywpmeta[$y];
		if(strstr($metaselectionsdata,"-")){
			$metaselections = explode("-",$metaselectionsdata);
			$wpmetaid = $metaselections[0];
		}else{
			if(strstr($rsMeta[$y]->value,",")){
				$wpmetavalues = $rsMeta[$y]->value;
			}else if(strstr($rsMeta[$y]->value,".")){
				$wpmetavalues = $rsMeta[$y]->value;
			}else{
				$wpmetavalues = number_format($rsMeta[$y]->value,0," "," ");
			}
		}
		$wmts=$resultWord[$y]->id;
		$SQwordMeta="SELECT * FROM wp_wording_meta WHERE id='".$wpmetaid."' AND word_id ='".$wmts."' ORDER BY `id` ASC,is_cond ASC";
		$WMeta = $wpdb->get_results($SQwordMeta);
		$meta .= '<tr><td style="width:97px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
		'.stripslashes($resultWord[$y]->title).'
		</font></font></td>';
		$meta .= '<td class="param-input tac">';
		 if(!empty($WMeta)){
			$arraymetaconsd = array();
			//$meta .= '<select name="wmetavalue[]" onchange=\'return  get_conditions(this.value,"'.$catgsid.'","'.$siteurl.'/wp-content/themes/enemat/filterajax/conditions_data.php");\'>';
			foreach($WMeta as $wmr){
				$SQLPRODMETACONDS = "SELECT * FROM wp_project_meta_conditions WHERE project_meta_id='".$project_meta_id."' AND wording_meta_id='".$wmr->id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				
				if(count($rsProdMetaConditions)>0){	
					$values = $wmr->id;					 				
				$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$values."' ORDER BY is_cond ASC";
				$rsConditions = $wpdb->get_results($SQLCOND);
				if(count($rsConditions)>0){
				$selected = "";
			$array_conds = array();
			$condisids = array();
			$condstextvalues = "";
			 for($x=0;$x<count($rsConditions);$x++){
				if($rsConditions[$x]->is_cond=="Yes"){ 
				$cond_id = $rsConditions[$x]->id;
				$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
				$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
				$condionsvals = '';		
				
				$SQLPRODMETACONDS = "SELECT wp_project_meta_conditions.condition_id,wp_meta_conditions_values.mc_title 
									 FROM wp_project_meta_conditions
									 LEFT JOIN wp_meta_conditions_values ON
									 wp_project_meta_conditions.conditions_valueids=wp_meta_conditions_values.id
									WHERE wp_project_meta_conditions.project_meta_id='".$project_meta_id."'
									AND wp_project_meta_conditions.wording_meta_id='".$values."'
									AND wp_project_meta_conditions.condition_id='".$cond_id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
						
			  for($jj=0;$jj<count($rsProdMetaConditions);$jj++){
				$SQLSUBCONDVALUES = "SELECT * FROM wp_project_meta_subconditions WHERE project_meta_id ='".$project_meta_id."' AND subparents_id='".$rsProdMetaConditions[$jj]->condition_id."'";				
				$rsSubConds = $wpdb->get_results($SQLSUBCONDVALUES);
				
				if(count($rsSubConds)>0){
					 $SQLSUBCONDSMETAS = "SELECT wp_cond_meta_cond.cmc_title
										FROM wp_cond_meta_cond
										LEFT JOIN wp_project_meta_subconditions ON
										wp_cond_meta_cond.id=wp_project_meta_subconditions.subcondition_id
										WHERE wp_cond_meta_cond.id='".$rsSubConds[0]->subcondition_id."'";
						
					$rsSubCondstitles = $wpdb->get_results($SQLSUBCONDSMETAS);
					
					$SQLSUBCONDSMETAS1 = "SELECT wp_cond_meta_cond_values.cmcv_title
										FROM wp_cond_meta_cond_values
										LEFT JOIN wp_project_meta_subconditions ON
										wp_cond_meta_cond_values.id=wp_project_meta_subconditions.subconditions_valueids
										WHERE wp_cond_meta_cond_values.id='".$rsSubConds[0]->subconditions_valueids."'";
						
					$rsSubCondsmetatitles = $wpdb->get_results($SQLSUBCONDSMETAS1);
					$meta2 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsSubCondstitles[0]->cmc_title.'</font></font></td><td>'.$rsSubCondsmetatitles[0]->cmcv_title.'</td></tr>';
				}
			  
			  
				$meta1 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$rsProdMetaConditions[$jj]->mc_title.'</td></tr>';
			 }
				if($x==0){
				$meta1 .= $meta2;
			  }
			 }else if($rsConditions[$x]->is_cond=="No"){
					$cond_id = $rsConditions[$x]->id;
					$SQLPRODMETACONDS = "SELECT wp_project_meta_conditions.condition_id,wp_project_meta_conditions.consddacavle,wp_meta_conditions_values.mc_title 
									 FROM wp_project_meta_conditions
									 LEFT JOIN wp_meta_conditions_values ON
									 wp_project_meta_conditions.conditions_valueids=wp_meta_conditions_values.id
									WHERE wp_project_meta_conditions.project_meta_id='".$project_meta_id."'
									AND wp_project_meta_conditions.wording_meta_id='".$values."'
									AND wp_project_meta_conditions.condition_id='".$cond_id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				for($jj=0;$jj<count($rsProdMetaConditions);$jj++){
					$meta1 .= '<tr><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$rsProdMetaConditions[$jj]->consddacavle.'</td></tr>';
				}
			 }	
			}
			}	
			 
				}				
				 
				$meta .=  stripslashes($wmr->title);
			 }
			//$meta .= '</select>';
		}else{
			$meta .= str_replace(".",",",$wpmetavalues);
		}
		 
		$meta .= '</td></tr>';
		} 
	}
		$meta .= $meta1;
		$meta .= '</table>';
 }
	return $meta;
}