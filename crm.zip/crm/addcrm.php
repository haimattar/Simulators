<?php
ob_start();
/* Plugin Name: CRM*/
/* Descriptiopn: CRM*/
add_action( 'admin_menu', 'register_show_category_menu_page_crm' );
function register_show_category_menu_page_crm(){
    add_menu_page( 'CRM', 'CRM', 'manage_options', 'crm', 'my_show_menu_page', plugins_url( 'crm/images/icon.png' ), 51);
	 
}

function my_show_menu_page(){
	include("simulator_listings.php"); 
}
?>



