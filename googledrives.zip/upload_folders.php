<?php  
		@session_start();   
		$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
		require_once( $parse_uri[0] . 'wp-load.php' );
		define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
		global $wpdb;		
		if(isset($_POST['strs']) && $_POST['strs']=="submitfinalreport"){
		//=========Stored Client Info========//
		$current_date = date("Y-m-d H:i:s");
		$datemontharray = array("01"=>"Janvier","02"=>"Février","03"=>"Mars","04"=>"Avril","05"=>"Mai","06"=>"Juin","07"=>"Juillet","08"=>"Août","09"=>"Septembre","10"=>"Octobre","11"=>"Novembre","12"=>"Décembre");
		$current_date_pdf = date("d")." ".$datemontharray[date("m")]." ".date("Y");
		global $wpdb;
		$userid=$_POST['userid'];
		$useremail=$_POST['useremail'];
		$desid=$_POST['scenarioids'];
		$pmetaid = $_POST['pmetaid'];
		$user = new WP_User( $user_id );
		foreach( $user->roles as $role ) {
			$role = get_role( $role );
			if ( $role != null )
			$user_roles = $role->name;
		}
		if($user_roles=="professionaluser"){			
			$parent_userid = get_user_meta($userid,"wp_user_parent",true);
		}else if($user_roles=="admin"){			
			$parent_userid = get_user_meta($userid,"wp_user_parent",true);
		}else{
			$parent_userid = $userid;
		}
		$SQLDESIGNATION = "SELECT * FROM wp_designations WHERE id='".$desid."'";
		$rsDesignation = $wpdb->get_results($SQLDESIGNATION); 
		$companyname =get_the_author_meta( 'company_name', $userid );
		$salesname =   get_the_author_meta('salesname',$userid);
		$first_name =   get_the_author_meta('first_name',$userid);
		$last_name =   get_the_author_meta('last_name',$userid);
		
		$default_prime_mwhc = get_the_author_meta( 'prime_mwhc',$userid);
		$default_prime_mwhcpdf = str_replace(".",",",$default_prime_mwhc);
		$default_precarite = get_the_author_meta( 'precarite',$userid);
		$default_precaritepdf = str_replace(".",",",$default_precarite);
		$default_highprecarite = get_the_author_meta( 'highprecarite',$userid);
		$default_highprecaritepdf = str_replace(".",",",$default_highprecarite); 
		
		 
		$notes =get_the_author_meta( 'notes', $userid );
		$city =get_the_author_meta( 'city', $userid );
		$notes =get_the_author_meta( 'notes', $userid );
		$job =get_the_author_meta( 'job', $userid );
		$notes =get_the_author_meta( 'notes', $userid );
		$phone_number =get_the_author_meta( 'phone_number', $userid );
		$mobile_number =get_the_author_meta( 'mobile_number', $userid );
		$society_number =get_the_author_meta( 'society_number', $userid );
		$society_address =get_the_author_meta( 'society_address', $userid );
		$society_postcode =get_the_author_meta( 'society_postcode', $userid );
		$fileno11 = date('ymd');
		$fileno1 = substr(strtoupper($salesname),0,3);
		$fileno2 = substr(strtoupper($companyname),0,3);
		$fileno3 = substr(strtoupper($_POST['cfullname']),0,3);
		$fileno4 = substr(strtoupper($_POST['cname']),0,3);
		$fileno = trim($fileno11).trim($fileno1).trim($fileno2).trim($fileno3).trim($fileno4);
		$mwhcumac = $_POST['mwhcumac'];
		$classclientmvh=$mwhcumac*$default_prime_mwhc/1000;
		$preclientmvh=$mwhcumac*$default_precarite/1000;
		$gpreclientmvh=$mwhcumac*$default_highprecarite/1000;

		$SQLPMETA = "SELECT prime_value_cal,mwh_cumac FROM wp_project_meta WHERE id='".$pmetaid."'";
		$rsPrMeta = $wpdb->get_results($SQLPMETA); 

		$prime_value_cal = $rsPrMeta[0]->prime_value_cal;
		$mwh_cumac = $rsPrMeta[0]->mwh_cumac;

		$full_name = $last_name." ".$first_name;
		$user = get_user_by( 'id', $userid);
		$email = $user->user_email;
		$prec_prime = 0;
		$prec_bonus = 0;
		$gprec_prime = 0;
		$gprec_bonus = 0;
		$points = trim($_POST['points']);
		$ac1 = str_replace(" €","",$_POST['primeval']);
		$ac = preg_replace('/\s+/', '',$ac1);
		$ae = 0;
		$cee_classique1 = get_option("cee_classique");
		$cee_classique = str_replace(",",".",$cee_classique1);
		$pts = $points/100;
		$prime_prof = ($ac+$ae)*((1/$pts)-1);
		$defaultsac = str_replace(",",".",$default_prime_mwhc);
		if(empty($defaultsac)){
			$defaultprime = get_option("defaultprime");
			$defaultsac = str_replace(",",".",$defaultprime);
		}
		$profits = $mwh_cumac*($cee_classique-$defaultsac);
		$table = $wpdb->prefix . "clientinfo";
		
		$titre_res = isset($_POST['titre_res'])?$_POST['titre_res']:"";
		$client_society_name = isset($_POST['client_society_name'])?$_POST['client_society_name']:"";
		$de_siren = isset($_POST['de_siren'])?$_POST['de_siren']:"";
		$website = isset($_POST['website'])?$_POST['website']:"";
		$debuit_begin = $_POST['debuit_begin'];
		$monthsyear = explode("-",$debuit_begin);
		$debuit_year = $monthsyear[0];
		$debuit_month = $datemontharray[$monthsyear[1]];
		$strs=$wpdb->insert( 
					$table, 
					array( 
							'userid' => $_POST['userid'],
							'parent_userid'=>$parent_userid,
							'file_number'=>$fileno,
							'pufirst_name' => $first_name,
							'pulast_name' => $last_name,
							'pucompany_name' => $companyname,
							'pusociety_number' => $society_number,
							'pusociety_address' => $society_address,
							'pusociety_postcode' => $society_postcode,
							'pucity' => $city,
							'pusalesname' => $salesname,
							'punotes' => $notes,
							'pujobs'=>$job,
							'puemail' => $email,
							'puprime1' => str_replace(",",".",$default_prime_mwhc),
							'puprime2' => str_replace(",",".",$default_precarite),
							'puprime3' => str_replace(",",".",$default_highprecarite),
							'puphone_number' => $phone_number,
							'pumobile_number' => $mobile_number,
							'prime_value_cal' => $prime_value_cal,
							'mwh_cumac' => $mwh_cumac,
							'scenario_id' =>$_POST['scenarioids'],
							'pmetaid' =>$pmetaid,
							'installeture' => $companyname, 
							'fname' => $_POST['cname'],
							'name' => $_POST['cfullname'],
							'address' => $_POST['caddress'],
							'post_code' => $_POST['postalcode'], 
							'ville' => $_POST['ville'],
							'tel' => $_POST['ctel'],
							'mobile' => $_POST['cmobil'],
							'email' => $_POST['cemail'],
							'fiche'=>$_POST['fiche'],
							'fichelink'=>$_POST['fichelink'],
							'scenario_title'=>esc_sql($_POST['scenariotitle']),
							'mwhcumac'=>$_POST['mwhcumac'],
							'commercial' => $salesname,
							'classclient' => $_POST['primeval'],
							'classclientbonus' => $_POST['g_primeval'],
							'classclientmvh' => $classclientmvh,
							'peclient' => $_POST['precarite'],
							'preclientbonus' => $_POST['g_precarite'],
							'preclientmvh' => $preclientmvh,
							'gpeclient' => $_POST['grandprecarite'],
							'gpreclientbonus' => $_POST['g_grandprecarite'],
							'gpreclientmvh' => $gpreclientmvh,
							'client_per' => $points,
							'class_prime'=>$_POST['primeval'],
							'class_bonus'=>$mwh_cumac,
							'prec_prime'=>$prec_prime,
							'prec_bonus'=>$prec_bonus,
							'gprec_prime'=>$gprec_prime,
							'gprec_bonus'=>$gprec_bonus,
							'prime_prof'=>$prime_prof,
							'profits'=>$profits,
							'titre_res'=>$titre_res,
							'client_society_name'=>$client_society_name,
							'de_siren'=>$de_siren,
							'website'=>$website,
							'debuit_begin'=>$debuit_begin,
							'debuit_month'=>$debuit_month,
							'debuit_year'=>$debuit_year,
							'usertype'=>$user_roles,
							'created_date'=>date('Y-m-d')
							
						)
				);
				$crmautoids =  $wpdb->insert_id;
				$SQLPOSTMETAUPDATES = "UPDATE wp_project_meta SET client_status='Yes' WHERE id='".$pmetaid."'";
				$wpdb->query($SQLPOSTMETAUPDATES);
			   if($strs){
		  $from= "gestion@enemat.fr";
		  $to = $_POST['cemail'];		  
		  $user_id = get_current_user_id();
		  if(empty($full_name)){
			$user_info = get_userdata($user_id);
			$full_name = $user_info->user_login;
		  }
		  $siteurl = get_option("siteurl");
		  $logourl = "".$siteurl."/wp-content/uploads/2018/01/logo.png";
		  $logoimages = '<img src="'.$logourl.'"/>';
		  $primevals = number_format($_POST['primeval'],0," "," ")." €";
		  $precarites = number_format($_POST['precarite'],0," "," ")." €";
		  $grandprecarites = number_format($_POST['grandprecarite'],0," "," ")." €";
		  if(strstr($_POST['fiche'],"BAR")){
			  $rsEmails = get_fronts_emailtemplates("documents1");
			  $subjectop = stripslashes($rsEmails[0]->email_subject);
			  $emailbodyop = stripslashes($rsEmails[0]->email_body);
			  
			  $find_sub = array("{15}", "{16}","{D1}","{7}","{8}","{10}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{27}","{27'}","{27''}","{30}");
			  $replace_sub = array($_POST['cname'], $_POST['cfullname'],date("d/m/Y"),$default_prime_mwhc,$default_precarite,stripslashes($companyname),$_POST['cemail'],$_POST['cmobil'],stripslashes($_POST['ctel']),$_POST['caddress'],$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),str_replace(" €","",$primevals),str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites),$fileno);
			  $subject = str_replace($find_sub,$replace_sub,$subjectop);
		  
			  $find_body = array("{15}","{16}","{25}","{logourl}","{D1}","{7}","{8}","{10}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{27}","{27'}","{27''}","{30}");
			  
			  $primevalspdf = str_replace(" ", "* ",$primevals);
			  $primevalspdf1 = str_replace(" €", "*",$primevals);		  
			  $replace_body = array($_POST['cname'],$_POST['cfullname'],$primevals,$logoimages,date("d/m/Y"),$default_prime_mwhc,$default_precarite,stripslashes($companyname),$_POST['cemail'],$_POST['cmobil'],stripslashes($_POST['ctel']),$_POST['caddress'],$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),str_replace(" €","",$primevals),str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites),$fileno);
			  $subject = str_replace($find_sub,$replace_sub,$subjectop);
			  
			  $find_body = array("{15}","{16}","{25}","{logourl}","{D1}","{7}","{8}","{10}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{27}","{27'}","{27''}","{30}");  
			  $message1 =  str_replace($find_body, $replace_body,$emailbodyop);
			  $message = addslashes($message1);
		  }else{
			  $rsEmails = get_fronts_emailtemplates("documents5");
			  $subjectop = stripslashes($rsEmails[0]->email_subject);
			  $emailbodyop = stripslashes($rsEmails[0]->email_body);
			  
			  $find_sub = array("{15}", "{16}","{D1}","{7}","{8}","{ENEMAT}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{27}","{27'}","{27''}","{30}","{35}","{36}","{37}");
			  $replace_sub = array($_POST['cname'], $_POST['cfullname'],date("d/m/Y"),$default_prime_mwhc,$default_precarite,stripslashes($notes),$_POST['cemail'],$_POST['cmobil'],stripslashes($_POST['ctel']),$_POST['caddress'],$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),str_replace(" €","",$primevals),str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites),$fileno,stripslashes($titre_res),stripslashes($client_society_name),stripslashes($de_siren));
			  $subject = str_replace($find_sub,$replace_sub,$subjectop);
			
			  $find_body = array("{15}","{16}","{25}","{logourl}","{D1}","{7}","{8}","{ENEMAT}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{27}","{27'}","{27''}","{30}","{35}","{36}","{37}");
			 
			  $primevalspdf = str_replace(" ", "* ",$primevals);
			  $primevalspdf1 = str_replace(" €", "*",$primevals);		  
			  $replace_body = array($_POST['cname'],$_POST['cfullname'],$primevals,$logoimages,date("d/m/Y"),$default_prime_mwhc,$default_precarite,stripslashes($notes),$_POST['cemail'],$_POST['cmobil'],$_POST['ctel'],stripslashes($_POST['caddress']),$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),str_replace(" €","",$primevals),str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites),$fileno,stripslashes($titre_res),stripslashes($client_society_name),stripslashes($de_siren));  
			  $message1 =  str_replace($find_body, $replace_body,$emailbodyop);
			  $message = addslashes($message1);		  
		  }
		  
		  $clientname = stripslashes($_POST['cname']).' '.stripslashes($_POST['cfullname']);
		  $docsignemailtemps = get_option("docsignemailtemps");
		  if(strstr($_POST['fiche'],"BAR")){
			if($user_roles=="professionaluser" || $user_roles=="administrator"){
				// Simulator done by PU
				//==Doc 2==//
				$rsContents = get_fronts_documents("documents2");
				$page1 = stripslashes($rsContents[0]->page1);				 
				$page2 =  stripslashes($rsContents[0]->page2);				
				
				$find_docs_array = array("{img1}","{img2}","{img3}","{27}","{23'}","{fichelink}","{23}","{img4}","{img5}","{img6}","{img7}","{16}","{15}","{br}","{19}","{18}","{17}","{20}","{21}","{22}","{current_date_pdf}","{img8}","{img9}","{img10}","{img11}","{30}","{10}","{img12}","{27'}","{27''}","{7}","{8}","{dateplus1year}","{D1}");
				$replace_docs_array = array(
				'<img  align="left" width="250" height="100" src="'.get_site_url().'/wp-content/uploads/2018/05/logsec-1.png"/>',
				'<img align="center" width="150" src="'.get_site_url().'/wp-content/uploads/2018/04/logo2.png"/>',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ2.png" width="10px" height="10px">',
				$primevals,
				stripslashes($_POST['scenariotitle']),$_POST['fichelink'],$_POST['fiche'],
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				stripslashes($_POST['cfullname']),stripslashes($_POST['cname']),"<br/>",$_POST['ctel'],$_POST['cmobil'],$_POST['cemail'],stripslashes($_POST['caddress']),$_POST['postalcode'],
				stripslashes($_POST['ville']),$current_date_pdf,
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/signataire12.png">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/attention.png" width="50px" padding-right="0px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/8000.png" width="150px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/ministry.png" style="border:1px solid #000;margin-right:10px;"/>',$fileno,$companyname,
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/avisabc.png">',
				$precarites,$grandprecarites,$default_prime_mwhcpdf,$default_precaritepdf,date('d/m/Y',strtotime("+1 Year")),date('d/m/Y')
				);		
				
				$page1contents = str_replace($find_docs_array,$replace_docs_array,$page1);
				$page2contents = str_replace($find_docs_array,$replace_docs_array,$page2);
				//==Doc 2==//
				$html = '<html>
							<head>
								<title>'.$_POST['cname'].' Merci de valider votre prime energie</title>
							</head>
							<body>
								<div id="scenariosummary">
								'.$page1contents.'
								'.$page2contents.' 
								</div>
							</body>
						</html>';
				// Simulator done by PU				
			}else if($user_roles=="admin" || $user_roles=="superadmin"){
				// Simulator done by Admin
				//==Doc 6==//
				$rsContents = get_fronts_documents("documents6");
				$page1 = stripslashes($rsContents[0]->page1);				 
				$page2 =  stripslashes($rsContents[0]->page2);				
				
				$find_docs_array = array("{img1}","{img2}","{img3}","{27}","{23'}","{fichelink}","{23}","{img4}","{img5}","{img6}","{img7}","{16}","{15}","{br}","{19}","{18}","{17}","{20}","{21}","{22}","{current_date_pdf}","{img8}","{img9}","{img10}","{img11}","{30}","{ENEMAT}","{img12}","{27'}","{27''}","{7}","{8}","{dateplus1year}","{D1}");
				$replace_docs_array = array(
				'<img  align="left" width="250" height="100" src="'.get_site_url().'/wp-content/uploads/2018/05/logsec-1.png"/>',
				'<img align="center" width="150" src="'.get_site_url().'/wp-content/uploads/2018/04/logo2.png"/>',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ2.png" width="10px" height="10px">',
				$primevals,
				stripslashes($_POST['scenariotitle']),$_POST['fichelink'],$_POST['fiche'],
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/squ1.png" width="10px" height="10px">',
				stripslashes($_POST['cfullname']),stripslashes($_POST['cname']),"<br/>",$_POST['ctel'],$_POST['cmobil'],$_POST['cemail'],stripslashes($_POST['caddress']),$_POST['postalcode'],
				stripslashes($_POST['ville']),$current_date_pdf,
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/signataire12.png">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/attention.png" width="50px" padding-right="0px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/8000.png" width="150px">',
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/ministry.png" style="border:1px solid #000;margin-right:10px;"/>',$fileno,stripslashes($notes),
				'<img src="'.get_site_url().'/wp-content/uploads/2018/05/avisabc.png">',
				$precarites,$grandprecarites,$default_prime_mwhcpdf,$default_precaritepdf,date('d/m/Y',strtotime("+1 Year")),date('d/m/Y')
				);				
					
				$page1contents = str_replace($find_docs_array,$replace_docs_array,$page1);
				$page2contents = str_replace($find_docs_array,$replace_docs_array,$page2);
				//==Doc 6==//
				$html = '
					<html>
						<head>
							<title>'.$_POST['cname'].' Merci de valider votre prime energie</title>
						</head>
						<body>
						<div id="scenariosummary">
						'.$page1contents.'
						'.$page2contents.' </div>
					</body>
					</html>';
				// Simulator done by Admin	
			}
			$headers  = "Content-type: text/html; charset=utf-8 \r\n"; 
			//$headers .= "From: Site <$from>\r\n"; 
			$headers  .= 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			// Create email headers
			$headers .= 'From: '.$from."\r\n".

				'Reply-To: '.$from."\r\n" .

				'X-Mailer: PHP/' . phpversion();
			//$attachments = ABSPATH."wp-content/themes/enemat/pdfs/TRA-EQ-114.pdf";
						//=====Generate PDF=======//						
						$filename = generate_pdfs($html,'Offre-de-Prime-'.$_POST['cname'].'-'.$_POST['cfullname'].'.pdf');
						$attachments = $filename;
						//=====Generate PDF=======//
						$sigparameter = 1;
			}else{
					//=====Doc5/& PDF=======//
				if($user_roles=="professionaluser" || $user_roles=="administrator"){
					// Simulator done by PU
					$rsContents = get_fronts_documents("documents5");
					$page1 = stripslashes($rsContents[0]->page1);
				}else if($user_roles=="admin" || $user_roles=="superadmin"){
					// Simulator done by Admin
					$rsContents = get_fronts_documents("documents7");
					$page1 = stripslashes($rsContents[0]->page1);	
				}			
				$find_docs_array = array("{img1}","{D1}","{30}","{datepls3months}","{36}","{23}","{23'}","{37}","{20}","{21}","{22}","{19}","{18}","{7}","{32}","{31}","{plus11months}","{15}","{16}","{35}","{17}","{img2}");
				$replace_docs_array = array(
				'<img  align="right" src="'.get_site_url().'/wp-content/uploads/2018/08/logonews.png">',		
				date('d/m/Y'),$fileno,date('d/m/Y',strtotime('+3 months')),stripslashes($client_society_name),$_POST['fiche'],stripslashes($_POST['pmtitle']),stripslashes($de_siren),stripslashes($_POST['caddress']),$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['ctel'],$_POST['cmobil'],$default_prime_mwhc,str_replace(".",",",number_format($mwhcumac,0," "," ")),$primevals,date('d/m/Y',strtotime('+11 months')),stripslashes($_POST['cfullname']),stripslashes($_POST['cname']),stripslashes($titre_res),$_POST['cemail'],
				'<img  align="left"src="'.get_site_url().'/wp-content/uploads/2018/08/stamps.png">');			
				
				$pagecontents = str_replace($find_docs_array,$replace_docs_array,$page1);
					 $html = '
					<html>
					<head>
						<title>Pour inciter et supporter les travaux d’amélioration de la performance énergétique</title>
					</head>
					<body>
		<div id="scenariosummary">'.$pagecontents.'</div>
		</body>
				</html>'; 		
			$headers  = "Content-type: text/html; charset=utf-8 \r\n"; 
			//$headers .= "From: Site <$from>\r\n"; 
			$headers  .= 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			// Create email headers
			$headers .= 'From: '.$from."\r\n".

				'Reply-To: '.$from."\r\n" .

				'X-Mailer: PHP/' . phpversion();
			//$attachments = ABSPATH."wp-content/themes/enemat/pdfs/TRA-EQ-114.pdf";
			//=====Generate PDF=======//
				$filename = generate_pdfs($html,'Offre-de-Prime-'.$_POST['cname'].'-'.$_POST['cfullname'].'.pdf');
				$attachments = $filename;
				//=====Doc5/7 PDF=======//
				$sigparameter = 2;
			}	
			//=========Integrate API=======//
				$docdesigns = api_integrate($filename,$_POST['cname'],$to,$subject,$message,$crmautoids,$fileno,$sigparameter);
			//=========Integrate API=======//
					
		if($docdesigns[0] =="success"){	
			$filenossend = $docdesigns[1];			
			if($user_roles=="professionaluser" || $user_roles=="administrator"){
				//=====Project contract PDF=======//
				$headersconts  = "Content-type: text/html; charset=utf-8 \r\n"; 
				//$headers .= "From: Site <$from>\r\n"; 
				$headersconts  .= 'MIME-Version: 1.0' . "\r\n";
				$headersconts .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				// Create email headers
				$headersconts .= 'From: '.$from."\r\n".

				'Reply-To: '.$from."\r\n" .

				'X-Mailer: PHP/' . phpversion();
				//$attachments = ABSPATH."wp-content/themes/enemat/pdfs/TRA-EQ-114.pdf";
				//=====Generate PDF=======//
				$rsContents = get_fronts_documents("documents4");
				$page1 = stripslashes($rsContents[0]->page1);
				
				$find_docs_array = array("{D1}","{dateplus3months}","{30}","{10}","{23}","{23'}","{11}","{2}","{3}","{16}","{15}","{12}","{13}","{14}","{20}","{21}","{22}","{dateplus6months}","{7}","{8}","{26}","{27}","{img2}");
				$replace_docs_array = array(date('d/m/Y'),date('d/m/Y',strtotime('+3 months')),$filenossend,$companyname,$_POST['fiche'],stripslashes($_POST['pmtitle']),$society_number,$first_name,$last_name,$_POST['cfullname'],$_POST['cname'],stripslashes($society_address),$society_postcode,$city,stripslashes($_POST['caddress']),$_POST['postalcode'],$_POST['ville'],date('d/m/Y',strtotime('+6 months')),$default_prime_mwhc,$default_precarite,str_replace(".",",",number_format($mwhcumac,0," "," ")),$primevals,'<img  align="left"  src="'.get_site_url().'/wp-content/uploads/2018/08/stamps.png">');
				
				$pagecontents = str_replace($find_docs_array,$replace_docs_array,$page1);
				$htmlcontract = '
						<html>
							<head>
								<title>CONTRAT PROJET -PARTENAIRE</title>
							</head>
							<body>
				<div id="scenariosummary">'.$pagecontents.'</div>
				</body>
						</html>';
							 $attachments1 = generate_pdfs($htmlcontract,'Contrat-Projet-Partenaire-'.$_POST['cname'].'-'.$_POST['cfullname'].'.pdf');
							//=====Project contract PDF=======//
							 $cltsname = $_POST['cname'].' '.$_POST['cfullname'];
							 $degree = html_entity_decode("&deg;");
							 $degrees = substr($degree,1);
							 if(strstr($_POST['fiche'],"BAR")){							  
								 $rsEmails = get_fronts_emailtemplates("documents2");
								 $email_subject_contracts = stripslashes($rsEmails[0]->email_subject);
								 $email_body_contracts = stripslashes($rsEmails[0]->email_body);
								 
								  $array_find_contrsubject = array("{15}","{16}","n̊","{30}","{D1}","{7}","{8}","{10}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{27}","{27'}","{27''}");
								  $array_replace_contrsubject = array($_POST['cname'],$_POST['cfullname'],"n".$degrees."",$filenossend,date("d/m/Y"),$default_prime_mwhc,$default_precarite,stripslashes($companyname),$_POST['cemail'],$_POST['cmobil'],stripslashes($_POST['ctel']),$_POST['caddress'],$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),str_replace(" €","",$primevals),str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites));							 
								 $subjectconrcts =  str_replace($array_find_contrsubject,$array_replace_contrsubject,$email_subject_contracts);
								 
								 $array_find_contrmsgbody = array("{3}","{2}","{27}","{15}","{16}","{27'}","{27''}","{logourl}","{D1}","{7}","{8}","{10}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{30}");
								  $array_replace_contrmsgbody = array($first_name,$last_name,str_replace(" €","",$primevals),$_POST['cname'],$_POST['cfullname'],str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites),$logoimages,date("d/m/Y"),$default_prime_mwhc,$default_precarite,stripslashes($companyname),
								  $_POST['cemail'],$_POST['cmobil'],$_POST['ctel'],stripslashes($_POST['caddress']),$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),$fileno);
								  
								 $messagectrcts=   str_replace($array_find_contrmsgbody,$array_replace_contrmsgbody,$email_body_contracts);
							}else{							 
								 $rsEmails = get_fronts_emailtemplates("documents3");
								 $email_subject_contracts = stripslashes($rsEmails[0]->email_subject);
								 $email_body_contracts = stripslashes($rsEmails[0]->email_body);
								  $array_find_contrsubject = array("{15}","{16}","n̊","{30}","{D1}","{7}","{8}","{ENEMAT}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{27}","{27'}","{27''}","{35}","{36}","{37}");
								  $array_replace_contrsubject = array($_POST['cname'],$_POST['cfullname'],"n".$degrees."",$filenossend,date("d/m/Y"),$default_prime_mwhc,$default_precarite,stripslashes($notes),$_POST['cemail'],$_POST['cmobil'],stripslashes($_POST['ctel']),$_POST['caddress'],$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),str_replace(" €","",$primevals),str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites),stripslashes($titre_res),stripslashes($client_society_name),stripslashes($de_siren));							 
								 $subjectconrcts =  str_replace($array_find_contrsubject,$array_replace_contrsubject,$email_subject_contracts);
								  
								  $array_find_contrmsgbody = array("{3}","{2}","{27}","{15}","{16}","{27'}","{27''}","{logourl}","{35}","{36}","{37}","{D1}","{7}","{8}","{ENEMAT}","{17}","{18}","{19}","{20}","{21}","{22}","{23}","{23'}","{30}");
								   $array_replace_contrmsgbody = array($first_name,$last_name,str_replace(" €","",$primevals),$_POST['cname'],$_POST['cfullname'],str_replace(" €","",$precarites),str_replace(" €","",$grandprecarites),$logoimages,stripslashes($titre_res),stripslashes($client_society_name),stripslashes($de_siren),date('d/m/Y'),$default_prime_mwhc,$default_precarite,stripslashes(stripslashes($notes)),
								  $_POST['cemail'],$_POST['cmobil'],$_POST['ctel'],stripslashes($_POST['caddress']),$_POST['postalcode'],stripslashes($_POST['ville']),$_POST['fiche'],stripslashes($_POST['scenariotitle']),$fileno);
								  
								 $messagectrcts=   str_replace($array_find_contrmsgbody,$array_replace_contrmsgbody,$email_body_contracts);
							}		
				//=====Project contract PDF=======//
				//===Send PU===//
				$to = $email;				 
			  	wp_mail($to, $subjectconrcts, $messagectrcts, $headers, array($attachments1,$filename));
				//===Send PU===//
				 //@unlink(ABSPATH."wp-content/themes/enemat/pdfs/".basename($attachments1));
				 
				 send_google_drive($crmautoids,$fileno,$filename,$attachments1);
			 }else{				 
				send_google_drive($crmautoids,$fileno,$filename,"");
			 }
			 //@unlink(ABSPATH."wp-content/themes/enemat/pdfs/".basename($filename));
			echo json_encode(array('status' => 'success'));
		} else {
		echo json_encode(array('status' => 'error'));
		}
		}else {
		echo json_encode(array('status' => 'error'));
		} 
		//=========Stored Client Info========//
		}else{
		 //Repartissez le montant total de la prime==//
		$currency = $_POST['currency'];
		if(empty($currency)){
			$currency = "€";
		}
		
		$pmetaid = $_POST['prmetaids'];
		$SQLPMETA = "SELECT * FROM wp_project_meta WHERE id='".$pmetaid."'";
		$rsPrMeta = $wpdb->get_results($SQLPMETA); 	
		$mwhvalue = $rsPrMeta[0]->mwh_cumac;	
		$userid = $_POST['userid'];
		//echo $amounts = $_POST['vals']?$_POST['vals']:'100';
		$amounts=$_POST['vals']/100;

		$key1='prime_mwhc';
		$key2='precarite';
		$key3='highprecarite';
		$single = true;

		$prime_mwhc= get_user_meta( $userid, $key1, $single );
		if(empty($prime_mwhc)){
			$defaultprime = get_option("defaultprime");
			$prime_mwhc = str_replace(",",".",$defaultprime);
		}else{
			$prime_mwhc = str_replace(",",".",$prime_mwhc);
		}
		$precarites= get_user_meta( $userid, $key2, $single );
		if(empty($precarites)){
			$precarites = get_option("precarites");
			$precarites = str_replace(",",".",$precarites);
		}else{
			$precarites = str_replace(",",".",$precarites);
		}
 
		 
		$prime=$mwhvalue*$prime_mwhc*$amounts;	
		$precarite=$mwhvalue*$precarites*$amounts;
		$highprecarite= $precarite*2;

		$grade_prime=(1-$amounts)*$mwhvalue*$prime_mwhc;
		$grade_precarite=(1-$amounts)*$mwhvalue*$precarites;
		$grade_highprecarite= $grade_precarite*2;
		$array_heads = "";
		if(strstr($rsPrMeta[0]->number_title,"BAR")){			
			$array_heads .= '<table width="100%" border="0"cellpadding="0" cellspacing="0">';
			$array_heads .= '<tr>
			  <th class="newrcvse"></th>
			  <th id="a2" axis="expenses">Pour votre client</th>
			  <th id="a3" axis="expenses">Pour vous</th>
			</tr>
			<tr>
			  <td class="newrcvse"></td>
			 <td></td>
			 <td></td></tr>';
			$array_heads .= '<tr><td class="newrcvse">Prime sans precarité</td>
			<td><a>'.number_format($prime,0," "," ")." ".$currency.'</a><input type="hidden" readonly value="'.$prime.'" name="primevalaj" id="primevalaj" ></td>
			<td><a>'.number_format($grade_prime,0," "," ")." ".$currency.'</a><input type="hidden" readonly value="'.$grade_prime.'" name="g_primevalaj" id="g_primevalaj" ></td></tr>
			<tr><td class="newrcvse">Prime avec précarité  (avec justificatif)</td>
			<td><a>'.number_format($precarite,0," "," ")." ".$currency.'</a><input type="hidden" readonly value="'.$precarite.'" name="precariteaj" id="precariteaj" ></td>
			<td><a>'.number_format($grade_precarite,0," "," ")." ".$currency.'</a><input type="hidden" readonly value="'.$grade_precarite.'" name="g_precariteaj" id="g_precariteaj" ></td></tr>
			<tr><td class="newrcvse">Prime grande avec précarité  (avec justificatif)</td>
			<td><a>'.number_format($highprecarite,0," "," ")." ".$currency.'</a><input type="hidden" readonly value="'.$highprecarite.'" name="grandprecariteaj" id="grandprecariteaj" ></td>
			<td><a>'.number_format($grade_highprecarite,0," "," ")." ".$currency.'</a><input type="hidden" readonly value="'.$grade_highprecarite.'" name="g_grandprecariteaj" id="g_grandprecariteaj" ></td>
			</tr>';
			$array_heads .= '</table>';


			$amt1 = number_format($prime,2);
			$amts1 = number_format($prime,0," "," ");
			$amt2 = number_format($grade_prime,0," "," ");
			$amts2 = number_format($grade_prime,0," "," ");

			$arrays = array("amount1"=>$amts1." ".$currency,"amount2"=>$amts2." ".$currency,"details"=>$array_heads);
			echo json_encode($arrays);
		}else{
			$array_heads .= '<table width="100%" border="0"cellpadding="0" cellspacing="0">';
			$array_heads .= '<tr>
			  <th class="newrcvse"></th>
			  <th id="a2" axis="expenses">Pour votre client</th>
			  <th id="a3" axis="expenses">Pour vous</th>
			</tr>
			<tr>
			  <td class="newrcvse"></td>
			 <td></td>
			 <td></td></tr>';
			$array_heads .= '<tr><td class="newrcvse">Prime sans precarité</td>
			<td><input type="hidden" readonly value="'.$prime.'" name="primevalaj" id="primevalaj" ></td>
			<td><input type="hidden" readonly value="" name="g_primevalaj" id="g_primevalaj" ></td></tr>
			<tr><td class="newrcvse">Prime avec précarité  (avec justificatif)</td>
			<td><input type="hidden" readonly value="" name="precariteaj" id="precariteaj" ></td>
			<td><input type="hidden" readonly value="" name="g_precariteaj" id="g_precariteaj" ></td></tr>
			<tr><td class="newrcvse">Prime grande avec précarité  (avec justificatif)</td>
			<td><input type="hidden" readonly value="" name="grandprecariteaj" id="grandprecariteaj" ></td>
			<td><input type="hidden" readonly value="" name="g_grandprecariteaj" id="g_grandprecariteaj" ></td>
			</tr>';
			$array_heads .= '</table>';
			$amt1 = number_format($prime,2);
			$amts1 = number_format($prime,0," "," ");
			$amt2 = number_format($grade_prime,0," "," ");
			$amts2 = number_format($grade_prime,0," "," ");

			$arrays = array("amount1"=>$amts1." ".$currency,"amount2"=>$amts2." ".$currency,"details"=>$array_heads);
			echo json_encode($arrays);
		}
		//Repartissez le montant total de la prime==//
		}
		//========Send Docs=========//
		function api_integrate($filename,$cname,$to,$subject,$message,$crmautoids,$fileno,$sigparameter){
			$apiurl = get_option("apiurl");
			$integratorKey = get_option("integratorKey");;
			$email = get_option("apiemail");
			$password = get_option("apipassword");
			
			$recipient_email = $to;
			$name = $cname;
			$document_name = $filename;

		// construct the authentication header:
		$header = "<DocuSignCredentials><Username>" . $email . "</Username><Password>" . $password . "</Password><IntegratorKey>" . $integratorKey . "</IntegratorKey></DocuSignCredentials>";

		/////////////////////////////////////////////////////////////////////////////////////////////////
		// STEP 1 - Login (to retrieve baseUrl and accountId)
		/////////////////////////////////////////////////////////////////////////////////////////////////
		$url = $apiurl."/login_information";
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array("X-DocuSign-Authentication: $header"));

		$json_response = curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		//print_r($json_response);
		if ( $status != 200 ) {
			echo "error calling webservice, status is:" . $status;
			exit(-1);
		}

		$response = json_decode($json_response, true);
		$accountId = $response["loginAccounts"][0]["accountId"];
		$baseUrl = $response["loginAccounts"][0]["baseUrl"];
		curl_close($curl);

		//--- display results
		//echo "\naccountId = " . $accountId . "\nbaseUrl = " . $baseUrl . "\n";

		/////////////////////////////////////////////////////////////////////////////////////////////////
		// STEP 2 - Create an envelope with one recipient, one tab, one document and send!
		/////////////////////////////////////////////////////////////////////////////////////////////////
		if($sigparameter==1){
			$data = "{
			  \"emailBlurb\":\"".$message."\",
			  \"emailSubject\":\"".$subject."\",
			  \"documents\":[
				{
				  \"documentId\":\"1\",
				  \"name\":\"".$document_name."\"
				}
			  ],
			  \"recipients\":{
				\"signers\":[
				  {
					\"email\":\"$recipient_email\",
					\"name\":\"$name\",
					\"recipientId\":\"1\",
					\"tabs\":{
					 \"dateSignedTabs\":[
						{
						  \"anchorString\":\"Date :\",
						  \"anchorXOffset\":\"50\",
						  \"anchorYOffset\":\"-10\",
						  \"documentId\":\"1\",
						  \"pageNumber\":\"2\",
						}
					  ],
					  \"signHereTabs\":[
						{
						  \"anchorString\":\"Signataire :\",
						  \"anchorXOffset\":\"10\",
						  \"anchorYOffset\":\"50\",
						  \"documentId\":\"1\",
						  \"pageNumber\":\"2\",
						}
					  ]
					}
				  }
				]
			  },
			  \"status\":\"sent\"
			}";  
		}else if($sigparameter==2){
			$data = "{
		  \"emailBlurb\":\"".$message."\",
		  \"emailSubject\":\"".$subject."\",
		  \"documents\":[
			{
			  \"documentId\":\"1\",
			  \"name\":\"".$document_name."\"
			}
		  ],
		  \"recipients\":{
			\"signers\":[
			  {
				\"email\":\"$recipient_email\",
				\"name\":\"$name\",
				\"recipientId\":\"1\",
				\"tabs\":{
				 \"dateSignedTabs\":[
					{
					  \"anchorString\":\"..............................\",
					  \"anchorXOffset\":\"0\",
					  \"anchorYOffset\":\"-5\",
					  \"documentId\":\"1\",
					  \"pageNumber\":\"2\",
					}
				  ],
				  \"signHereTabs\":[
					{
					  \"anchorString\":\"Signature\",
					  \"anchorXOffset\":\"195\",
					  \"anchorYOffset\":\"35\",
					  \"documentId\":\"1\",
					  \"pageNumber\":\"2\",
					}
				  ]
				}
			  }
			]
		  },
		  \"status\":\"sent\"
		}";  
		}
		$file_contents = file_get_contents($document_name);

		$requestBody = "\r\n"
		."\r\n"
		."--myboundary\r\n"
		."Content-Type: application/json\r\n"
		."Content-Disposition: form-data\r\n"
		."\r\n"
		."$data\r\n"
		."--myboundary\r\n"
		."Content-Type:application/pdf\r\n"
		."Content-Disposition: file; filename=\"$filename.\"; documentid=1 \r\n"
		."\r\n"
		."$file_contents\r\n"
		."--myboundary--\r\n"
		."\r\n";

		// *** append "/envelopes" to baseUrl and as signature request endpoint
		$curl = curl_init($baseUrl . "/envelopes" );
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $requestBody);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			'Content-Type: multipart/form-data;boundary=myboundary',
			'Content-Length: ' . strlen($requestBody),
			"X-DocuSign-Authentication: $header" )
		);

		$json_response = curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		if ( $status != 201 ) {
			echo "error calling webservice, status is:" . $status . "\nerror text is --> ";
			print_r($json_response); echo "\n";
			exit(-1);
		}

		$response = json_decode($json_response, true);
		//$envelopeId = $response["envelopeId"];
		//Update Table
		global $wpdb;
		if(!empty($response["envelopeId"])){
			$sendmaildate = $response["statusDateTime"];
			$envelopeId = $response["envelopeId"];			 
			$SQL = "UPDATE wp_clientinfo SET file_number='".$fileno."',sendmaildate='".$sendmaildate."',envelopeId='".$response["envelopeId"]."' ,docusignstatus='".$response["status"]."' WHERE id='".$crmautoids."'";
			$wpdb->query($SQL);

		//--- display results
		//echo "Document is sent! Envelope ID = " . $envelopeId . "\n\n";
			$array_response = array("success",$fileno);
		}else{
			$array_response = array("error",$fileno);
		}
		return $array_response;
		}
		//========Send Docs=========//
		//=====Get Documents========//
		function get_fronts_documents($pagekeys){
			global $wpdb;
			$SQL = "SELECT * FROM wp_word_documents WHERE pagekeys='".esc_sql($pagekeys)."'";
			$rs = $wpdb->get_results($SQL);
			return $rs;
		}
		//=====Get Documents========//
		//=====Get Email Templates========//
		function get_fronts_emailtemplates($emailtempltkeys){
			global $wpdb;
			$SQL = "SELECT * FROM wp_emailtemplates WHERE emailtempltkeys='".esc_sql($emailtempltkeys)."'";
			$rs = $wpdb->get_results($SQL);
			return $rs;
		}
		//=====Get Email Templates========//
		//=====Generate PDF=======//
		function generate_pdfs($html,$filnames){
			require_once(ABSPATH.'wp-content/themes/enemat/filterajax/tcpdf/tcpdf.php');
						$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
						$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
						$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
						// set default monospaced font
						$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
						// set auto page breaks
						$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
						$pdf->setPrintHeader(false);
						$pdf->setPrintFooter(false);
						// set some language-dependent strings (optional)
						if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
							require_once(dirname(__FILE__).'/lang/eng.php');
							$pdf->setLanguageArray($l);
						}
						// set default font subsetting mode
						$pdf->setFontSubsetting(true);
						// Set font
						// dejavusans is a UTF-8 Unicode font, if you only need to
						// print standard ASCII chars, you can use core fonts like
						// helvetica or times to reduce file size.
						$pdf->SetFont('dejavusans', '', 10, '', true);
						// Add a page
						// This method has several options, check the source code documentation for more information.
						$pdf->SetDisplayMode('fullpage', 'SinglePage', 'UseNone');
						$pdf->AddPage('P', 'A3');
						// set text shadow effect
						$pdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,196,196), 'opacity'=>1, 'blend_mode'=>'Normal'));
						// Set some content to print
						$find = array("<",">");
						$replace = array("&lt;","&gt;");
						$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
						ob_end_clean();
						$filename = ABSPATH.'wp-content/themes/enemat/pdfs/'.$filnames.'';
						$pdf->Output($filename, 'F');
						return $filename;
		}
		//=====Generate PDF=======//
		//======Send To Google Drive======//
		function send_google_drive($id,$fileno,$filename1,$filename2){
			global $wpdb;
			require(ABSPATH.'/wp-content/themes/enemat/googledrives/vendor/autoload.php');
			$client = getClient();
			$service = new Google_Service_Drive($client);
			$folderslink = "";
			$docusignorgs = "";
			$contractdrivelink = "";
			if(!empty($filename1)){ 
				$results = $service->files->listFiles();
				foreach ($results->getFiles() as $item) {
					if ($item['name'] == 'ENEMAT CRM FILES') {
						$folderId = $item['id'];
						break;
					}
				}
				$parentid = $folderId;
				$childid = "";
				foreach ($results->getFiles() as $item) {
					if ($item['name'] == $fileno) {
						$childid = $item['id'];
						break;
					}
				}
				if(empty($childid)){
					$fileMetadata = new Google_Service_Drive_DriveFile(array(
										'name' => $fileno,
										'parents'=>array($parentid),
										'mimeType' => 'application/vnd.google-apps.folder'));
										$file = $service->files->create($fileMetadata, array(
										'fields' => 'id'));
					 $folderId = $file->id;
				 }else{
					$folderId = $childid;
				 }
					$newPermission = new Google_Service_Drive_Permission();
					$newPermission->setType('anyone');
					$newPermission->setRole('reader');
					$service->permissions->create($folderId, $newPermission);
					
					$fileMetadata = new Google_Service_Drive_DriveFile(array(
								'name' => array(basename($filename1)),
								'parents' => array($folderId)
							));
							$content = file_get_contents($filename1);
							$files = $service->files->create($fileMetadata, array(
									'data' => $content,
									'uploadType' => 'resumable',
									'fields' => 'id'));	
					$fileids = $files->id; 
					$docusignorgs = "https://drive.google.com/open?id=".$fileids."";
					$folderslink = "https://drive.google.com/drive/folders/".$folderId."";
					@unlink(ABSPATH."wp-content/themes/enemat/pdfs/".basename($filename1));
					$newPermission = new Google_Service_Drive_Permission();
					$newPermission->setType('anyone');
					$newPermission->setRole('reader');
					$service->permissions->create($fileids, $newPermission);
				 
			}
			 
			if(!empty($filename2)){ 
				$results = $service->files->listFiles();
				foreach ($results->getFiles() as $item) {
					if ($item['name'] == '46 - CONTRAT PARTENARIAT') {
						$folderId = $item['id'];
						break;
					}
				}
				 
					$fileMetadata = new Google_Service_Drive_DriveFile(array(
								'name' => array(basename($filename2)),
								'parents' => array($folderId)
							));
							$content = file_get_contents($filename2);
							$files = $service->files->create($fileMetadata, array(
									'data' => $content,
									'uploadType' => 'resumable',
									'fields' => 'id'));	
					$fileids1 = $files->id; 
					$contractdrivelink = "https://drive.google.com/open?id=".$fileids1."";
					$newPermission = new Google_Service_Drive_Permission();
					$newPermission->setType('anyone');
					$newPermission->setRole('reader');
					$service->permissions->create($fileids1, $newPermission);
					@unlink(ABSPATH."wp-content/themes/enemat/pdfs/".basename($filename2));
				 
			}
			$SQLUPDATE = "UPDATE wp_clientinfo SET docusignorgs='".$docusignorgs."',folderid='".$folderslink."',contractdrivelink='".$contractdrivelink."' WHERE id='".$id."'";
			$wpdb->query($SQLUPDATE);
		}
		function getClient(){
			$client = new Google_Client();
			$client->setApplicationName('Google Drive API PHP Quickstart');
			$client->setScopes(Google_Service_Drive::DRIVE);
			$client->setAuthConfig(ABSPATH.'/wp-content/themes/enemat/googledrives/credentials.json');
			return $client;
		}
		//======Send To Google Drive======//
		
		?>