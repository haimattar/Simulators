<?php
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
  $postid = $_POST['postid'];
  $status = $_POST['valstatus'];
  $table = $wpdb->prefix.$_POST['table_name'];
  $current_date = date("Y-m-d H:i:s");
 global $wpdb;	
 $table_prefix = $wpdb->prefix;
 $SQL = "UPDATE ".$table." SET status = '".$status."',modify = '".$current_date."' WHERE id='".$postid."'";
 $wpdb->query($SQL);
?>