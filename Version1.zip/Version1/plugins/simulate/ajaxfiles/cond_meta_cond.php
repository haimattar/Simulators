<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$table_wording = $wpdb->prefix . "wording";
$table_wording_meta=$wpdb->prefix."wording_meta";
$table_meta_conditions=$wpdb->prefix."meta_conditions";
$cond_meta_cond=$wpdb->prefix."cond_meta_cond";
$table_neta_conditionsvalue=$wpdb->prefix."meta_conditions_values";
$cond_ID=$_POST['cond_ID'];
$cmc_ID=$_POST['cmc_ID'];
$buttontext = $_POST['sbmt'];
$title = $_POST['wordtitle'];
$current_date = date("Y-m-d H:i:s");
$currentuserid=get_current_user_id();
if(!empty($cmc_ID)){
$formtype = "mcmedit";
$SQLcondS = "SELECT * FROM ".$cond_meta_cond." WHERE cmcond_id='".$cond_ID."' AND id='".$cmc_ID."'";
$condTPTS = $wpdb->get_results($SQLcondS);
$condtitle=$condTPTS[0]->cmc_title?$condTPTS[0]->cmc_title:'';
$condid=$condTPTS[0]->id;		
}else{
$formtype = "mcmnew";
}
$SQLwmcond = "SELECT * FROM ".$table_neta_conditionsvalue." WHERE id='".$cond_ID."'";
$wmcondTPT = $wpdb->get_results($SQLwmcond);
$subtitlem=$wmcondTPT[0]->mc_title?$wmcondTPT[0]->mc_title:'';
$cmetacid=$wmcondTPT[0]->id;
$wmTPTid=$wmcondTPT[0]->meta_id;
$wTPTid=$wmcondTPT[0]->word_id;
$subcondid=$wmcondTPT[0]->cond_id;
?>

<form style="display:block;" id="newform8" action="" method="POST" enctype="multipart/form-data">
<h2><?php echo $title?$title.'Condition Meta Title':"Add New Condition Meta title";?>  </h2>
<input type="hidden" name="userid" id="userid" value="<?php echo $currentuserid; ?>">
<input type="hidden" name="cmcid" id="cmcid" value="<?php echo $cmc_ID; ?>">
<input type="hidden" name="location" id="location" value="">
<p id="designation" style=" border:0px solid gray;">
<label>Meta Title</label>
<?php 
	echo '<input type="hidden" value="'.$wTPTid.'" id="wordid" name="wordid" class="wordid">';
	echo '<input type="hidden" value="'.$wmTPTid.'" id="metaid" name="metaid" class="metaid">';
	echo '<input type="hidden" value="'.$subcondid.'" id="subcondid" name="subcondid" class="subcondid">';
	echo '<input type="hidden" value="'.$cmetacid.'" id="cmetacid" name="cmetacid" class="cmetacid">';
	echo '<input readonly type="text" value="'.$subtitlem.'" id="metatitle" name="metatitle" class="metatitle">';
?>
</p>
<p><label>Condition Title</label><input type="text" name="cmctitle" id="cmctitle" value="<?php echo $condtitle?$condtitle:'';?>"></p>
<p><label>Is Condition Meta?: </label>
<select name="iscmetac" id="iscmetac" onchange="leaveChangeadd(this.value)">
<option value="">Select Value</option>
<option value="Yes" <?php echo ($condTPTS[0]->is_cond=='Yes')?'selected':''; ?>>Yes</option>
<option value="No" <?php echo ($condTPTS[0]->is_cond=='No')?'selected':''; ?>>No</option>
</select>
</p>
<?php $dislay=($condTPTS[0]->is_cond=='No')?'block':'none'; ?>
<p id="iscmetacop" style="display:<?php echo $dislay ;?>;"><label>Other Parts?: </label>
<select name="cmcotherparts" id="cmcotherparts" onchange="leaveChange2(this.value)">
<option value="">Select Value</option>
<option value="No" <?php echo ($condTPTS[0]->otherparts=='No')?'selected':''; ?>>No</option>
<option value="Yes" <?php echo ($condTPTS[0]->otherparts=='Yes')?'selected':''; ?>>Yes</option>
</select>
</p>
<?php $dislays2=($condTPTS[0]->otherparts=='Yes')?'block':'none'; ?>
<p id="iscmetacop2" style="display:<?php echo $dislays2?:'none';?>;"><label>Optional Types?: </label>
<select name="optypes" id="optypes" onchange="leaveChange7(this.value)">
<option value="">Select Value</option>
<option value="Add" <?php echo ($condTPTS[0]->optypes=='Add')?'selected':''; ?>>Add</option>
<option value="Sub" <?php echo ($condTPTS[0]->optypes=='Sub')?'selected':''; ?>>Sub</option>
<option value="Mult" <?php echo ($condTPTS[0]->optypes=='Mult')?'selected':''; ?>>Mult</option>
<option value="Div" <?php echo ($condTPTS[0]->optypes=='Div')?'selected':''; ?>>Div</option>
</select>
</p>
<?php $displayc=($condTPTS[0]->otherparts=="Yes")?'block':'none';?>
<p id="iscmetacop1" style="display:<?php echo $displayc?$displayc:'none';?>;"><label>Condition Value</label><input type="text" name="cmcvalue" id="cmcvalue" value="<?php echo $condTPTS[0]->mc_value; ?>"></p>
<p><label></label><input type="button" class="btn btn-info" onclick="return insertcondmetaconditiontitle('<?php echo $cond_ID;?>','<?php echo plugins_url('ajaxfiles/save_condmetacond_title.php' ,dirname(__FILE__));?>','cond_meta_cond','<?php echo $formtype; ?>');"  name="<?php echo "cmcsubmit";?>" value="<?php  echo $buttontext; ?>" id="submit"></p>
<p id="response"></p>
</form>