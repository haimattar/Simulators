<?php global $wpdb;
@session_start(); 
$adminurl = admin_url();
$siteurl = get_option("siteurl");
$tablename= $wpdb->prefix . "categories";
$current_date = date("Y-m-d H:i:s");
 //===========Paging=============//
$items_per_page =5;	
$page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
$offset = ( $page * $items_per_page ) - $items_per_page;
$SQLcat = "SELECT * FROM $tablename";
$allCategoriesc = $wpdb->get_results($SQLcat);
$total = count($allCategoriesc);

$SQLcatp = "SELECT * FROM $tablename  ORDER BY id ASC
LIMIT ".$offset.",".$items_per_page."";
$allCategories = $wpdb->get_results($SQLcatp);   
$catids=$_GET['cat_ID'];
if($_GET['action']=="editcat"){
		$title="Edit Sector";
		$buttontext="Update";
		$aurl=$adminurl."admin.php?page=sectors";
		$addurl='<a class="page-title-action" id="addnewurl" href="'.$aurl.'">Add New Sector</a>';
		$SQLecat = "SELECT * FROM $tablename WHERE id  LIKE '%".$catids."%'";
		$edCat = $wpdb->get_results($SQLecat);
		$id=$edCat[0]->id;
		if(isset($_POST['Update'])){
            $cat_name=$_POST['catname'];
            $catdescription=$_POST['catdescription'];
            echo $primevalue=$_POST['primevalue'];
           echo  $primecurrency=$_POST['primecurrency'];
				$SQLup = "UPDATE ".$tablename." SET category_name='".$cat_name."',description='".$catdescription."',
				prime_value ='".$primevalue."',prime_currency ='".$primecurrency."',modify='".$current_date."' WHERE id='".$id."'";
				$c=$wpdb->query($SQLup);
				if($c){
			$_SESSION['id']="success";
				$_SESSION['SuccessMsg']="Record Updated Successfully";
				wp_redirect($adminurl."admin.php?page=sectors");	
				}else{echo 'ko';}
		}
}else if($_GET['action']=="deletecat"){
$SQLD = "DELETE FROM $tablename WHERE id =$catids";
$Del=$wpdb->query($SQLD);
if($Del){
    $_SESSION['id']="success";
$_SESSION['SuccessMsg']="Record Deleted Successfully";
wp_redirect($adminurl."admin.php?page=sectors");	
	exit; 
}else{
    $_SESSION['id']="error";
$_SESSION['SuccessMsg']="Record Deleted Error";
}
}else {
$aurl=$adminurl."admin.php?page=sectors&action=subsector";
$addurl='<a class="page-title-action" id="addnewurl" href="'.$aurl.'">Sub Sectors</a>';
if(isset($_POST['Submit'])){
	$cat_name=$_POST['catname'];
	$catdescription=$_POST['catdescription'];
	$primevalue=$_POST['primevalue'];
	$primecurrency=$_POST['primecurrency'];
		if(empty($cat_name)){
		$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Enter Sector Name.........";		
		}
		else
		{
		global $wpdb;
	$SQL = "SELECT * FROM $tablename WHERE category_name  LIKE '%".$cat_name."%'";
	$rsSubject = $wpdb->get_results($SQL);
	if(empty($rsSubject)){	
		$data=array('category_name' => $cat_name, 'description' => $catdescription,'prime_value' => $primevalue, 'prime_currency' => $primecurrency,
		'status' => 'Active','created'=>$current_date);
		$insert=$wpdb->insert( $tablename, $data);
		$_SESSION['SuccessMsg']="Sector added Successfully";
	$_SESSION['id']="success";
		wp_redirect($adminurl."admin.php?page=sectors");	
	exit;
		}else{
	$_SESSION['id']="error";
		$_SESSION['SuccessMsg']="Sector already exists....";
		wp_redirect($adminurl."admin.php?page=sectors");	
	exit;
		}
	}
}
$title="Add New Sector";
$buttontext="Submit";
}
?>
<script type="text/javascript">
jQuery(document).ready(function(){
    $("#<?php echo $_SESSION['id'];?>").show(1).delay(6000).hide('slow');
	});
</script>
<div id="primary" class="content-area">
<div id="wrapper">
<div id="col-container" class="wp-clearfix">
<div id="col-left">
<div class="form-wrap wrap">
<h2><?php echo $title?$title:"";?> <?php echo $addurl; ?></h2>
<?php if(isset($_SESSION['SuccessMsg'])){?> 
<div id="<?php echo $_SESSION['id'];?>" class="success-msg"><?php echo $_SESSION['SuccessMsg'];unset( $_SESSION['SuccessMsg']);?></div>
<?php }?>
<form id="addcat" method="post" action="" class="validate">
	<div class="form-field form-required term-name-wrap">
	<label for="catname">Name</label>
	<input name="catname" id="catname" value="<?php echo $edCat[0]->category_name?$edCat[0]->category_name:''; ?>" size="40" aria-required="true" type="text">
	</div>
	<div class="form-field term-description-wrap">
	<label for="cat-description">Description</label>
	<textarea name="catdescription" id="catdescription" rows="5" cols="40"><?php echo $edCat[0]->description?$edCat[0]->description:''; ?></textarea>
	</div>
    <div class="form-field form-required term-name-wrap">
    <label for="primevalue">Prime Value : </label>
    <input name="primevalue" id="primevalue" value="<?php echo $edCat[0]->prime_value?$edCat[0]->prime_value:''; ?>" size="40" aria-required="true" type="text">
    </div>	
    
    <div class="form-field form-required term-name-wrap">
    <label for="primecurrency">Currency : </label>
    
    <?php
    $curr=$edCat[0]->prime_currency?$edCat[0]->prime_currency:'';
    $plan = array('$'=>'Doller','€' => 'EUR','£'=>'Pound' ); ?>
 <select name="primecurrency" id="primecurrency">
<?php foreach ($plan as $id=> $value) { ?>
  <option value="<?php echo $id;?>" <?php echo ($id==$curr) ? ' selected="selected"' : '';?>><?php echo $value;?></option>
<?php } ?>
</select>
</div>
<p class="submit"><input name="<?php echo $buttontext;?>" id="submit" class="button button-primary" value="<?php echo $buttontext;?>" type="submit"></p>
</form>
</div>
</div><!-- /col-left -->
<div id="col-right">
<div class="col-wrap">
<form id="posts-filter" method="post">
<div class="alignleft actions bulkactions">
</div>
</div>
<h2 class="1screen-reader-text">Sectors Lists</h2>
<table class="wp-list-table widefat fixed striped cats">
	<thead>
	<tr><th id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1">Select All</label><span><a href="#">P.ID</a></span></th><th scope="col" id="name" class="manage-column column-name column-primary sortable desc"><a href="#"><span>Name</span><span class="sorting-indicator"></span></a></th><th scope="col" id="description" class="manage-column column-description sortable desc"><a href="#"><span>Description</span><span class="sorting-indicator"></span></a></th><th scope="col" id="posts" class="manage-column column-posts num sortable desc"><a href="#"><span>Status</span><span class="sorting-indicator"></span></a></th>	</tr>
	</thead>

	<tbody id="the-list" data-wp-lists="list:cat">
		<?php 
		global $wpdb;
		if(count($allCategories)>0){
			foreach($allCategories as $cat){
     		$cid=$cat->id;
			$tablenamea= $wpdb->prefix . "subcategory";
  $SQLpt = "SELECT * FROM ".$tablenamea." WHERE catid  LIKE '%".$cid."%'";
	$parentsector = $wpdb->get_results($SQLpt);
//			print_r($parentsector);
			?>
			<tr id="cat-2">			
			<th scope="row" class="check-column">
			<label class="screen-reader-text" for="cb-select-2">Select a</label>
			<?php echo $cid;?>
						</th>			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo $cat->category_name;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>/admin.php?page=sectors&action=editcat&cat_ID=<?php echo $cid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> | </span><span class="delete"><a role="button" href="<?php echo $adminurl;?>/admin.php?page=sectors&action=deletecat&cat_ID=<?php echo $cid; ?>" class="delete-cat aria-button-if-js" aria-label="Delete “a”">Delete</a> | </span></div>
			</td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo $cat->description;?></span></td>
			<td class="posts column-posts" data-colname="Count"><a href="#"><?php echo $cat->status;?></a></td>
			</tr>
			<?php 
				if(count($parentsector)>0){ 
				foreach($parentsector as $pc){
					$pcid=$pc->id;
				?>
			<tr id="cat-2">			
			<th scope="row" class="check-column">
			<label class="screen-reader-text" for="cb-select-2">Select a</label>
						</th>			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"><?php echo "— ". $pc->category_name;?></a></strong><br>
			<div class="row-actions">
			<span class="edit">
			<a role="button" href="<?php echo $adminurl;?>admin.php?page=sectors&action=subsector&type=edit&edit_ID=<?php echo $pcid; ?>" class="editinline aria-button-if-js" aria-label="Quick edit “a” inline">Quick&nbsp;Edit</a> | </span></div>
			</td>
			<td class="description column-description" data-colname="Description">
			<span class="tscreen-reader-text"><?php echo $pc->description;?></span></td>
			<td class="posts column-posts" data-colname="Count"><a href="#"><?php echo $pc->status;?></a></td>
			</tr>
				<?php }}?>
			<?php }
			}else{
			?>
			<tr id="cat-2">			
			<th scope="row" class="check-column">
			</th>			
			<td class="name column-name has-row-actions column-primary" data-colname="Name">
			<strong><a class="row-title" href="#" aria-label="“a” (Edit)"></a></strong><br>
			</td>
			<td class="description column-description" data-colname="Description">
			<span class="ascreen-reader-text">No Record found!</span></td>
			<td class="posts column-posts" data-colname="Count">
			<a href="#"></a></td>
			</tr>	
			<?php } ?>			
			</tbody>
			<tfoot>
	<tr>
		<th id="cb"  class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-2">Select All</label><span><a href="#">P.ID</a></span></th><th scope="col" class="manage-column column-name column-primary sortable desc"><a href="#"><span>Name</span><span class="sorting-indicator"></span></a></th><th scope="col" class="manage-column column-description sortable desc"><a href="#"><span>Description</span><span class="sorting-indicator"></span></a></th><th scope="col" class="manage-column column-posts num sortable desc"><a href="#"><span>Count</span><span class="sorting-indicator"></span></a></th>	</tr>
	</tfoot>
	<section id="pagination">
	<?php echo paginate_links( array(
        'base' => add_query_arg( 'cpage', '%#%' ),
        'format' => '',
        'prev_text' => __('&laquo;'),
        'next_text' => __('&raquo;'),
        'total' => ceil($total/$items_per_page),
        'current' => $page
    ));?>
	</section>
</table>
</form>
</div>
</div><!-- /col-right -->
</div>
</div>
</div>
