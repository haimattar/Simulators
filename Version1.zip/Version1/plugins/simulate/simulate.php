<?php
ob_start();
/*
Plugin Name: ECE Projects
Description: This is Energy Saving Certificates Simulator Projects based plugin.
Author: Rakesh Kumar
Version: 1.0
*/

/**********Hooks Start Here*************/

register_activation_hook( __FILE__, 'install_db' );
/**********Hooks End Here*************/
add_action('admin_menu', 'admin_actions');
// admin menu page function
function admin_actions() {
//$admin_menus=add_menu_page("Simulate Projects", "Simulate Projects", 'manage_options', "simulate_projects", "sp_admin");
$simulateposts=add_menu_page('All Scenarios', "All Scenarios", 'manage_options', "designation", "sp_post");
//$itg_admin_menu =add_submenu_page( 'designation', 'Project Type', 'Project Type','manage_options', "project_type",'projecttype');
$admin_sector =add_submenu_page( 'designation', 'secteur', 'secteur','manage_options', "sectors",'addnewcategories');
$admin_zone =add_submenu_page( 'designation', 'Zone', 'Zone','manage_options', "zone",'zone');
$admin_settings =add_submenu_page( 'designation', 'Paramètres', 'Paramètres','manage_options', "settings",'mypluginsettings');
//add_action('admin_print_styles-' . $admin_menus, 'wptuts_scripts_load_cdn');
//add_action('admin_print_styles-' . $itg_admin_menu, 'wptuts_scripts_load_cdn');
add_action('admin_print_styles-' . $admin_sector, 'wptuts_scripts_load_cdn');
add_action('admin_print_styles-' . $admin_zone, 'wptuts_scripts_load_cdn');
add_action('admin_print_styles-' . $admin_settings, 'wptuts_scripts_load_cdn');
add_action('admin_print_styles-' . $simulateposts, 'wptuts_scripts_load_cdn');
}
function sp_post(){
if($_GET['type']=='scenarioslist' && $_GET['page']=="designation" && $_GET['action']=="scenario"){
load_template( dirname( __FILE__ ) . '/templates/scenarios.php' );
}else if($_GET['type']=='edit' && $_GET['page']=="designation"){
load_template( dirname( __FILE__ ) . '/templates/designationnew.php' );
}else if($_GET['type']=='new' && $_GET['page']=="designation"){
load_template( dirname( __FILE__ ) . '/templates/designationnew.php' );
}else{
load_template( dirname( __FILE__ ) . '/templates/designationlist.php' );
}
}

function projecttype(){
load_template( dirname( __FILE__ ) . '/templates/projecttype.php' );
}
function wptuts_scripts_load_cdn()
{
wp_register_style('custom-css', plugins_url('/css/style.css', __FILE__), array(), 'all');
wp_enqueue_style('custom-css');
wp_enqueue_script('jquery-ui', 'http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'); 
wp_register_script( 'custom-script', plugins_url( '/js/custom-script.js', __FILE__ ), array( 'jquery' ) );
wp_enqueue_script( 'custom-script' );
}

// create sectors&sub sectors function
function addnewcategories(){
if($_GET['action']=="subsector"){
load_template( dirname( __FILE__ ) . '/templates/subsectors.php' );	
}else{
load_template( dirname( __FILE__ ) . '/templates/add_sectors.php' );	
}	
}

function zone(){
load_template( dirname( __FILE__ ) . '/templates/zones.php' );	
}
function mypluginsettings(){ ?>
<div class="wrap">
<?php    echo "<h2>" . __( 'Simulate Settings', 'simulate' ) . "</h2>"; ?>
<form name="oscimp_form" method="post" action="">
<input type="hidden" name="oscimp_hidden" value="Y">
<?php    echo "<h4>" . __( 'Database Settings', 'simulate' ) . "</h4>";
$option= get_option('plugindeactivate');
if($option=="Yes"){
$op='checked';
$opv='No';
}else{
$op='';
$opv='Yes';
}
?>
<p><input type="checkbox" <?php echo $op; ?> name="plugindeactivate" value="<?php echo $opv; ?>" size="20"><?php _e("Are You want to delete database after deactivate plugin"); ?></p>
<p class="submit">
<input type="submit" name="Submit" value="<?php _e('Update Options', 'simulate' ) ?>" />
</p>
    </form>
</div>
	<?php 
    if($_POST['oscimp_hidden'] == 'Y') {
        $plugindeactivate = $_POST['plugindeactivate'];
        update_option('plugindeactivate', $plugindeactivate);
	?>
        <div class="updated"><p><strong><?php _e('Options saved.' ); ?></strong></p></div>
	<?php }
}

// create plugin database tables function
function install_db() {
							global $wpdb;
							$charset_collate = $wpdb->get_charset_collate();
							$table_name1 = $wpdb->prefix . "categories";
							$table_name2 = $wpdb->prefix . "subcategory";
							$table_name3 = $wpdb->prefix . "epc";
							$table_name4 = $wpdb->prefix . "subcpe";
							$table_name5 = $wpdb->prefix . "ewc_selling_price";
							$table_name6 = $wpdb->prefix . "zone";
							$table_name7 = $wpdb->prefix . "project_type";
							$table_name8 = $wpdb->prefix . "project_subtype";
							$table_name9 = $wpdb->prefix . "designations";
							$table_name10 = $wpdb->prefix . "designationsmeta";
							$table_name11 = $wpdb->prefix . "projects";
							
											
							$sql1 = "CREATE TABLE $table_name1 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`category_name` VARCHAR(20) NOT NULL,
							`description` VARCHAR(20) NOT NULL,
							`image` VARCHAR(20) NOT NULL,
						    `status` enum('Active','Inactive') default NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql2 = "CREATE TABLE $table_name2 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`catid` VARCHAR(20) NOT NULL,
							`category_name` VARCHAR(20) NOT NULL,
							`description` VARCHAR(20) NOT NULL,
							`image` VARCHAR(20) NOT NULL,
							`status` enum('Active','Inactive') default NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql3 = "CREATE TABLE $table_name3 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`project_id` bigint(20) NOT NULL,
							`status` VARCHAR(20) NOT NULL,
							`duration` VARCHAR(20) NOT NULL,
							`goal` VARCHAR(20) NOT NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql4 = "CREATE TABLE $table_name4 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`cpeid` VARCHAR(20) NOT NULL,
							`duration` VARCHAR(20) NOT NULL,
							`energysaving` VARCHAR(20) NOT NULL,
							`status` enum('Active','Inactive') default NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql5 = "CREATE TABLE $table_name5 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`price` VARCHAR(20) NOT NULL,
							`unit` VARCHAR(20) NOT NULL,
							`status` enum('Active','Inactive') default NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql6 = "CREATE TABLE $table_name6 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`dcode` bigint(20) NOT NULL, 
							`department` VARCHAR(20) NOT NULL,
							`zone` VARCHAR(20) NOT NULL,
							`description` VARCHAR(20) NOT NULL,
							`status` enum('Active','Inactive') default NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql7= "CREATE TABLE $table_name7 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`name` varchar(100)  NOT NULL,
							`description` varchar(200) NOT NULL,
							`status` enum('Active','Inactive') DEFAULT NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY (`id`)
							) $charset_collate;";
							
							$sql8= "CREATE TABLE $table_name8 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`parent_pt_id` bigint(20) NOT NULL,
							`title` VARCHAR(20) NOT NULL,
							`status` enum('Active','Inactive') default NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							
							$sql9= "CREATE TABLE $table_name9 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`author` bigint(20) NOT NULL,
							`des_name` VARCHAR(200) NOT NULL,
							`description` VARCHAR(200) NOT NULL,
                            `catid` VARCHAR(20) NOT NULL,
							`subcatid` VARCHAR(20) NOT NULL,
							`number` VARCHAR(200) NOT NULL,
							`conditions` VARCHAR(200) NOT NULL,
							`cpe` VARCHAR(200) NOT NULL,
							`comments` VARCHAR(200) NOT NULL,
							`status` enum('Active','Inactive') default NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql10= "CREATE TABLE $table_name10 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`desgid` VARCHAR(20) NOT NULL,
							`meta_key` VARCHAR(20) NOT NULL,
							`meta_value` VARCHAR(20) NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
							$sql11= "CREATE TABLE $table_name11 (
							`id` int(11) NOT NULL AUTO_INCREMENT,
							`name` VARCHAR(20) NOT NULL,
							`description` VARCHAR(20) NOT NULL,
							`pt_id` bigint(20) NOT NULL,
							`subpt_id` bigint(20) NOT NULL,
                            `zone_id` bigint(20) NOT NULL,
                            `sectors_id` bigint(20) NOT NULL,
                            `epc_status` VARCHAR(20) NOT NULL,
                            `sellingprice_id` bigint(20) NOT NULL,
							`created` datetime NOT NULL,
							`modify` datetime NOT NULL,
							PRIMARY KEY  (id)
							) $charset_collate;";
							
												
							$wpdb->query($sql1);
							$wpdb->query($sql2);
							$wpdb->query($sql3);
							$wpdb->query($sql4);
							$wpdb->query($sql5);
							$wpdb->query($sql6);
							$wpdb->query($sql7);
							$wpdb->query($sql8);
							$wpdb->query($sql9);
							$wpdb->query($sql10);
							$wpdb->query($sql11);
    				  }
					  
					  
register_deactivation_hook(__FILE__, 'on_deactivation');
function on_deactivation()
{
global $wpdb;
$option= get_option('plugindeactivate');
if($option=="Yes"){
		$table_name1 = $wpdb->prefix . "categories";
		$table_name2 = $wpdb->prefix . "subcategory";
		$table_name3 = $wpdb->prefix . "cpe";
		$table_name4 = $wpdb->prefix . "subcpe";
		$table_name5 = $wpdb->prefix . "ewc_selling_price";
		$table_name6 = $wpdb->prefix . "zone";
		$table_name7 = $wpdb->prefix . "project_type";
		$table_name8 = $wpdb->prefix . "project_subtype";
		$table_name9 = $wpdb->prefix . "posts";
		$table_name10 = $wpdb->prefix . "postmeta";
		$table_name11 = $wpdb->prefix . "project";
$sql1 = "DROP TABLE IF EXISTS $table_name1;";
$sql2 = "DROP TABLE IF EXISTS $table_name2;";
$sql3 = "DROP TABLE IF EXISTS $table_name3;";
$sql4 = "DROP TABLE IF EXISTS $table_name4;";
$sql5 = "DROP TABLE IF EXISTS $table_name5;";
$sql6 = "DROP TABLE IF EXISTS $table_name6;";
$sql7 = "DROP TABLE IF EXISTS $table_name7;";
$sql8 = "DROP TABLE IF EXISTS $table_name8;";
$sql9 = "DROP TABLE IF EXISTS $table_name9;";
$sql10 = "DROP TABLE IF EXISTS $table_name10;";
$sql11 = "DROP TABLE IF EXISTS $table_name11;";
$wpdb->query($sql1);
$wpdb->query($sql2);
$wpdb->query($sql3);
$wpdb->query($sql4);
$wpdb->query($sql5);
$wpdb->query($sql6);
$wpdb->query($sql7);
$wpdb->query($sql8);
$wpdb->query($sql9);
$wpdb->query($sql10);
$wpdb->query($sql11);
}
}

//menu duntion `sp_admin`
function sp_admin()
{
//echo $default_path = plugin_dir_path( __FILE__ ) . 'templates/';
// load_template( dirname( __FILE__ ) . '/templates/projects.php' );
}

?>
