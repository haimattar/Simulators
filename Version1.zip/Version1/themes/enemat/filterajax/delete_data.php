<?php
   // echo "<pre>";
   // print_r($_POST);exit;
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$project_meta_id = $_POST['project_meta_id'];
if(!empty($project_meta_id)){
	$SQLDELETEMETACONDS = "DELETE FROM wp_project_meta_conditions WHERE project_meta_id='".$project_meta_id."'";
	$wpdb->query($SQLDELETEMETACONDS);

	$SQLDELETEMETA = "DELETE FROM wp_project_meta_wording WHERE project_meta_id='".$project_meta_id."'";
	$wpdb->query($SQLDELETEMETA);

	$SQLDELETE = "DELETE FROM wp_project_meta WHERE id='".$project_meta_id."'";
	$wpdb->query($SQLDELETE);
	
	$SQLSUBCONDSDELETE = "DELETE FROM wp_project_meta_subconditions  WHERE project_meta_id='".$project_meta_id."'";
	$wpdb->query($SQLSUBCONDSDELETE);	
}