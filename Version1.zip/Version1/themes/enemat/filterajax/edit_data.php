<?php
   //  echo "<pre>";
   // print_r($_POST);exit;
@session_start();
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
$siteurl = get_option("siteurl");
$catgsid = $_POST['catgsid'];
$project_meta_id = $_POST['project_meta_id'];
$subsector_id = $_POST['subsecid'];
$designation_id = $_POST['desgid'];
$project_id = $_POST['projid'];

$redirect_viewdetails= get_page_by_path("view-details");
$redirectviewdetailslink = get_permalink($redirect_viewdetails->ID);

$sqlcats ="SELECT prime_value,prime_currency
		   FROM `wp_categories`
		   WHERE id ='".$catgsid."'
		   AND status='Active'";
$rsCats=$wpdb->get_results($sqlcats);
$prime_value = $rsCats[0]->prime_value;
$prime_currency = $rsCats[0]->prime_currency;

$sqlSUBCat="SELECT * FROM `wp_subcategory` WHERE status='Active' AND  catid ='".$catgsid."' ";
$SUBCat=$wpdb->get_results($sqlSUBCat);

$SQLDesc="SELECT * FROM wp_designations WHERE subcatid ='".$subsector_id."'";
$resultDesc = $wpdb->get_results($SQLDesc);

$SQLPROJECTMETA = "SELECT * FROM wp_project_meta WHERE id='".$project_meta_id."' ORDER BY id DESC LIMIT 1";
$rsProdmeta = $wpdb->get_results($SQLPROJECTMETA);

function rspecial($string,$rp = '') {
$string = str_replace(' ', ',', $string);
return preg_replace('/[^A-Za-z0-9\-]/', $rp, $string);
}

function get_wordings($project_meta_id,$designation_id,$catgsid){
	global $wpdb;
	$SQL = "SELECT * FROM wp_project_meta_wording WHERE project_meta_id ='".$project_meta_id."' ORDER BY id ASC";
	$rsMeta = $wpdb->get_results($SQL);
	//print_r($rsMeta);
	$arraywpmeta = array();
	$flags = true;
	if(count($rsMeta)>0){
		for($x=0;$x<count($rsMeta);$x++){
			if($rsMeta[$x]->wording_meta_id!=0){
				$flags = true;
				$arraywpmeta[$x] = $rsMeta[$x]->wording_meta_id."-".$rsMeta[$x]->value;
			}else{
				$flags = false;
				$arraywpmeta[$x] = $rsMeta[$x]->value;
			}
		}
	}
	if(count($rsMeta)>1){
		$SQwording="SELECT * FROM wp_wording WHERE desg_id ='".$designation_id."' ORDER BY `desg_id` ASC,otherparts ASC";
	}else if(count($rsMeta)==1){
		$SQwording="SELECT * FROM wp_wording WHERE desg_id ='".$designation_id."' ORDER BY `id` ASC,otherparts ASC";
	}
$resultWord = $wpdb->get_results($SQwording);
$meta = "";
$meta1 = "";
$meta2 = "";
if(count($resultWord)>0){
	$wpmetaid = "";
	$wpmetavalues = "";
	$meta .= '<table width="100%">';
	for($y=0;$y<count($resultWord);$y++){
		if($resultWord[$y]->otherparts=="No"){
		$metaselectionsdata = $arraywpmeta[$y];
		if(strstr($metaselectionsdata,"-")){
			$metaselections = explode("-",$metaselectionsdata);
			$wpmetaid = $metaselections[0];
		}else{
			$wpmetavalues = $metaselectionsdata;
		}
		$wmts=$resultWord[$y]->id;
		$SQwordMeta="SELECT * FROM wp_wording_meta WHERE word_id ='".$wmts."' ORDER BY `id` ASC,is_cond ASC";
		$WMeta = $wpdb->get_results($SQwordMeta);
		$meta .= '<tr><td style="width:97px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
		'.stripslashes($resultWord[$y]->title).'
		</font></font>
		<input type="text" name="wordingid[]" value="'.$wmts.'" style="display:none;"/>
		</td>';
		$meta .= '<td class="param-input tac">';
		 if(!empty($WMeta)){
			$arraymetaconsd = array();
			$meta .= '<select name="wmetavalue[]" onchange=\'return  get_conditions(this.value,"'.$catgsid.'","'.$siteurl.'/wp-content/themes/enemat/filterajax/conditions_data.php");\'>';
			foreach($WMeta as $wmr){
				$SQLPRODMETACONDS = "SELECT * FROM wp_project_meta_conditions WHERE project_meta_id='".$project_meta_id."' AND wording_meta_id='".$wmr->id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				
				if(count($rsProdMetaConditions)>0){					
					$arraymetaconsd[] = $wmr->id;
					$values = $wmr->id;
				 				
				$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$values."' ORDER BY is_cond ASC";
				$rsConditions = $wpdb->get_results($SQLCOND);
				if(count($rsConditions)>0){
				$selected = "";
			$array_conds = array();
			$condisids = array();
			$condstextvalues = "";
			$selectedSubconds = "";
			 for($x=0;$x<count($rsConditions);$x++){
				if($rsConditions[$x]->is_cond=="Yes"){ 
				$cond_id = $rsConditions[$x]->id;
				$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
				$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
				$condionsvals = '<select name="condition_valuesid[]" id="condition_valuesid" onchange=\'return  get_sub_conditions(this.value,"'.$catgsid.'","'.$siteurl.'/wp-content/themes/enemat/filterajax/subconditions_data.php");\'>';
				$SQLPRODMETACONDS = "SELECT * FROM wp_project_meta_conditions WHERE project_meta_id='".$project_meta_id."' AND wording_meta_id='".$values."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				for($jj=0;$jj<count($rsProdMetaConditions);$jj++){
						$condisids[] = $rsProdMetaConditions[$jj]->conditions_valueids."-".$rsProdMetaConditions[$jj]->consddacavle;
						
						if(empty($rsProdMetaConditions[$jj]->conditions_valueids)){
							$condstextvalues = $rsProdMetaConditions[$jj]->consddacavle;
						}
				}
				for($aa=0;$aa<count($rsCondValues);$aa++){
					if(in_array($rsCondValues[$aa]->id."-".$rsCondValues[$aa]->mc_value,$condisids)){
							$selected = 'selected="selected"';						 
							$SQLSUBCONDS = "SELECT * FROM wp_cond_meta_cond WHERE cmcond_id='".$rsCondValues[$aa]->id."'";
							$rsSubconds = $wpdb->get_results($SQLSUBCONDS);
							if(count($rsSubconds)>0){
								$SQLSUBCONDS = "SELECT * FROM wp_project_meta_subconditions WHERE project_meta_id='".$project_meta_id."'";	
								$rsSubConds = $wpdb->get_results($SQLSUBCONDS);
								$sub1 = $rsSubConds[0]->subconditions_valueids;
								$sub2 = $rsSubConds[0]->subconsddacavle;
								$sub3 = $rsSubConds[0]->condition_id;
								$sub4 = $rsSubConds[0]->subparents_id;
								$subarrays = $sub1."-".$sub2."-".$sub3."-".$sub4;
								 for($xx=0;$xx<count($rsSubconds);$xx++){						
									$SQLCONDMETAVALUESVALUES = "SELECT * FROM wp_cond_meta_cond_values WHERE cmcond_id='".$rsSubconds[$xx]->id."'";
									$rsSubcondMetas = $wpdb->get_results($SQLCONDMETAVALUESVALUES);
									if(count($rsSubcondMetas)>0){
										$subcondionsvals = '<select name="subcondition_valuesid" id="subcondition_valuesid">';
										for($yy=0;$yy<count($rsSubcondMetas);$yy++){
											if($rsSubcondMetas[$yy]->id."-".$rsSubcondMetas[$yy]->cmcv_value."-".$rsSubcondMetas[$yy]->cond_id."-".$rsSubcondMetas[$yy]->subconds_id==$subarrays){
												$selectedSubconds = 'selected="selected"';
											}else{
												$selectedSubconds = "";
											}
											$subcondionsvals .= '<option value="'.$rsSubcondMetas[$yy]->id."-".$rsSubcondMetas[$yy]->cmcv_value."-".$rsSubcondMetas[$yy]->cond_id."-".$rsSubcondMetas[$yy]->subconds_id.'" '.$selectedSubconds.'>'.$rsSubcondMetas[$yy]->cmcv_title.'</option>';
										}
										$subcondionsvals .= '</select>';	
									}
									 $meta2 .= '<tr id="trcpconmetas'.$catgsid.'" class="trcpnditions'.$catgsid.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsSubconds[$xx]->cmc_title.'</font></font>
									 <input type="hidden" name="subcondition_id" id="subcondition_id'.$catgsid.'" value="'.$rsSubconds[$xx]->id.'" style="display:none;"/>
									 </td><td>'.$subcondionsvals.'</td></tr>';
								}
							}
						 
						
						
					}else{
						$selected = '';
					}
					//print_r($array_conds);
					$condionsvals .= '<option value="'.$rsCondValues[$aa]->id."-".$rsCondValues[$aa]->mc_value.'" '.$selected.'>'.stripslashes($rsCondValues[$aa]->mc_title).'</option>';
				 }
				$condionsvals .= '</select>
				<input type="text" name="condition_id[]" id="condition_id'.$catgsid.'" value="'.$rsConditions[$x]->id.'" style="display:none;"/>';				
			  
             $meta1 .= '<tr class="trcpnditions'.$catgsid.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$condionsvals.'</td></tr>';
				if($x==0){
					$meta1 .= '<tr id="trconds0-'.$catids.'"style="display:none;"><td colspan="2"></td></tr>';
						$meta1 .= $meta2; 
				}
			 }
			 if($rsConditions[$x]->is_cond=="No"){
				if($rsConditions[$x]->otherparts=="No"){
				$cond_id = $rsConditions[$x]->id;
				$SQLPRODMETACONDS = "SELECT wp_project_meta_conditions.condition_id,wp_project_meta_conditions.consddacavle,wp_meta_conditions_values.mc_title 
									 FROM wp_project_meta_conditions
									 LEFT JOIN wp_meta_conditions_values ON
									 wp_project_meta_conditions.conditions_valueids=wp_meta_conditions_values.id
									WHERE wp_project_meta_conditions.project_meta_id='".$project_meta_id."'
									AND wp_project_meta_conditions.wording_meta_id='".$values."'
									AND wp_project_meta_conditions.condition_id='".$cond_id."'";
				$rsProdMetaConditions = $wpdb->get_results($SQLPRODMETACONDS);
				 $condsvaltext = '<input type="text" name="condition_text" id="condition_text" value="'.$rsProdMetaConditions[0]->consddacavle.'"/>';
				 $meta1 .= '<tr class="trcpnditions'.$catgsid.'"><td style="width:85;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">'.$rsConditions[$x]->mc_title.'</font></font></td><td>'.$condsvaltext.'</td></tr>';
				 $meta1 .= '<input type="hidden" name="condition_textid" id="condition_textid'.$catgsid.'" value="'.$rsConditions[$x]->id.'"/>';	
				}
				if($rsConditions[$x]->otherparts=="Yes"){
				 $meta1 .= '<tr class="trcpnditions'.$catgsid.'" style="display:none;"><td><input type="hidden" name="partssub" id="partssub'.$catgsid.'" value="'.$rsConditions[$x]->mc_value.'"/>
				 <input type="hidden" name="partssubopt" id="partssubopt'.$catgsid.'" value="'.$rsConditions[$x]->optypes.'"/></td></tr>';
				 }
			 }
			}
			}	
			 
				}				
				if($wmr->id==$wpmetaid){
					$selected = 'selected="selected"';
				}else{
					$selected = "";
				}
				 $wmrval=rspecial($wmr->value,'.');
				$meta .=  '<option value="'.$wmr->id.'-'.$wmrval.'-'.$wmr->is_cond.'" '.$selected.'>'.stripslashes($wmr->title).'</option>';
			 }
			$meta .= '</select>';
		}else{
			$meta .= '<input type="text" name="wmetavalue[]" value="'.str_replace(".",",",number_format($wpmetavalues,0," "," ")).'"  min="0" step="1">';
		}
		 
		$meta .= '</td></tr>';
		}else if($resultWord[$y]->otherparts=="Yes"){
			 $meta .= '<input type="text" name="wpartssub[]" style="display:none;" id="wpartssub'.$catgsid.'" value="'.$resultWord[$y]->word_value.'"/>
				 <input type="hidden" name="wpartssubopt" id="wpartssubopt'.$catgsid.'" value="'.$resultWord[$y]->optypes.'"/>';
		}
	}
	 $meta .=$meta1;
		$meta .= '<tr id="trconds'.$catgsid.'" style="display:none;"><td colspan="2"></td></tr></table>';
 }
	return $meta;
}
?><span onclick="return close1();"> &#215; </span>
<form name="aa<?php echo $catgsid."-".$project_meta_id;?>" id="aa<?php echo $catgsid."-".$project_meta_id;?>">
<table class="table_a smpl_tbl sa_table">
<thead>
<tr>
<th rowspan="2" width="115"><div class="th_wrapp">
<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sous-secteur</font></font></div></th>
<th rowspan="2" width="230px">
<div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Désignation</font></font></div></th>
<th colspan="2"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Paramètres</font></font></div></th>
<th rowspan="2" width="100"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Principales conditions d'application</font></font></div></th>
<th rowspan="2" width="50"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">KWh </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">cumac</font></font></div></th>
<th rowspan="2">Prime indicative</th>
<th class="hide-print" style="text-align:center;" rowspan="2" width="75"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></div></th></tr><tr><th width="85"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Libellé</font></font></div></th>
<th style="text-align:center;" width="106"><div class="th_wrapp"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Valeur</font></font></div></th>
</tr></thead>
<tbody>
 
 <tr id="treditrow<?php echo $catgsid."-".$project_meta_id;?>" class="new-op parent  hide-print sa_tab" data-param-count="0" data-child-class="new-op-AGRI">
<td class="multi-row sousSecteur" rowspan="1">
<select name="sousSecteur" onchange="subcatchangeedit(this.value,'<?php echo $catgsid.'-'.$project_meta_id;?>','<?php echo get_template_directory_uri().'/filterajax/frontdataedit.php';?>','designations','<?php echo $project_meta_id;?>')" id="sousSecteur<?php echo $catgsid.'-'.$project_meta_id;?>"  style="max-width: 110px;">
<option selected=""></option>
<?php foreach($SUBCat as $subc){ ?>
<option value="<?php echo $subc->id; ?>" <?php if($subc->id==$subsector_id){?>selected="selected"<?php }?>><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $subc->category_name; ?></font></font></option>
<?php } ?>
</select><br></td>
<td class="multi-row fiche responsecat"  rowspan="1">
<div id="fiche-input-holder<?php echo $catgsid.'-'.$project_meta_id;?>">
<select name="fiche" style="max-width: 120px;" id="fiche<?php echo $catgsid.'-'.$project_meta_id;?>" onchange="getdestinationsedit(this.value,'<?php echo $catgsid;?>','<?php echo $catgsid.'-'.$project_meta_id;?>')">
<?php for($jj=0;$jj<count($resultDesc);$jj++){?>
<option value="<?php echo $resultDesc[$jj]->id;?>" <?php if($resultDesc[$jj]->id==$designation_id){?>selected="selected"<?php }?>><?php echo stripslashes($resultDesc[$jj]->des_name);?></option>
<?php }?>
</select>
<br>
<span  id="numbedit<?php echo $catgsid?>" class="numero-link-holder">
<a href="<?php echo $rsProdmeta[0]->number_link;?>" target="_blank"><?php echo $rsProdmeta[0]->number_title;?></a>
</span>

</div>
<span class="fiche-nom"></span><input type="hidden" name="fiche" disabled=""></td>
<td style="padding: 0px ! important; vertical-align: top;" colspan="2"><div id="catgscatgsid<?php echo $catgsid.'-'.$project_meta_id;?>"><?php 
	$wordings = get_wordings($project_meta_id,$designation_id,$catgsid);
	echo $wordings;?></div></td>

<td class="multi-row commentaire" rowspan="1"><div id="commt<?php echo $catgsid.'-'.$project_meta_id;?>"><?php echo stripslashes($rsProdmeta[0]->conditions);?></div></td>
<td class="multi-row cumac"><?php echo str_replace(".",",",number_format($rsProdmeta[0]->mwh_cumac,0," "," "));?></td>
<td class="" rowspan="1"><?php echo number_format($rsProdmeta[0]->prime_value_cal,0," "," ")." ".$rsProdmeta[0]->primecurr;?></td>
<td class="content_actions multi-row hide-print" style="text-align:center;" rowspan="1">
<span class="updt_data" onclick="return update_form('<?php echo $rsProdmeta[0]->id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/update_data.php','<?php echo $catgsid.'-'.$project_meta_id;?>');">Nouveau scénario</span>
<span class="updt_data" onclick="return delete_records('<?php echo $rsProdmeta[0]->id;?>','<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/delete_data.php','<?php echo $catgsid;?>');">Effacer</span>
<a href="<?php echo $redirectviewdetailslink;?>?id=<?php echo $rsProdmeta[0]->id;?>"><span class="updt_data">Demander ma Prime<br/><?php echo number_format($rsProdmeta[0]->prime_value_cal,0," "," ")." ".$rsProdmeta[0]->primecurr;?></span></a>
<input type="hidden" name="catgsid" id="catgsid" value="<?php echo $catgsid;?>">
<input type="hidden" name="project_id" id="project_id" value="<?php echo $project_id;?>">
<input type="hidden" name="project_meta_id" id="project_meta_id" value="<?php echo $project_meta_id;?>">
<input type="hidden" name="number_title" id="number_title" value="<?php echo $rsProdmeta[0]->number_title;?>">
<input type="hidden" name="number_link" id="number_link" value="<?php echo $rsProdmeta[0]->number_link;?>">
<input type="hidden" name="conditions" id="conditions" value="<?php echo $rsProdmeta[0]->conditions;?>">
<input type="hidden" name="prime_value" id="prime_value" value="<?php echo $prime_value;?>"/>
<input type="hidden" name="primecurr" id="primecurr" value="<?php echo $prime_currency;?>"/>
<input type="hidden" name="calcul"><input type="hidden" name="id" value="0">
<div class="hidden-inputs param-input"><input type="hidden" name="vecteur1" value="20">
<input type="hidden" name="calcul" value="81"></div>
</td>
</tr>
</tbody></table>
</form>
