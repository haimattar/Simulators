<?php
  
@session_start();   
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
global $wpdb;
if($_POST['strs']=="submitfinalreport"){
$current_date = date("Y-m-d H:i:s");
global $wpdb;
$userid=$_POST['userid'];
$useremail=$_POST['useremail'];
$desid=$_POST['scenarioids'];
$SQLDESIGNATION = "SELECT * FROM wp_designations WHERE id='".$desid."'";
$rsDesignation = $wpdb->get_results($SQLDESIGNATION); 

$companyname=get_the_author_meta( 'company_name', $userid );
$salesname=   get_the_author_meta('salesname',$userid);
$table = $wpdb->prefix . "clientinfo";
$strs=$wpdb->insert( 
            $table, 
            array( 
                    'userid' => $_POST['userid'], 
                    'scenario_id' =>$_POST['scenarioids'],
                    'pmetaid' =>'0',
                    'Installeture' => $companyname, 
                    'fname' => $_POST['cname'],
                    'name' => $_POST['cfullname'],
                    'address' => $_POST['caddress'],
                    'post_code' => $_POST['postalcode'], 
                    'ville' => $_POST['ville'],
                    'mobile' => $_POST['ctel'],
                    'email' => $_POST['cemail'],
                    'fiche'=>$_POST['fiche'],
                    'fichelink'=>$_POST['fichelink'],
                    'scenario_title'=>esc_sql($_POST['scenariotitle']),
                    'mwhcumac'=>$_POST['mwhcumac'],
                    'sendmaildate'=>$current_date,
                    'signdate'=>$current_date,       
                    'commercial' => $salesname,
                )
        );
     if($strs){
  $from=$_POST['useremail'];
  $to = $_POST['cemail'];
  $subject = 'Scenario Details';
  $message = '
        <html>
            <head>
                <title>Scenatio Details</title>
            </head>
            <body>
<div id="scenariosummary">
<ul style="list-style:none;display:inline-block;width:80%">
<li style="float:left;width:30%;"><img style="width:100%;"  src="'.get_site_url().'/wp-content/uploads/2018/04/logo.png"></li>
<li style="float:right;width:30%;"><img style="width:100%;" src="'.get_site_url().'/wp-content/uploads/2018/01/logo.png"></li>
<div style="clear:both;"></div>
</ul>
<p>Le dispositif national des certificats d’économies d’énergie(CEE) mis en place par le Ministère en charge de l’énergie impose à l’ensemble des 
fournisseurs d’énergie (électricité, gaz, fioul domestique, chaleur ou froid, carburants automobiles),
de réaliser des économies et de promouvoir les comportements vertueux auprès des consommateurs d’énergie.</p>
<h3>Dans ce cadre, la société ENEMAT (SASU) s`engage à vous apporter :</h3>
<ul>
<li>Une prime d`un montant de '.$_POST['primeval'].' €</li>
<li>Un bon d’achat pour des produits de consommation courante d’un montant …………. € ;</li>
<li>Un prêt bonifié d’un montant de ………….. € proposé par …………. au taux effectif global (TEG) de …… % (valeur de la bonification = ………….. €);</li>
<li>Un audit ou conseil personnalisé, remis sous forme écrite au bénéficiaire (valeur …………. €); </li>
<li>Un produit ou service offert : …………….  …………….d’une valeur de …………….. €;</li>
</ul>
<h3>Dans le cadre des travaux suivants (1 ligne par opération) :</h3>
<table colspan="1" style="border: 1px solid black;border-collapse: collapse; width:100%;">

<tr><td style="border: 1px solid black;border-collapse: collapse; padding:10px 20px;"><b>Nature des travaux </b></td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;"><b>Fiche CEE</b></td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;"><b>Condition a respecter</b></td></tr>
<tr><td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;">'.$_POST['scenariotitle'].'</td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;"><a href="'.$_POST['fichelink'].'" target="_blank">'.$_POST['fiche'].'</a></td>
<td style="border: 1px solid black;border-collapse: collapse;padding:10px 20px;">'.$rsDesignation[0]->conditions.'</td></tr>
</table>

<p>au bénéfice de :  » '.$_POST['cname'].'<br/>					
Tel : '.$_POST['ctel'].'<br/>
Email:'.$_POST['cemail'].'<br/>
Address: '.$_POST['caddress'].'<br/> « '.$_POST['postalcode'].' » 
« '.$_POST['ville'].' »
</p>
<hr>
<p>Pour le calcul détaillé du montant de votre prime et son mode de paiement : voir les conditions contractuelles, dans l`engagement page suivante.
<br/>
Date de cetteproposition: '.$current_date.'
<div id="footernote">
<h3>Signature :</h3>
<h4>Cordialement</h4>
<img src="'.get_site_url().'/wp-content/uploads/2018/01/logo.png">
<h4>0649888055</h4> 
</div>                
            </body>
        </html>'; 
$headers  = "Content-type: text/html; charset=utf-8 \r\n"; 
//$headers .= "From: Site <$from>\r\n"; 
$headers  .= 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
// Create email headers
$headers .= 'From: '.$from."\r\n".

    'Reply-To: '.$from."\r\n" .

    'X-Mailer: PHP/' . phpversion();

if(mail($to, $subject, $message, $headers)){
echo json_encode(array('status' => 'success'));
} else {
echo json_encode(array('status' => 'error'));
}
}else {
echo json_encode(array('status' => 'error'));
} 
}else{
$currency = $_POST['currency'];
$mwhvalue = $_POST['mwhvalue']/1000;
$userid = $_POST['userid'];
//echo $amounts = $_POST['vals']?$_POST['vals']:'100';
$amounts=$_POST['vals']/100;

$key1='prime_mwhc';
$key2='precarite';
$key3='highprecarite';
$single = true;

$prime_mwhc= get_user_meta( $userid, $key1, $single );
$precarites= get_user_meta( $userid, $key2, $single );
$highprecarites= get_user_meta( $userid, $key3, $single );

$prime=$mwhvalue*$prime_mwhc*$amounts;
$precarite=$mwhvalue*$precarites*$amounts;
$highprecarite=$mwhvalue*$highprecarites*$amounts;

$grade_prime=(1-$amounts)*$mwhvalue*$prime_mwhc;
$grade_precarite=(1-$amounts)*$mwhvalue*$precarites;
$grade_highprecarite=(1-$amounts)*$mwhvalue*$highprecarites;


$array_heads = "";
$array_heads .= '<table with="100%">';
$array_heads .= '<tbody><tr><td>&nbsp;</td><td>Pour value client</td><td>Pour value</td></tr>';
$array_heads .= '<tr><td>Prime sans precarite</td>
<td><input readonly value="'.number_format($prime,2)." ".$currency.'" name="primevalaj" id="primevalaj" ></td>
<td><input readonly value="'.number_format($grade_prime,2)." ".$currency.'" name="g_primevalaj" id="g_primevalaj" ></td></tr>
<tr><td>Prime avac precarite (avec justificatif)</td>
<td><input readonly value="'.number_format($precarite,2)." ".$currency.'" name="precariteaj" id="precariteaj" ></td>
<td><input readonly value="'.number_format($grade_precarite,2)." ".$currency.'" name="g_precariteaj" id="g_precariteaj" ></td></tr>
<tr><td>Prime grand avac precarite (avec justificatif)</td>
<td><input readonly value="'.number_format($highprecarite,2)." ".$currency.'" name="grandprecariteaj" id="grandprecariteaj" ></td>
<td><input readonly value="'.number_format($grade_highprecarite,2)." ".$currency.'" name="g_grandprecariteaj" id="g_grandprecariteaj" ></td>
</tr>';
$array_heads .= '</tbody></table>';
$arrays = array("amount1"=>number_format($prime,2)." ".$currency,"amount2"=>number_format($grade_prime,2)." ".$currency,"details"=>$array_heads);
echo json_encode($arrays);
}
?>