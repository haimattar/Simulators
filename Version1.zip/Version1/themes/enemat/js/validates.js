function subcatchange(id,sids,url,tname){
//alert (id+url+tname);
var strs="fetchsubcat";
$('#numb'+sids+'').html('');
$('#commt'+sids+'').html('');
$('#idss'+sids+'').html('');
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"catids":id,"table_name":tname},
                url: url,
                success: function(msgs){
				//alert(msgs);
				 if($.trim(msgs)!=""){
					$('#fiche-input-holder'+sids+'').html(msgs);
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}

function subcatchangeedit(id,sids,url,tname,prjmtaid){
//alert (id+url+tname);
var strs="fetchsubcat";
//$('#numb'+sids+'').html('');
$('#commt'+sids+'').html('');
$('#catgscatgsid'+sids+'').html('');
        $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"catids":id,"table_name":tname,"prjmtaid":prjmtaid},
                url: url,
                success: function(msgs){
				//alert(msgs);
				 if($.trim(msgs)!=""){
					$('#fiche-input-holder'+sids+'').html(msgs);
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
}


function getdestinations(id,sid){
//alert (sid);
var strs="fetchdestinations";
var url= document.getElementById("tabsurls").value;
    $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"destiid":id},
                url: url,
                success: function(msg){
               // alert (msg);
			   if($.trim(msg)!=""){
					var data_array = $.parseJSON(msg);				
					$('#numb'+sid+'').html(data_array['numb']);
					$('#commt'+sid+'').html(data_array['comnt']);
					$('#idss'+sid+'').html(data_array['meta']);
				}else{
					$('#numb'+sid+'').html('');
					$('#commt'+sid+'').html('');
					$('#idss'+sid+'').html('');
				}
                },
                error: function(){
                //$('#nummb').html(msg);
                }
        });
}

function getdestinationsedit(id,sidcts,prjmetaids){
  //alert (prjmetaids);
var strs="fetchdestinations";
var url="<?php echo $siteurl;?>/wp-content/themes/enemat/filterajax/frontdataeditwordings.php";
    $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"stats":strs,"destiid":id,"catids":sidcts,"prjmetaid":prjmetaids},
                url: url,
                success: function(msgs){
                //alert (msgs);
			   if($.trim(msgs)!=""){
					var data_array = $.parseJSON(msgs);	
					//alert(data_array['meta']);					
					$('#catgscatgsid'+prjmetaids+'').html(data_array['meta']);
				}else{
					$('#catgscatgsid'+prjmetaids+'').html('');
				}
                },
                error: function(){
                //$('#nummb').html(msg);
                }
        });
}


function openCity(evt, cityName,project_id,pageurls1) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
	if(document.getElementById("projectsrecds"+cityName+"")){
		$("#projectsrecds"+cityName+"").show();
	}
    evt.currentTarget.className += " active";
	document.getElementById("fiche"+cityName+"").options.length = 0;
	//========Ajax Part==============//
	$.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_id":project_id,"subsector_id":cityName},
                url: pageurls1,
                success: function(msgformdatas){
					//alert(msgformdatas);
					$("#projectsrecds"+cityName+"").before(msgformdatas);
                },
                error: function(){  
                }
        });
	//========Ajax Part==============//
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

function submit_form(pageurls,secsids){
	 frmdatas = $("#frmdata"+secsids+"").serialize();
	 if(document.getElementById("sousSecteur"+secsids+"").value==""){
		alert("Please select Subsector");
		document.getElementById("sousSecteur"+secsids+"").focus() = true;
		return false;
	}
	 if(document.getElementById("fiche"+secsids+"").value==""){
		alert("Please select Designation");
		document.getElementById("fiche"+secsids+"").focus() = true;
		return false;
	}
	/*var elements = document.getElementsByName("wmetavalue[]");
	if(elements){
		for (i = 0; i < elements.length; i++) {
			if (elements[i].tagName == "INPUT") {
				if(elements[i].value.replace(/^\s+|\s+$/g,'')==""){
					alert("Please enter this value");
					elements[i].focus() = true;
					return false;
				 }
			} 
		}
	}*/
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas,
                url: pageurls,
                success: function(msgformdatas){
					//alert(msgformdatas);
					$("#projectsrecds"+secsids+"").before(msgformdatas);
					$('#numb'+secsids+'').html('');
					$('#commt'+secsids+'').html('');
					$('#idss'+secsids+'').html('');
					$('#fiche'+secsids+'').val();
					$("#EventStartTimeMin").val();
					$('#commentaires'+secsids+'').val('');
					$('#sousSecteur'+secsids+'').prop('selectedIndex',0);
					$('#wordingid'+secsids+'').val('');
					document.getElementById("wmetavalue"+secsids+"").options.length = 0;
					document.getElementById("fiche"+secsids+"").options.length = 0;
                },
                error: function(){  
                }
        });
}

function recet_data(ids,pageurls,secsids){
	//alert(secsids);
	 frmdatas11 = $("#aa"+secsids+"").serialize();
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas11,
                url: pageurls,
                success: function(msgformdatareset){
					 //alert(msgformdatas);
				$("#treditrow"+secsids+"").replaceWith(msgformdatareset);	 
                },
                error: function(){  
                }
        });
}
function update_form(ids,pageurls,secsids){
	//alert(secsids);
	 frmdatas11 = $("#aa"+secsids+"").serialize();
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas11,
                url: pageurls,
                success: function(msgformdatasdatas){
				//alert(msgformdatasdatas);
				$("#myModal").hide(); 	
				$("#trsimuledit"+ids+"").replaceWith(msgformdatasdatas);	 
                },
                error: function(){  
                }
        });
}

function delete_records(prmids,pageurlsdels,secsids){
	//alert(secsids);
	// alert(frmdatas1);	
	if(confirm("Do you want to delete?")){
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_meta_id":prmids},
                url: pageurlsdels,
                success: function(msgdeletes){
					 //alert(msgformdatas);
				//alert("Deleted");	 
				$("#trsimuledit"+prmids+"").remove();
				$("#myModal").hide(); 	
                },
                error: function(){  
                }
        });
	}	
}

function edit_project(project_meta_id,pageurlsmeta,subsecid,desgid,projid,catgsid){
	//alert("A");
	document.getElementById('myModal').style.display= "block";
	$.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: {"project_meta_id":project_meta_id,"subsecid":subsecid,"desgid":desgid,"projid":projid,"catgsid":catgsid},
                url: pageurlsmeta,
                success: function(msgformdatasupdates){
					//alert(msgformdatas);
					$("#myModal").html(msgformdatasupdates);
			    },
                error: function(){  
                }
        });
}

function show_pop1(){
	 document.getElementById('myModal').style.display= "block";
} 
function close1(){
	document.getElementById('myModal').style.display="none";
}