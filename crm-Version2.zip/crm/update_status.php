<?php
  include('../../../wp-load.php');
 $id = $_POST['id'];
 $status = $_POST['valstatus'];
 global $wpdb;	
 $table_prefix = $wpdb->prefix;
 $SQL = "UPDATE wp_clientinfo SET status = '".esc_sql($status)."' WHERE id='".$id."'";
 $wpdb->query($SQL);
 echo "<strong>Updated</strong>";
?>