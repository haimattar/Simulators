	<?php 
	global $wpdb;
	session_start();
	//echo "<pre>";
	//print_r($_SERVER);
	 $WHERE = "";
	global $wpdb;	
	$table_prefix = $wpdb->prefix;
	include("simulator_opt.php");
	 //===========Paging=============//
	 /* $items_per_page =20;	
	  $page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
	  $offset = ( $page * $items_per_page ) - $items_per_page;
	  $SQLTOTAL = "SELECT * FROM  wp_clientinfo ORDER BY id DESC";
	  $SQLTOTAL = $wpdb->get_results($SQLTOTAL); 
	  $total = count($SQLTOTAL);*/
	  //===========Paging=============//
		$WHERE = "";
		$search_status = isset($_POST['status'])?$_POST['status']:"Classique";
		if(isset($_POST['field_name']) && !empty($_POST['field_name'])){
			$field_name = $_POST['field_name'];
			$field_value = $_POST['field_valie'];
			$WHERE .= "".$field_name." LIKE '%".esc_sql($field_value)."%'";
		}
	    $SQL = "SELECT * FROM  wp_clientinfo
			   WHERE status='".$search_status."'
			   ".$WHERE."
			   ORDER BY id DESC";
		$rs = $wpdb->get_results($SQL);
		$field_name = isset($_POST['field_name'])?$_POST['field_name']:"";
		$field_value = isset($_POST['field_value'])?$_POST['field_value']:"";
		
	  ?>
	  <style>
	  .newtbsect {
	  overflow-y: scroll;
	  width: 100%;
	}

	.newtbsect td strong {
		float: left;
		text-align: center;
		width: 147px !important;
	}
	b, strong {
		color: #0073aa;
		font-weight: 600;
	}
	.newtbsect tr:nth-child(2n+1) {
	  background: #fff none repeat scroll 0 0;
	}
	.newtbsect tr:nth-child(2n) {
	  background: #f9f9f9 none repeat scroll 0 0;
	}
	  </style>
	  <div class="newtbsect">
		<div><h1>CRM</h1></div>
		<div>
			<div class="pages_reg">
	<ul class="pagnav">
	 <?php if($total>$items_per_page){?>
		  
		  <?php echo  paginate_links( array(
			'base' => add_query_arg( 'cpage', '%#%' ),
			'format' => '<li></li>',
		   'total' => ceil($total/$items_per_page),
			'current' => $page,
			 'prev_text'          => __( 'Previous' ),
		'next_text'          => __( 'Next'),
		'type' => 'list'
		));
		
		
	   } ?>
	</ul>
	</div><!--pages_reg-->
	<div class="newtable">
<table width="100%" cellpadding="0" cellspacing="0" align="">
	<tr><td valign="top">
	<form name="frmsearch" id="frmsearch" action="" method="Post">
		<table width="100%" cellpadding="0" cellspacing="0" style="border:none;">
			<tr>
			<td align="right" style="padding:7px 96px 8px 0;" >Search 
			<select name="status" id="status">			
				<option value="">Select Group</option>
				<option value="Classique" <?php if($search_status=="Classique"){?>selected="selected"<?php }?>>Classique</option>
					<option value="Grand Precaire" <?php if($search_status=="Grand Precaire"){?>selected="selected"<?php }?>>Grand Precaire</option>
					<option value="Precaire" <?php if($search_status=="Precaire"){?>selected="selected"<?php }?>>Precaire</option>				 
			</select>
			<input type="text" name="field_value" id="field_value" value="<?php echo $field_value;?>" placeholder="Keywords">&nbsp;
			<input type="submit" name="btnsearch" id="btnsearch" value="Search"/>
			<input type="button" name="btnall" id="btnall" value="View all" onclick="return view_all('<?php echo  $siteurl;?>/wp-admin/admin.php?page=crm');"/> 
			 
		</td></tr>
		</table>
	</form></td></tr> 
</table></div>
			<table width="100%" cellpadding="0" cellspacing="2">
				<tr style="padding:10px 0px; background:#FFFFFF; border-bottom:solid 1px #333">
				<td   style="color:#333; padding:10px 0;"><strong>Action</strong></td>
				<td   style="color:#333;"><strong>NUMERO DOSSIER</strong></td>
				<td  style="color:#333;"><strong>STATUT</strong></td>
				<td  style="color:#333;"><strong>DEBUT</strong></td>
				<td  style="color:#333;"><strong>FIN</strong></td>
				<td  style="color:#333;"><strong>INSTALLATEUR</strong></td>
				<td  style="color:#333;"><strong>SIRET</strong></td>
				<td  style="color:#333;"><strong>NOM</strong></td>
				<td  style="color:#333;"><strong>PRENOM</strong></td>
				<td  style="color:#333;"><strong>Adresse</strong></td>
				<td  style="color:#333;"><strong>CP</strong></td>
				<td  style="color:#333;"><strong>Ville</strong></td>
				<td  style="color:#333;"><strong>EMAIL</strong></td>
				<td  style="color:#333;"><strong>PHONE</strong></td>
				<td  style="color:#333;"><strong>MOBILE</strong></td>
				<td  style="color:#333;"><strong>FONCTION</strong></td>
				<td  style="color:#333;"><strong>RGE</strong></td>
				<td  style="color:#333;"><strong>NOM</strong></td>
				<td  style="color:#333;"><strong>PRENOM</strong></td>
				<td  style="color:#333;"><strong>PRÉCARITÉ</strong></td>
				<td  style="color:#333;"><strong>ADRESS</strong></td>
				<td  style="color:#333;"><strong>CP</strong></td>
				<td  style="color:#333;"><strong>VILLE</strong></td>
				<td  style="color:#333;"><strong>MOBILE</strong></td>
				<td  style="color:#333;"><strong>PHONE NUMBER</strong></td>
				<td  style="color:#333;"><strong>EMAIL</strong></td>
				<td  style="color:#333;"><strong>FICHE</strong></td>
				<td  style="color:#333;"><strong>Operations</strong></td>
				<td  style="color:#333;"><strong>COMMERCIAL</strong></td>
				<td style="color:#333;"><strong>PRIME CLIENT €</strong></td>
				<td style="color:#333;"><strong>Referentiel prime</strong></td>
				<td style="color:#333;"><strong>CLASSIQUE MWH</strong></td>
				<td style="color:#333;"><strong>PRECARITÉ MWH</strong></td>
				<td style="color:#333;"><strong>ENVOYÉ</strong></td>
				<td style="color:#333;"><strong>OPENED</strong></td>
				<td style="color:#333;"><strong>SIGNÉ</strong></td>
				<td style="color:#333;"><strong>FACTURE</strong></td>
				<td style="color:#333;"><strong>AH</strong></td>
				<td style="color:#333;"><strong>N° DE LOT</strong></td>
				<td style="color:#333;"><strong>STATUT</strong></td>
				<td style="color:#333;"><strong>% client</strong></td>
				<td style="color:#333;"><strong>CLASSIQUE</strong></td>
				<td style="color:#333;"><strong>PRECARITÉ</strong></td>
				<td style="color:#333;"><strong>G PRECARITÉ</strong></td>				
				<td style="color:#333;"><strong>ENEMAT</strong></td>
				<td style="color:#333;"><strong>INSTALLATEUR</strong></td>
				<td style="color:#333;"><strong>PROFIT</strong></td>
			</tr>
			<?php  if(count($rs)){
			 for($i=0;$i<count($rs);$i++){	
			 $ID = $rs[$i]->id;
			 $status = $rs[$i]->status;
			 ?>
			<tr>
				<td>
				<select name="status" id="status" onchange="return change_status(this.value,'<?php echo $ID;?>','<?php echo plugins_url('crm/update_status.php' ,dirname(__FILE__));?>')">
					<option value="Classique" <?php if($status=="Classique"){?>selected="selected"<?php }?>>Classique</option>
					<option value="Grand Precaire" <?php if($status=="Grand Precaire"){?>selected="selected"<?php }?>>Grand Precaire</option>
					<option value="Precaire" <?php if($status=="Precaire"){?>selected="selected"<?php }?>>Precaire</option>
				</select>
				<div id="msgs<?php echo $ID;?>" style="display:none;"><strong>Processing.....</strong></div>
				</td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td><?php echo $rs[$i]->Installeture;?></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td><?php echo $rs[$i]->name;?></td>
				<td><?php echo $rs[$i]->fname;?></td>
				<td><?php echo $rs[$i]->status;?></td>
				<td><?php echo $rs[$i]->address;?></td>
				<td><?php echo $rs[$i]->post_code;?></td>
				<td><?php echo $rs[$i]->ville;?></td>
				<td><?php echo $rs[$i]->mobile;?></td>
				<td><?php echo $rs[$i]->tel;?></td>
				<td><?php echo $rs[$i]->email;?></td>
				<td><a href="<?php echo $rs[$i]->fichelink;?>" target="_blank"><?php echo $rs[$i]->fiche;?></a></td>
				<td><?php 
					if(!empty($rs[$i]->pmetaid)){
						$wordings = get_wordings($rs[$i]->pmetaid);
						echo $wordings;
					}
					?></td>
				<td><?php echo $rs[$i]->commercial;?></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td><?php //echo date("d/m/Y",strtotime($rs[$i]->sendmaildate));?></td>
				<td></td>
				<td><?php //echo date("d/m/Y", strtotime($rs[$i]->signdate));?></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			 
		</tr>
		<?php }
		 }else{?>
			 <tr><td align="center" colspan="51">No Record found!</td></tr>
		<?php
		}?>
			</table>
		</div>  
	  </div>
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <script type="text/javascript">
		function view_all(urls){
			window.location.href = urls;
		}
		function change_status(valstatus,ids,changestatusurl){
			//alert(ids);
			document.getElementById("msgs"+ids+"").style.display="block";
			setInterval(function(){
				$.ajax({
				   type: "POST",
				   data: {"valstatus":valstatus,"id":ids},
				   url: changestatusurl,
				   success: function(msg){
					   document.getElementById("msgs"+ids+"").innerHTML = msg;
						//alert("Status updated successfully!");
					 //$('#status').html(msg);
				   },
				   error: function(){
					//alert("Error!")
					 //$('.answer').html(msg);
				   }
				});
		},2000);
	}

	  </script>