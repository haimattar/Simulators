<?php
/**
 * enemat functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package enemat
 */

if ( ! function_exists( 'enemat_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function enemat_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on enemat, use a find and replace
		 * to change 'enemat' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'enemat', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'enemat' ),
		) );
		
		register_nav_menus( array(
			'menu-3' => esc_html__( 'fix', 'enemat' ),
		) );
		
		register_nav_menus( array(
			'my-menu' => esc_html__( 'My Menu', 'enemat' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'enemat_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'enemat_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function enemat_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'enemat_content_width', 640 );
}
add_action( 'after_setup_theme', 'enemat_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function enemat_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'enemat' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'enemat' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'enemat_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function enemat_scripts() {
	wp_enqueue_style( 'enemat-style', get_stylesheet_uri() );

	wp_enqueue_script( 'enemat-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'enemat-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'enemat_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

require get_template_directory() . '/user_registeration.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}


// function to display number of posts.

function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    return $count.' Views';
}

// function to count views.
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
function remove_menus(){
 if( current_user_can('editor') || current_user_can('admin') ) { 

		global $menu;
//	print_r($menu);
remove_menu_page( 'index.php' );                  //Dashboard
//remove_menu_page( 'jetpack' );                    //Jetpack* 
//remove_menu_page( 'edit.php' );                   //Posts
remove_menu_page( 'upload.php' );                 //Media
//remove_menu_page( 'edit.php?post_type=page' );    //Pages
remove_menu_page( 'edit-comments.php' );          //Comments
//  remove_menu_page( 'theme_my_login.php' );                 //Appearance
remove_menu_page( 'theme_my_login' );
remove_menu_page( 'plugins.php' );                //Plugins
// remove_menu_page( 'users.php' );                  //Users
remove_menu_page( 'tools.php' );                  //Tools
remove_menu_page( 'options-general.php' );        //Settings
}
}
add_action( 'admin_menu', 'remove_menus' );
/* Extra Admin functions */
if( current_user_can('editor') || current_user_can('admin') ) { 

function my_text_strings( $translated_text, $text, $domain ) {
switch ( $translated_text ) {
   case 'Users' :
       $translated_text = __( 'Professional User', 'master-slider' );
       break;
}
return $translated_text;
}
add_filter( 'gettext', 'my_text_strings', 20, 3 );
}


add_filter( 'wp_mail_from', 'new_mail_from' );
add_filter( 'wp_mail_from_name', 'new_mail_from_name' );
function new_mail_from( $old ) {
    return get_option( 'admin_email' );
}
function new_mail_from_name( $old ) {
    return get_option( 'blogname' ); 
}

function my_login_redirect( $redirect_to, $request, $user ) {
    //is there a user to check?
	$siteurl = get_option("siteurl");
    if ( isset( $user->roles ) && is_array( $user->roles ) ) {
        //check for admins
        if ( in_array( 'administrator', $user->roles ) ) {
            // redirect them to the default place
			$redirect_to = $siteurl."/wp-admin/";
            return $redirect_to;
        }else if ( in_array( 'editor', $user->roles ) ) {
            // redirect them to the default place
			$redirect_to = $siteurl."/wp-admin/";
            return $redirect_to;
        }else if ( in_array( 'admin', $user->roles ) ) {
            // redirect them to the default place
			$redirect_to = $siteurl."/wp-admin/";
            return $redirect_to;
        } else {
            return $siteurl."/simulateur/";
        }
    } else {
        return $redirect_to;
    }
}
 
 
add_filter( 'login_redirect', 'my_login_redirect', 10, 3 );

add_filter( 'editable_roles', 'wpse42003_filter_roles' );
function wpse42003_filter_roles( $roles )
{
    $user = wp_get_current_user();
    if( in_array( 'admin', $user->roles ) ){
        $tmp = array_keys( $roles );
        foreach( $tmp as $r ){
            if( 'subscriber' == $r || 'admin' == $r) continue;
            unset( $roles[$r] );
        }
    }
    return $roles;
}

function pa_user_list_pay_link( $actions, $user_object ) {
  $user = wp_get_current_user();
    if( in_array( 'admin', $user->roles ) || in_array( 'subscriber', $user->roles )){
         unset($actions['lock']);	// lock
         unset($actions['view']);	// view
       
    }
     return $actions;
}

add_filter( 'user_row_actions', 'pa_user_list_pay_link', 10, 2 );
function load_admin_style(){
    $user = wp_get_current_user();
    if( in_array( 'admin', $user->roles ) || in_array( 'subscriber', $user->roles )){
        $style = "<style>.lock-user,.user-role-wrap{display:none;}</style>";
        echo $style;
    }
}
 add_action( 'admin_head', 'load_admin_style' );
 
function change_role_name() {
    global $wp_roles;

    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();

    //You can list all currently available roles like this...
    //$roles = $wp_roles->get_names();
    //print_r($roles);

    //You can replace "administrator" with any other role "editor", "author", "contributor" or "subscriber"...
    $wp_roles->roles['subscriber']['name'] = 'Professinal User';
    $wp_roles->role_names['subscriber'] = 'Professinal User';           
}
add_action('init', 'change_role_name');


/*
add_filter ("retrieve_password_title", "retrieve_password_title");

function retrieve_password_title(){   
    $user_data = '';
    // If no value is posted, return false
    if( ! isset( $_POST['user_login'] )  ){
            return '';
    }
    // Fetch user information from user_login
    if ( strpos( $_POST['user_login'], '@' ) ) {

        $user_data = get_user_by( 'email', trim( $_POST['user_login'] ) );
    } else {
        $login = trim($_POST['user_login']);
        $user_data = get_user_by('login', $login);
    }
    if( ! $user_data  ){
        return '';
    }
    $user_id = $user_data->ID;
    $company_name = get_user_meta($user_id,"company_name",true);
     return "Réinitialisation mot de passe ENEMAT pour ".$company_name."";
}
*/
add_action('pre_user_query','rudr_hide_all_administrators');
 
function rudr_hide_all_administrators( $u_query ) {
 
	// let's do the trick only for non-administrators
	$current_user = wp_get_current_user();
	if ( $current_user->roles[0] == 'admin' ) { 
		global $wpdb;
		$u_query->query_where = str_replace(
			'WHERE 1=1', 
			"WHERE 1=1 AND {$wpdb->users}.ID IN (
				SELECT {$wpdb->usermeta}.user_id FROM $wpdb->usermeta 
					WHERE {$wpdb->usermeta}.meta_key = '{$wpdb->prefix}capabilities'
					AND {$wpdb->usermeta}.meta_value   LIKE '%subscriber%')", 
			$u_query->query_where
		);
	}
}


function my_custom_fonts() {
wp_enqueue_style( 'main', get_template_directory_uri() . '/style.css' );
}
add_action('admin_head', 'my_custom_fonts');

if(is_user_logged_in()){
    $current_user = wp_get_current_user();
    if ( $current_user->roles[0] == 'admin' ) { 
    add_filter('gettext', 'change_profile_labels');
    function change_profile_labels($input) {
        	$current_user = wp_get_current_user();
        	if ( $current_user->roles[0] == 'admin' ) {         	
        	if ('Username' == $input)
                return "Nom d'utilisateur";        	
            if ('First Name' == $input)
                return 'Prénom';
			if ('Language' == $input)
                return 'Langue';	
        
            if ('Last Name' == $input)
                return 'Nom de famille';
			if ('Nickname' == $input)
                return 'Surnom';
			if ('Display name publicly as' == $input)
                return 'Afficher le nom publiquement comme';		
            if ('Password' == $input)
                return 'Mot de passe';
            if ('Role' == $input)
                return 'Rôle'; 
            if ('Send User Notification' == $input)
                return "Envoyer une notification d'utilisateur";
             if ('Send the new user an email about their account.' == $input)
                return "Envoyez un nouvel e-mail au nouvel utilisateur à propos de son compte.";    
            return $input;
            if ('Add New User' == $input)
                return 'Rôle1'; 
    	}
    }
    
    function hide_website_krotedev(){
  echo "\n" . '<script type="text/javascript">jQuery(document).ready(function($) {
    $(\'label[for=url], input#url\').hide();
    
  }); 
  </script>' . "\n";
}
add_action('admin_head','hide_website_krotedev');

add_action( 'admin_head', 'resettext');
function resettext(){ ?>

<script type="text/javascript">
   jQuery( document ).ready(function() {   
	  jQuery('#createuser #createusersub').attr('onclick','return checkfields();');	
      jQuery('#createuser input#createusersub').val("Envoyer une invitation a s'Inscrire");
   });
   function checkfields(){
	  emails = document.getElementById("email").value;
	  if(emails!=""){
	  var errmsgs = "";
	  document.getElementById("user_login").value = emails;
		 if(document.getElementById("company_name").value==""){
		   errmsgs += "Company name est requis\n";	
		   //document.getElementById("company_name").focus();	
		 }
		 if(document.getElementById("society_number").value==""){
		   errmsgs += "N Siret est requis\n";
		   //document.getElementById("society_number").focus();		
		 }
		 if(document.getElementById("society_address").value==""){
		   errmsgs += "Society Adresse est requis\n";
		   //document.getElementById("society_address").focus();		
		 }
		 if(document.getElementById("society_postcode").value==""){
		   errmsgs += "Society Code postale est requis\n";
		   //document.getElementById("society_postcode").focus();		
		 }
		 if(document.getElementById("city").value==""){
		   errmsgs += "Ville est requis\n";
		   //document.getElementById("city").focus();		
		 }
		 if(document.getElementById("salesname").value==""){
		   errmsgs += "Commercial est requis\n";
		   //document.getElementById("salesname").focus();		
		 }
		 if(document.getElementById("notes").value==""){
		   errmsgs += "ENEMAT est requis\n";
		   //document.getElementById("notes").focus();		
		 }
		 if(document.getElementById("job").value==""){
		   errmsgs += "functions est requis\n";
		   //document.getElementById("job").focus();		
		 }
		 if(document.getElementById("phone_number").value==""){
		   errmsgs += "Tel fixe est requis\n";
		   //document.getElementById("phone_number").focus();		
		 }
		 if(document.getElementById("mobile_number").value==""){
		   errmsgs += "Tel mobile est requis\n";
		   //document.getElementById("mobile_number").focus();		
		 }
		 if(document.getElementById("prime_mwhc").value==""){
		   errmsgs += "Default Prime / Mwhc est requis\n";
		   //document.getElementById("prime_mwhc").focus();		
		 }
		 if(document.getElementById("precarite").value==""){
		   errmsgs += "Default Prime précarité / Mwhc est requis\n";
		   //document.getElementById("precarite").focus();		
		 }
		 if(document.getElementById("highprecarite").value==""){
		   errmsgs += "Default Prime High Precariousness / Mwhc\n";
		   //document.getElementById("highprecarite").focus();		
		 }
		 if(errmsgs!=""){
			alert(errmsgs);
			return false;
		 }
	 }
   }
</script>
<?php
}	add_action('admin_head', function(){
	if(!isset($_GET['user_id'])){
?>
     

    <script type="text/javascript">
        jQuery(document).ready(function($){
            $('.form-table tbody  tr:first-child').css('display', 'none');
        });
    </script>
<?php
}});
	add_action( 'edit_user_profile', 'resettext2');
	function resettext2(){ ?>

<script type="text/javascript">
   jQuery( document ).ready(function() {   
	  jQuery('#your-profile #submit').attr('onclick','return checkfields();');	
      //jQuery('#createuser input#createusersub').val("Envoyer une invitation a s'Inscrire");
   });
   function checkfields(){
	  emails = document.getElementById("email").value;
	  if(emails!=""){
	  var errmsgs = "";
	 	 if(document.getElementById("company_name").value==""){
		   errmsgs += "Company name est requis\n";	
		   //document.getElementById("company_name").focus();	
		 }
		 if(document.getElementById("society_number").value==""){
		   errmsgs += "N Siret est requis\n";
		   //document.getElementById("society_number").focus();		
		 }
		 if(document.getElementById("society_address").value==""){
		   errmsgs += "Society Adresse est requis\n";
		   //document.getElementById("society_address").focus();		
		 }
		 if(document.getElementById("society_postcode").value==""){
		   errmsgs += "Society Code postale est requis\n";
		   //document.getElementById("society_postcode").focus();		
		 }
		 if(document.getElementById("city").value==""){
		   errmsgs += "Ville est requis\n";
		   //document.getElementById("city").focus();		
		 }
		 if(document.getElementById("salesname").value==""){
		   errmsgs += "Commercial est requis\n";
		   //document.getElementById("salesname").focus();		
		 }
		 if(document.getElementById("notes").value==""){
		   errmsgs += "ENEMAT est requis\n";
		   //document.getElementById("notes").focus();		
		 }
		 if(document.getElementById("job").value==""){
		   errmsgs += "functions est requis\n";
		   //document.getElementById("job").focus();		
		 }
		 if(document.getElementById("phone_number").value==""){
		   errmsgs += "Tel fixe est requis\n";
		   //document.getElementById("phone_number").focus();		
		 }
		 if(document.getElementById("mobile_number").value==""){
		   errmsgs += "Tel mobile est requis\n";
		   //document.getElementById("mobile_number").focus();		
		 }
		 if(document.getElementById("prime_mwhc").value==""){
		   errmsgs += "Default Prime / Mwhc est requis\n";
		   //document.getElementById("prime_mwhc").focus();		
		 }
		 if(document.getElementById("precarite").value==""){
		   errmsgs += "Default Prime précarité / Mwhc est requis\n";
		   //document.getElementById("precarite").focus();		
		 }
		 if(document.getElementById("highprecarite").value==""){
		   errmsgs += "Default Prime High Precariousness / Mwhc\n";
		   //document.getElementById("highprecarite").focus();		
		 }
		 if(errmsgs!=""){
			alert(errmsgs);
			return false;
		 }
	 }
   }
</script>
<?php
}
	// remove personal options block
if( is_admin() ){
    //remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
    //add_action( 'personal_options', 'prefix_hide_personal_options' );
	add_action('admin_head','remove_personal_options');
}
/*
function prefix_hide_personal_options() {
  ?>
    <script type="text/javascript">
        jQuery( document ).ready(function( $ ){
            $( '#your-profile .form-table:first, #your-profile h3:first' ).remove();
        } );
    </script>
  <?php
}*/
function remove_personal_options(){
    echo '<script type="text/javascript">jQuery(document).ready(function($) {
  
$(\'form#your-profile > h2:first\').remove(); // remove the "Personal Options" title
  
$(\'form#your-profile tr.user-rich-editing-wrap\').remove(); // remove the "Visual Editor" field
  
$(\'form#your-profile tr.user-admin-color-wrap\').remove(); // remove the "Admin Color Scheme" field
  
$(\'form#your-profile tr.user-comment-shortcuts-wrap\').remove(); // remove the "Keyboard Shortcuts" field
  
$(\'form#your-profile tr.user-admin-bar-front-wrap\').remove(); // remove the "Toolbar" field
  
$(\'form#your-profile tr.user-language-wrap\').remove(); // remove the "Language" field
  
$(\'form#your-profile tr.user-nickname-wrap\').hide(); // Hide the "nickname" field
  
$(\'table.form-table tr.user-display-name-wrap\').remove(); // remove the “Display name publicly as” field
  
$(\'table.form-table tr.user-url-wrap\').remove();// remove the "Website" field in the "Contact Info" section
  
$(\'h2:contains("About Yourself"), h2:contains("About the user")\').remove(); // remove the "About Yourself" and "About the user" titles
  
$(\'form#your-profile tr.user-description-wrap\').remove(); // remove the "Biographical Info" field
  
$(\'form#your-profile tr.user-profile-picture\').remove(); // remove the "Profile Picture" field
  
$(\'table.form-table tr.user-aim-wrap\').remove();// remove the "AIM" field in the "Contact Info" section
 
$(\'table.form-table tr.user-yim-wrap\').remove();// remove the "Yahoo IM" field in the "Contact Info" section
 
$(\'table.form-table tr.user-jabber-wrap\').remove();// remove the "Jabber / Google Talk" field in the "Contact Info" section
 
});</script>';
  
}
  

    }
}

add_filter('ure_show_additional_capabilities_section', 'ure_show_additional_capabilities_section');
add_filter('ure_bulk_grant_roles', 'ure_show_additional_capabilities_section');

function ure_show_additional_capabilities_section($show) {
  if (current_user_can('admin'))     {
    $show = false;
  }

  return $show;
}
add_action('manage_users_custom_column',  'add_user_columns_content', 10, 3);
function add_user_columns_content($value, $column_name, $user_id) {
    $user = get_userdata( $user_id );
    if ( 'user_pass' == $column_name ){
    $user_pass = get_user_meta($user_id,"user_pass",true);
     return $user_pass;
    }else{
    return $value;
    }
}
add_filter('manage_users_columns', 'add_user_columns');
function add_user_columns($columns) {
    $columns['user_pass'] = 'Mot de passe de l\'utilisateur';
    return $columns;
}  

add_action( 'password_reset','password_reset', 10, 2 );

function password_reset($user, $pass){
	$user_id = $user->ID;
	$user_pass = $pass;
	update_user_meta($user_id,"user_pass",$user_pass);
}
