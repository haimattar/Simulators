<?php
// Template Name: Accueil
get_header(); ?>

<div class="main_bnr">
	<div class="wraper">
		<div class="txxt">
			<h3>Enemat</h3>
			<h5>VALORISER VOS CERTIFICATS D'ECONOMIE D'ENERGIE</h5>
			<?php //if ( is_user_logged_in() ) {
    echo '	<a href="'.get_site_url().'/simulateur/">SIMULATEUR</a>';
/*} else {
    echo '<a href="'.get_site_url().'/login/">SIMULATEUR</a>';
}*/ ?>
		
		</div>
		<div class="clr"></div>
	</div>
</div>
	
<div class="vNav">
      <?php wp_nav_menu(array('theme_location' => 'my-menu',  'container' => 'ul',
    'menu_class'=> 'vNav', 'link_before'   => '<div class="label">', 'link_after'    => '</div>')); ?>
    </div>
    
<div class="services par" id="services">
	<div class="wraper">
		<div class="lf_serv">
			<img src="<?php echo get_template_directory_uri(); ?>/images/service.png">
		</div>
		<div class="rg_serv">
			<h6>CEE MODE D'EMPLOI</h6>
			<p>En imposant aux fournisseurs d’énergie (électricité, gaz, fioul domestique, froid, chaleur) une obligation de réaliser des actions d’économies d’énergie, les CEE permettent de pouvoir faire financer tout ou partie des &nbsp; travaux d’efficacité énergétique.</p>
			<a href="<?php echo get_site_url(); ?>/typologie/">Plus</a>
		</div>	
		<div class="clr"></div>
	</div>
</div>
<div class="article par" id="NOTREÉQUIPE">
	<div class="wraper">
		<div class="lf_art">
			<h5>NOTRE ÉQUIPE</h5>
			<p>Des&nbsp;professionnels experts dans les problématiques écologiques et dans les dispositifs mis en place par le ministère de l'Ecologie et de l'Environnement vous accompagne et vous proposent des solutions clés en main en quelques clics.</p>
			<a href="<?php echo get_site_url(); ?>/a-propos/">Plus</a>
		</div>	
		<div class="rg_art">
			<img id="img1" src="<?php echo get_site_url(); ?>/wp-content/uploads/2018/03/article1.png">
			
		</div>
		<div class="clr"></div>
	</div>
</div>
<div class="rec_bck par" id="ARTICLESRÉCENTS">
	<div class="wraper">
	<h5 style="letter-spacing:0.2em;">ARTICLES RÉCENTS</h5>
		<ul>
		 <?php
  $args = array( 'post_type' => 'post', 
  'posts_per_page' => 3,
  'category_name'=>'Rédigez un commentaire',
  'order'=>'DESC',
 'orderby'=>'date'
  ); 
  $loop = new WP_Query( $args ); while ( $loop->have_posts() ) : $loop->the_post();
?>

<li>
<?php if ( has_post_thumbnail()) {?> <a href="<?php the_permalink(); ?>" ><?php echo the_post_thumbnail(array(200,150)); ?> </a> <?php } ?>
<a href="<?php the_permalink(); ?>"><p class="title1"><?php the_title(); ?></p></a>
<p class="rup_set">
<span><i class="fa fa-eye" aria-hidden="true"></i></span><?php echo do_shortcode('[post-views]') ?>
<a href="<?php the_permalink(); ?>"><span class="txt1">Rédigez un commentaire</span></a>
<span><i class="fa fa-heart-o" aria-hidden="true"></i></span>
</p>
</li>

  


 <?php endwhile; ?>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="contact par" id="contact">
	<div class="wraper">
		<div class="lf_con">
			<h5>Besoin de plus d'infos ? Contactez nous</h5>
			<p>N'hésitez pas à nous contacter.</p>
		</div>
		<div class="rg_con">
			<a href="<?php echo get_site_url(); ?>/contact/">Nous contacter</a>
		</div>
	<div class="clr"></div>
	</div>
</div>
<?php get_footer(); ?>
