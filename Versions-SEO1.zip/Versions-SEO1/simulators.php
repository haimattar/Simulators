<?php 
// Template name: Simualtors Demo
get_header(1);
session_start();
define('WP_USE_THEMES', true);
$template_dir= get_template_directory_uri();
global $wpdb;
global $wp;
$current_url = home_url(add_query_arg(array(),$wp->request));
$parseurls = parse_url($current_url);
$paths = explode("/",$parseurls['path']);
$urlsslugs = array_filter($paths);
//echo count($urlsslugs);
//print_r($urlsslugs);
$catslugs = "";
$subcatslugs = "";
$desgslugs = "";
if(count($urlsslugs)>1){
	$catslugs = $urlsslugs[2];
	if(!empty($urlsslugs[3])){
		$subcatslugs = $urlsslugs[3];
	}
	if(!empty($urlsslugs[4])){
		$desgslugs = $urlsslugs[4];
	}
}

$current_date = date("Y-m-d H:i:s");
$siteurl = get_option("siteurl");
$redirect_addproject= get_page_by_path("add-project");
$redirectaddprojectlink = get_permalink($redirect_addproject->ID);

$table_name = $wpdb->prefix . "projects";
$currentuserid=get_current_user_id();
$project_id = "";
$user_id = get_current_user_id();
//$cat_ds=implode(',',$_POST['projectcat']);*/
$browserid = session_id();
$SQL="SELECT * FROM `wp_categories` WHERE status='Active' order by category_name ASC " ;
/*
if(is_user_logged_in()){
$SQL="SELECT * FROM `wp_categories` WHERE status='Active' order by category_name ASC " ;
}
else{
    $page_id = 95;
$uri = get_page_uri($page_id);
  //  $_SESSION['SuccessMsg']="<p>if you want to Use Simulator then login first <a href=\"$uri\">Login</a></p>";
$SQL="SELECT * FROM `wp_categories` WHERE status='Active' order by category_name ASC " ;
}*/
$rsTabs=$wpdb->get_results($SQL);
//echo "<pre>";
//print_r($strsd);
function get_icons($caegory_name){
	$siteurl = get_option("siteurl");
	switch($caegory_name){
	 case "Agricole":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-agriculture.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-agriculture-2" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Bâtiment Résidentiel":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Bâtiment Tertiaire":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Industrie":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-industrie.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-industrie-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Réseaux":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-reseaux.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-reseaux-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	 case "Transports":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-transport.png" alt="'.$caegory_name.'">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-transport-1.png" class="img-top" alt="'.$caegory_name.'">';
	  return $img;		  
	}
}
?>
<script type="text/javascript">
	function show_step1(catids,prime_value,prime_currency,pageurls,sitecaturls,category_slug){//alert("a1");
		//var newurl = document.location;
		history.pushState(null, null, sitecaturls+"/");
		if(document.getElementById("step3")){
			document.getElementById("step3").style.display="none";
		}
		if(document.getElementById("numtitles")){
			document.getElementById("numtitles").style.display="none";
		}
		if(document.getElementById("step4")){
			document.getElementById("step4").style.display="none";
		}
		if(document.getElementById("step5")){
			document.getElementById("step5").style.display="none";
		}
		if(document.getElementById("step6")){
			document.getElementById("step6").style.display="none";
		}
		if($('.navlists li').hasClass('active')){
			$('.navlists li').removeClass('active');			
		}
		if(!$("#step1").hasClass("simulater12")){
	       $("#step1").addClass("simulater12");
	     
	    }
	    if($("#step2").hasClass("simulater12")){
	       $("#step2").removeClass("simulater12");
	     
	    }
	    if($("#step3").hasClass("simulater12")){
	       $("#step3").removeClass("simulater12");
	     
	    }
		if(document.getElementById("fiche")){
			$('#fiche option').remove();
		}
		document.getElementById("catgsid").value = catids;
		document.getElementById("prime_value").value = prime_value;
		document.getElementById("primecurr").value = prime_currency;
		
		$("#catsli-"+catids+"").addClass('active');
		 $.ajax({
                type: "POST",
                 data: {"catids":catids,"category_slug":category_slug},
                url: pageurls,
                success: function(msgs){
				//alert(msgs);
				 if($.trim(msgs)!=""){
				    if($("#step1").hasClass("simulater12")){
	                    $("#step1").removeClass("simulater12");
	                    $("#step2").addClass("simulater12");
	             } 
					document.getElementById("step2").style.display="block"; 
					$('#step2').html(msgs);
					//var scrollPos1 =  $("#step2").offset().top;
					//$(window).scrollTop(scrollPos1);
					$('html, body').animate({scrollTop:$('#step2').position().top}, 'slow');
					$('#step2').focus();
				 }
                },
                error: function(){
                 //$('.responsecat').html(msgs);
                }
        });
	}
	
	function active_zone(metaids){//alert(metaids);
		if($('.dexbnatiboxx a').hasClass('crrents')){
			$('.dexbnatiboxx a').removeClass('crrents');
		}
		$('#zone-'+metaids+'').addClass('crrents');
		document.getElementById("wmetavalues").value = metaids;
	}
	
	function show_designations(subcatids,pageurls,sitesubcaturls,category_slug,subcategory_slug){//alert("a1");
	    history.pushState(null, null, sitesubcaturls+"/");
		if(document.getElementById("step3")){
					document.getElementById("step3").style.display="none";
		}
		if(document.getElementById("numtitles")){
				document.getElementById("numtitles").style.display="none";
		}
		if(document.getElementById("step4")){
					document.getElementById("step4").style.display="none";
		}
		if(document.getElementById("step5")){
					document.getElementById("step5").style.display="none";
		}
		if(document.getElementById("step6")){
					document.getElementById("step6").style.display="none";
		}
		if(document.getElementById("fiche")){
			$('#fiche option').remove();
		}
		 if(subcatids!=""){
			if($('.subnavlists li').hasClass('active_sub')){
				$('.subnavlists li').removeClass('active_sub');			
			}
			$("#subcats-"+subcatids+"").addClass('active_sub');
			document.getElementById("sousSecteur").value = subcatids;
			 $.ajax({
					type: "POST",
					 data: {"subcatids":subcatids,"category_slug":category_slug,"subcategory_slug":subcategory_slug},
					url: pageurls,
					success: function(msgs1){
					//alert(msgs);
					 if($.trim(msgs1)!=""){
						document.getElementById("designations").style.display="block"; 
						$('#designations').html(msgs1);
					 }
					},
					error: function(){
					 //$('.responsecat').html(msgs);
					}
			});
		}else{
			document.getElementById("designations").style.display="none";
			if(document.getElementById("step4")){
				document.getElementById("step4").style.display="none";
			}
			if(document.getElementById("step5")){
				document.getElementById("step5").style.display="none";
			}
			if(document.getElementById("step6")){
				document.getElementById("step6").style.display="none";
			}
		}
	}
	function show_step2(desgids,pageurls){//alert("a1");
		if(document.getElementById("step5")){
				document.getElementById("step5").style.display="none";
		}
		if(document.getElementById("step6")){
				document.getElementById("step6").style.display="none";
		}
		if(desgids!=""){
			res = desgids.split(",");
			desgid = res[0];
			sitesubcatdesgurls1 = res[1];
			history.pushState(null, null, sitesubcatdesgurls1+"/");
			//alert(desgid+"==="+sitesubcatdesgurls1);			
		 }else{
			desgid = "";
			sitesubcatdesgurls = document.getElementById("sitesubcatdesgurlsdef").value;
			history.pushState(null, null, sitesubcatdesgurls);
		 }
		if($("#step1").hasClass("simulater12")){
	       $("#step1").removeClass("simulater12");
	     
	    }
	    if($("#step2").hasClass("simulater12")){
	       $("#step2").removeClass("simulater12");
	     
	    }
		var current = $('#fiche').val();
		if (current!= '') {
				$('#fiche').css('color','#2686c6');
		} else {
			  $('#fiche').css('color','#bfbfbf');
		}
		if(desgid!=""){			
			 $.ajax({
					type: "POST",
					 data: {"desgid":desgid},
					url: pageurls,
					success: function(msgs2){
					//alert(msgs);
					 if($.trim(msgs2)!=""){
						var datas = $.parseJSON(msgs2);	
					    if($("#step1").hasClass("simulater12")){
	                     $("#step1").removeClass("simulater12");	                     
	                    }  
	                     if($("#step2").hasClass("simulater12")){
    	                    $("#step2").removeClass("simulater12");
    	                }
    	                $("#step3").addClass("simulater12");
						document.getElementById("numtitles").style.display="block";
						document.getElementById("step3").style.display="block";
						//document.getElementById("step4").style.display="block";
						$('#numtitles').html(datas['designations']);
						$('#step3').html(datas['meta']);
						//var scrollPos2 =  $("#step3").offset().top;
						//$(window).scrollTop(scrollPos2);
						$('html, body').animate({scrollTop:$('#step3').position().top}, 'slow');
						$('#step3').focus();
					 }
					},
					error: function(){
					 //$('.responsecat').html(msgs);
					}
			});
		}else{
			document.getElementById("step3").style.display="none";
			if(document.getElementById("numtitles")){
				document.getElementById("numtitles").style.display="none";
			}
			document.getElementById("step4").style.display="none";
			if(document.getElementById("step5")){
				document.getElementById("step5").style.display="none";
			}
			if(document.getElementById("step6")){
					document.getElementById("step6").style.display="none";
			}
		}	
	}
	
	function get_conditions(metaids,secsids,pageurls){
	 //alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					//alert(msgformdatareset);
					if($.trim(msgformdatareset)!="No"){
						  $(".trcpnditions"+secsids+"").remove(".trcpnditions"+secsids+"");
						//$("spcnd"+secsids+"").before(msgformdatareset);
						//$("#trconds"+secsids+"").before(msgformdatareset);
					}				
                },
				complete: function () {
					get_conditions2(metaids,secsids,pageurls);
				
				},
                error: function(){  
                }
        });
}

function get_sub_conditions(metaids,secsids,pageurls){
	 //alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					//alert(msgformdatareset);
					if($.trim(msgformdatareset)!="No"){
						  $("#trcpconmetas"+secsids+"").replaceWith(msgformdatareset);
					}				
                },
                error: function(){  
                }
        });
}
function get_conditions2(metaids,secsids,pageurls){
	 // alert(secsids);
	// alert(frmdatas1);
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                data: {"metaids":metaids,"catid":secsids},
                url: pageurls,
                success: function(msgformdatareset){
					 //alert(msgformdatareset);
					if($.trim(msgformdatareset)!="No"){
						$("#trconds"+secsids+"").before(msgformdatareset);
					}				
                },
                error: function(){  
                }
        });
}

function submit_form(pageurls,secsids){
	 frmdatas = $("#frmdata").serialize();	 
	 $.ajax({
                type: "POST",             // Type of request to be send, called as method
                 data: frmdatas,
                url: pageurls,
                success: function(msgformdatas){
					//alert(msgformdatas);
					 document.getElementById("step5").style.display="block";
					 $("#step5").html(msgformdatas);
					 if(document.getElementById("step6")){
						document.getElementById("step6").style.display="none";
					}
					 //var scrollPos3 =  $("#step5").offset().top;
					 //$(window).scrollTop(scrollPos3);
					 $('html, body').animate({scrollTop:$('#step5').position().top}, 'slow');
					 $('#step5').focus();					 	
                },
                error: function(){  
                }
        });
}
function show_prime_details(prmetaid,pageurls){//alert("a1");
		 $.ajax({
					type: "POST",
					 data: {"prmetaid":prmetaid},
					url: pageurls,
					success: function(msgs5){
					//alert(msgs);
					 if($.trim(msgs5)!=""){
						document.getElementById("step6").style.display="block"; 
						$('#step6').html(msgs5);
						//var scrollPos4 =  $("#step6").offset().top;
						//$(window).scrollTop(scrollPos4);
						$('html, body').animate({scrollTop:$('#step6').position().top}, 'slow');
						$('#step6').focus();
					 }
					},
					error: function(){
					 //$('.responsecat').html(msgs);
					}
			});		  
}
</script>
 <div class="simu_primese">
  <div class="wraper">
    <h1>Simulateur Prime énergie</h1>
	<form class="frmdatas" name="frmdata" id="frmdata" method="post" action="">
      <div id="step1" class="simular_sec1 <?php if(empty($subcatslugs)){?>simulater12<?php }?>">
	  <img src="<?php echo $siteurl;?>/wp-content/uploads/2018/06/smartphone-1.png" class="nerwsec">
	   <h3>Secteur concerné par votre étude :</h3>
		<?php if(count($rsTabs)>0){?>	
		 <ul class="navlists">
			<?php foreach($rsTabs as $tbs){
				$category_name = ucwords($tbs->category_name);
				$category_slug = $tbs->category_slugs;
				$sitecaturls = $siteurl."/simulateur/".$category_slug;
				$ids=$tbs->id;
				$prime_value = $tbs->prime_value;
				$prime_currency = $tbs->prime_currency;
				if($category_slug==$catslugs){
					$class_cats = 'class="active"';
				}else{
					$class_cats = 'class=""';
				}
				?>
				<li id="catsli-<?php echo $ids;?>" <?php echo $class_cats;?> onclick="return show_step1('<?php echo $ids;?>','<?php echo $prime_value;?>','<?php echo $prime_currency;?>','<?php echo get_template_directory_uri().'/ajax_scripts/get_subcats.php';?>','<?php echo $sitecaturls;?>','<?php echo $category_slug;?>');">
					   <div class="card" id="catimages-<?php echo $ids;?>">
					    <?php $images = get_icons($category_name);
							echo $images;
						?>						
					</div>
                   <h4 id="catheading-<?php echo $ids;?>"><?php echo str_replace(" ","<br/>",$category_name); ?></h4></li>
			<?php }?>		
	      </ul>
		  <?php }?>
	 </div>
<!--2 section-->
	<input type="hidden" name="catgsid" id="catgsid" value="">
	<input type="hidden" name="prime_value" id="prime_value" value=""/>
	<input type="hidden" name="primecurr" id="primecurr" value=""/>
	<input type="hidden" name="project_id" id="project_id" value="<?php echo $project_id;?>"/>	
  
  <div id="step2" class="simular_sec1 <?php if(empty($desgslugs)){?>simulater12<?php }?>" <?php if(empty($subcatslugs)){?>style="display:none;"<?php }else{?>style="display:block;"<?php }?>>
   <?php
   if(!empty($subcatslugs)){    
	$SQLCATS = "SELECT * FROM `wp_categories` WHERE category_slugs='".$catslugs."'" ;
	$rsCatsids=$wpdb->get_results($SQLCATS);
	$catids = $rsCatsids[0]->id;
	
    $category_slug = $catslugs;
    $SQL="SELECT * FROM `wp_subcategory` WHERE status='Active' AND  catid ='".$catids."'";
    $rsSubCats=$wpdb->get_results($SQL);
	
	$SQLSUBCAT1="SELECT * FROM `wp_subcategory` WHERE status='Active' AND  category_slugs ='".$catslugs."' AND  subcategory_slugs ='".$subcatslugs."'";
	$rsSubCats1=$wpdb->get_results($SQLSUBCAT1);
	$subcatid = $rsSubCats1[0]->id;
					
    function get_subcat_icons($caegory_name){
		$siteurl = get_option("siteurl");
		switch($caegory_name){
		 case "Chauffage":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/chauffage.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/chauffage-1.png" class="img-top" alt="Card Front">';
		  return $img;		  
		 case "Isolation":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/isolation2.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/isolation2-1.png" class="img-top" alt="Card Front">';
		  return $img;		  
		 case "LED & autres":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/led-autres.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/led-autres-1.png" class="img-top" alt="Card Front">';
		  return $img;		  
		 case "Services":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/services.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/services-1.png" class="img-top" alt="Card Front">';
		  return $img;		  
		 case "Utilités":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/utilites.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/utilites-1.png" class="img-top" alt="Card Front">';
		  return $img;      
		  case "Chaleur et Froid":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/chaleur-froid.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/chaleur-froid-1.png" class="img-top" alt="Card Front">';
		  return $img;
		   case "Eclairage":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/eclairage.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/eclairage-1.png" class="img-top" alt="Card Front">';
		  return $img;
		  case "Bâtiments":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel-1.png" class="img-top" alt="Card Front">';
		  return $img;
		  case "Equipment":
		  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire.png" alt="Card Back">
				  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire-1.png" class="img-top" alt="Card Front">';
		  return $img;	
		}
	}
?>
	  <img src="<?php echo $siteurl;?>/wp-content/uploads/2018/06/smartphone-2.png" class="nerwsec">
	   <h3>Sous secteur :</h3>
	    <?php if(count($rsSubCats)){?>
	      <ul class="subnavlists">	<?php foreach($rsSubCats as $subtbs){
				$ids = $subtbs->id;
				$category_name = $subtbs->category_name;
				$subcategory_slug = $subtbs->subcategory_slugs;				 
				$sitesubcaturls = $siteurl."/simulateur/".$category_slug."/".$subcategory_slug;
				if($subcategory_slug==$subcatslugs){
					$class_subcats = 'class="active_sub"';
				}else{
					$class_subcats = 'class=""';
				}
		  ?>
				<li  id="subcats-<?php echo $ids;?>" <?php echo $class_subcats;?> onclick="return show_designations('<?php echo $ids;?>','<?php echo get_template_directory_uri().'/ajax_scripts/get_designations.php';?>','<?php echo $sitesubcaturls;?>','<?php echo $category_slug;?>','<?php echo $subcategory_slug;?>');">
					   <div class="card">
						 <?php $images = get_subcat_icons($category_name);
							echo $images;?>
					</div>
                   <h4><?php echo $category_name;?></h4></li>
				<?php }?> 
				
	      </ul>		  
		  <input type="hidden" name="sousSecteur" id="sousSecteur" value="<?php echo $subcatid;?>">
		  <?php }?>
		  <div class="dexbnati" id="designations">
				<?php if(!empty($subcatslugs)){
				    $siteurl = get_option('siteurl');
					$catslugs = $catslugs;					
					$subcatslugs = $subcatslugs;
					global $wpdb;
					$SQL="SELECT * FROM `wp_designations` WHERE status='Active' AND  subcatid ='".$subcatid."' ORDER BY des_name ASC";
					$rsDesignation=$wpdb->get_results($SQL);					
					$sitesubcatdesgurlsdef = $siteurl."/simulateur/".$catslugs."/".$subcatslugs."/";
				?>
				<h3>Désignation :</h3>
				 <select name="fiche" id="fiche" <?php if(!empty($desgslugs)){?>style="color:#2686c6;"<?php }?> onchange="return show_step2(this.value,'<?php echo get_template_directory_uri().'/ajax_scripts/get_wordings.php';?>');">
					 <option value="" class="opwrap" selected="selected">Merci de sélectionner ...</option>
					  <?php if(count($rsDesignation)>0){
							for($i=0;$i<count($rsDesignation);$i++){
								$sitesubcatdesgurls = $siteurl."/simulateur/".$rsDesignation[$i]->category_slugs."/".$rsDesignation[$i]->subcategory_slugs."/".$rsDesignation[$i]->desg_slugs."";
								$desgoptions = $rsDesignation[$i]->id.",".$sitesubcatdesgurls;
							?>
						<option value="<?php echo $desgoptions;?>" <?php if(strpos($desgoptions, $desgslugs)== true) {?>selected="selected" <?php }?>><?php echo stripslashes($rsDesignation[$i]->des_name);?></option>
					  <?php }
					  } ?>
			</select>
			<input type="hidden" name="sitesubcatdesgurlsdef" id="sitesubcatdesgurlsdef" value="<?php echo $sitesubcatdesgurlsdef;?>"/>
			 <div id="numtitles"><?php if(!empty($desgslugs)){ 
			 $SQLDESIG="SELECT * FROM `wp_designations` WHERE status='Active' AND  category_slugs ='".$catslugs."' AND  subcategory_slugs ='".$subcatslugs."' AND  desg_slugs ='".$desgslugs."'";
			$rsDesgs=$wpdb->get_results($SQLDESIG);
			$array_find = array(".pdf",".PDF");
			$array_replace = "";
			$number_title = str_replace($array_find,$array_replace,$rsDesgs[0]->number);
			$designationsliks = '<a href="'.$target.'" target="_blank">'.$number_title.'</a>';
			 echo $designationsliks;}?></div>
				<?php
				}?>
		  </div> 
	<?php }?>
  </div>	 
	 
	<!--3 section-->	 
  <div id="step3" <?php if(empty($desgslugs)){?>style="display:none;"<?php }else{?>class="simulater12" style="display:block;"<?php }?>>
		<?php if(!empty($desgslugs)){ 
	 $siteurl = get_option('siteurl');
	 $SQLDESIG="SELECT * FROM `wp_designations` WHERE status='Active' AND  category_slugs ='".$catslugs."' AND  subcategory_slugs ='".$subcatslugs."' AND  desg_slugs ='".$desgslugs."'";
	$rsDesignation=$wpdb->get_results($SQLDESIG);
	//print_r($rsDesignation);
	$desgid = $rsDesignation[0]->id;
	$catids = $rsDesignation[0]->catid;
	//$SQL="SELECT * FROM wp_wording WHERE desg_id ='".$desgid."' AND title NOT LIKE '%Zone climatique%' ORDER BY `desg_id` ASC";
	
	$SQL="SELECT * FROM wp_wording WHERE desg_id ='".$desgid."' ORDER BY `desg_id` ASC";
	$resultWord = $wpdb->get_results($SQL);

	$SQLZONE="SELECT * FROM wp_wording WHERE desg_id ='".$desgid."' AND title LIKE '%Zone climatique%' ORDER BY `title` ASC";
	$resultWordZONE = $wpdb->get_results($SQLZONE);
	//print_r($resultWordZONE);
	$meta = "";
	$meta1 = "";
	$meta2 = "";
	function rspecial($string,$rp = '') {
	$string = str_replace(' ', ',', $string);
	return preg_replace('/[^A-Za-z0-9\-]/', $rp, $string);
	}
	 
	$meta .= '<div id="step31" class="simular_sec1 simular_sec3">
	  <img src="'.$siteurl.'/wp-content/uploads/2018/06/smartphone-3.png" class="nerwsec">
		<div class="dexbnati secsimu2 newsedrmaint">';				 
					if(count($resultWord)>0 ){
		$meta .= '<table cellpadding="0" cellspacing="0" border="0" align="center" style="width:100%;">';
		foreach($resultWord as $spt){
			$wmts=$spt->id;
			if($spt->otherparts=="No"){
			$SQwordMeta="SELECT * FROM wp_wording_meta WHERE word_id ='".$wmts."' ORDER BY `id` ASC,is_cond ASC";
			$WMeta = $wpdb->get_results($SQwordMeta);
			$meta .= '<tr><td>
			<h3>'.stripslashes($spt->title).'</h3>
			<input type="text" name="wordingid[]" id="wordingid'.$catids.'" value="'.$wmts.'" style="display:none;"/>
			</td>';
			$meta .= '<td class="param-input tac">';
			if(!empty($WMeta)){
			$counter_meta = 0;
			$counter_meta_conds = 0;
			$first_conditions = "";
			$condionsvals = "";
			$subcondionsvals = "";
			 $meta .= '<select name="wmetavalue[]" id="wmetavalue'.$wmts.'" onchange=\'return  get_conditions(this.value,"'.$catids.'","'.$siteurl.'/wp-content/themes/enemat/ajax_scripts/conditions_data.php");\'>';
			foreach($WMeta as $wmr){
				$counter_meta = $counter_meta+1;
				//====Check Meta Conditions==========//
				//If Meta Conditions Exists//
				//If Meta Conditions Exists//
				if($counter_meta==1){
					$meta_id = $wmr->id;
					$SQLCOND = "SELECT * FROM wp_meta_conditions WHERE meta_id='".$meta_id."' ORDER BY is_cond ASC";
					$rsConditions = $wpdb->get_results($SQLCOND);
					$first_conditions = "1";
					if(count($rsConditions)>0){
				 for($x=0;$x<count($rsConditions);$x++){
					if($rsConditions[$x]->is_cond=="Yes"){ 
						$cond_id = $rsConditions[$x]->id;
						$SQLCONDVALUES = "SELECT * FROM wp_meta_conditions_values WHERE cond_id='".$cond_id."'";
						$rsCondValues = $wpdb->get_results($SQLCONDVALUES);
						$condionsvals = '<select name="condition_valuesid[]" id="condition_valuesid" onchange=\'return  get_sub_conditions(this.value,"'.$catids.'","'.$siteurl.'/wp-content/themes/enemat/ajax_scripts/subconditions_data.php");\'>';
						 for($aa=0;$aa<count($rsCondValues);$aa++){
							$counter_meta_conds = $counter_meta_conds+1;
							if($counter_meta_conds ==1){
								$SQLSUBCONDS = "SELECT * FROM wp_cond_meta_cond WHERE cmcond_id='".$rsCondValues[$aa]->id."'";
								$rsSubconds = $wpdb->get_results($SQLSUBCONDS);
								if(count($rsSubconds)>0){								
									 for($xx=0;$xx<count($rsSubconds);$xx++){						
										$SQLCONDMETAVALUESVALUES = "SELECT * FROM wp_cond_meta_cond_values WHERE cmcond_id='".$rsSubconds[$xx]->id."'";
										$rsSubcondMetas = $wpdb->get_results($SQLCONDMETAVALUESVALUES);
										if(count($rsSubcondMetas)>0){
											$subcondionsvals = '<select name="subcondition_valuesid" id="subcondition_valuesid">';
											for($yy=0;$yy<count($rsSubcondMetas);$yy++){
												$subcondionsvals .= '<option value="'.$rsSubcondMetas[$yy]->id."-".$rsSubcondMetas[$yy]->cmcv_value."-".$rsSubcondMetas[$yy]->cond_id."-".$rsSubcondMetas[$yy]->subconds_id.'">'.$rsSubcondMetas[$yy]->cmcv_title.'</option>';
											}
											$subcondionsvals .= '</select>';	
										}
										 $meta2 .= '<tr id="trcpconmetas'.$catids.'" class="trcpnditions'.$catids.'"><td><h3>'.$rsSubconds[$xx]->cmc_title.'</h3>
										 <input type="hidden" name="subcondition_id" id="subcondition_id'.$catids.'" value="'.$rsSubconds[$xx]->id.'" style="display:none;"/>
										 </td><td class="param-input tac">'.$subcondionsvals.'</td></tr>';
									}
								}
							}else{
								$meta2 .= "";
							}
							$condionsvals .= '<option value="'.$rsCondValues[$aa]->id."-".$rsCondValues[$aa]->mc_value.'">'.$rsCondValues[$aa]->mc_title.'</option>';
						 }
						$condionsvals .= '</select>
						<input type="text" name="condition_id[]" id="condition_id'.$catids.'" value="'.$rsConditions[$x]->id.'" style="display:none;"/>';				
						
						$meta1 .= '<tr class="trcpnditions'.$catids.'"><td><h3>'.$rsConditions[$x]->mc_title.'</h3></td><td class="param-input tac">'.$condionsvals.'</td></tr>';
						if($x==0){
							$meta1 .= '<tr id="trconds0-'.$catids.'"style="display:none;"><td colspan="2"></td></tr>';
							$meta1 .= $meta2; 
						}
											
				 }
				 if($rsConditions[$x]->is_cond=="No"){
					if($rsConditions[$x]->otherparts=="No"){
					 $condsvaltext = '<input type="text" name="condition_text" id="condition_text"/>';
					 $meta1 .= '<tr class="trcpnditions'.$catids.'"><td><h3>'.$rsConditions[$x]->mc_title.'</h3></td><td class="param-input tac">'.$condsvaltext.'</td></tr>';
					 $meta1 .= '<input type="hidden" name="condition_textid" id="condition_textid'.$catids.'" value="'.$rsConditions[$x]->id.'"/>';	
					}
					if($rsConditions[$x]->otherparts=="Yes"){
					 $meta1 .= '<tr class="trcpnditions'.$catids.'" style="display:none;"><td><input type="hidden" name="partssub" id="partssub'.$catids.'" value="'.$rsConditions[$x]->mc_value.'"/>
					 <input type="hidden" name="partssubopt" id="partssubopt'.$catids.'" value="'.$rsConditions[$x]->optypes.'"/></td></tr>';
					 }
				 }
				 
				}
				}	
				}
				//====Check Meta Conditions==========//
		
	 $wmrval=rspecial($wmr->value,'.'); //  output: _index_id_666
				
			$meta .=  '<option  value="'.$wmr->id.'-'.$wmrval.'-'.$wmr->is_cond.'">'.stripslashes($wmr->title).'</option>';
			}
			$meta .= '</select>';
			}else{
			$meta .= '<input type="text" name="wmetavalue[]" id="wmetavalue'.$catids.'"  step="1" value=""  min="0" >';
			}		 
			$meta .= '</td></tr>';
			}else if($spt->otherparts=="Yes"){
				 $meta .= '<input type="text" style="display:none;"name="wpartssub[]" id="wpartssub'.$catids.'" value="'.$spt->word_value.'"/>
					 <input type="hidden" name="wpartssubopt" id="wpartssubopt'.$catids.'" value="'.$spt->optypes.'"/>';
			}
			}
			if(!empty( $first_conditions)){
					$meta .= $meta1;
			}
			$meta .= '<tr id="trconds'.$catids.'" style="display:none;"><td class="sav_spcl" colspan="2"></td></tr></table>';
			} 
			$meta .= '</div>
			   
		<br class="clr"/> 		 
		</div>';
		$meta .= '<div id="step4">
<span class="hrbor"></span>
<div class="cond_applica">
		  <h3>Conditions d’application :</h3>
		  <ul>
		      <li>'.$rsDesignation[0]->conditions.'</li>
			  
	</ul>';
	  $target = get_site_url()."/wp-content/plugins/simulate/uploads/".$rsDesignation[0]->number;
	  $meta .= '<input type="hidden" name="number_title" id="number_title" value="'.$rsDesignation[0]->number.'"/>
	   <input type="hidden" name="number_link" id="number_link" value="'.$target.'" target="_blank"/>
		<input type="hidden" name="conditions" id="conditions" value="'.stripslashes($rsDesignation[0]->conditions).'"/> 
		  <h4 class="saproject"> <a  onclick="return submit_form(\''.$siteurl.'/wp-content/themes/enemat/ajax_scripts/submit_data.php\',\''.$catids.'\');">Demander ma prime</a> </h4>
		   <br class="clr"/>
	 </div>	 
<span class="hrbor"></span>
	</div>'; 
		echo $meta;
		}?>
  </div>
  <div id="step5" style="display:none;"></div>
   </form>
  <div id="step6" style="display:none;"></div>
	 </div><!--ends wraper-->	 	 
 </div><!--ends simu_primese--> 

 <div class="clr"></div>
<?php get_footer(1);?>