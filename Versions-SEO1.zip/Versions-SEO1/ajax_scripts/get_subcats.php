<?php
   //  echo "<pre>";
   // print_r($_POST);exit;
@session_start();   
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __DIR__  ) );
$siteurl = get_option('siteurl');
global $wpdb;
$catids = $_POST['catids'];
$category_slug = $_POST['category_slug'];
$SQL="SELECT * FROM `wp_subcategory` WHERE status='Active' AND  catid ='".$catids."'";
$rsSubCats=$wpdb->get_results($SQL);
function get_subcat_icons($caegory_name){
	$siteurl = get_option("siteurl");
	switch($caegory_name){
	 case "Chauffage":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/chauffage.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/chauffage-1.png" class="img-top" alt="Card Front">';
	  return $img;		  
	 case "Isolation":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/isolation2.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/isolation2-1.png" class="img-top" alt="Card Front">';
	  return $img;		  
	 case "LED & autres":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/led-autres.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/led-autres-1.png" class="img-top" alt="Card Front">';
	  return $img;		  
	 case "Services":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/services.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/services-1.png" class="img-top" alt="Card Front">';
	  return $img;		  
	 case "Utilités":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/utilites.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/utilites-1.png" class="img-top" alt="Card Front">';
	  return $img;      
	  case "Chaleur et Froid":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/chaleur-froid.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/chaleur-froid-1.png" class="img-top" alt="Card Front">';
	  return $img;
	   case "Eclairage":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/eclairage.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/eclairage-1.png" class="img-top" alt="Card Front">';
	  return $img;
	  case "Bâtiments":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-residentiel-1.png" class="img-top" alt="Card Front">';
	  return $img;
	  case "Equipment":
	  $img = '<img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire.png" alt="Card Back">
			  <img src="'.$siteurl.'/wp-content/uploads/2018/06/1-batiment-tertiaire-1.png" class="img-top" alt="Card Front">';
	  return $img;	
	}
}
?>
	  <img src="<?php echo $siteurl;?>/wp-content/uploads/2018/06/smartphone-2.png" class="nerwsec">
	   <h3>Sous secteur :</h3>
	    <?php if(count($rsSubCats)){?>
	      <ul class="subnavlists">	<?php foreach($rsSubCats as $subtbs){
				$ids = $subtbs->id;
				$category_name = $subtbs->category_name;
				$subcategory_slug = $subtbs->subcategory_slugs;				 
				$sitesubcaturls = $siteurl."/simulateur/".$category_slug."/".$subcategory_slug;
		  ?>
				<li  id="subcats-<?php echo $ids;?>" onclick="return show_designations('<?php echo $ids;?>','<?php echo get_template_directory_uri().'/ajax_scripts/get_designations.php';?>','<?php echo $sitesubcaturls;?>','<?php echo $category_slug;?>','<?php echo $subcategory_slug;?>');">
					   <div class="card">
						 <?php $images = get_subcat_icons($category_name);
							echo $images;?>
					</div>
                   <h4><?php echo $category_name;?></h4></li>
				<?php }?> 
				
	      </ul>		  
		  <input type="hidden" name="sousSecteur" id="sousSecteur" value="">
		  <?php }?>
		  <div class="dexbnati" id="designations" style="display:none;">
		     
		  </div> 